package com.example.demo.service.adminService;

import com.example.demo.dto.request.adminReq.ConfirmOrCancelTransactionReq;
import com.example.demo.dto.request.adminReq.StatisticalReq;
import com.example.demo.dto.response.statisticalRes.admin.StatisticalForAdminRes;
import com.example.demo.dto.response.statisticalRes.seller.StatisticalForSellerRes;

import javax.servlet.http.HttpServletRequest;

public interface AdminService {
    void confirmTransaction(HttpServletRequest request, ConfirmOrCancelTransactionReq confirmOrCancelTransactionReq);

    /**
     * statistical for admin
     * @param req
     * @return
     */
    StatisticalForAdminRes statisticalForAdmin(StatisticalReq req);


    /**
     * statistical for seller
     * @param servletRequest
     * @param req
     * @return
     */
    StatisticalForSellerRes statisticalForSeller(HttpServletRequest servletRequest, StatisticalReq req);





}
