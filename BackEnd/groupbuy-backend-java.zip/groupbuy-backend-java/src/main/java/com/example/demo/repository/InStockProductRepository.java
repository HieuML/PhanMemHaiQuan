package com.example.demo.repository;

import com.example.demo.entities.InStockProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface InStockProductRepository extends JpaRepository<InStockProduct, Integer> {
    Optional<InStockProduct> findByProductProductIDAndCampaignCampaignIDAndInStockProductID(String productID, String campaignID, Integer instockProductID);

    Optional<InStockProduct> findByProductProductIDAndInStockProductID(String productID, Integer inStockProductID);

    Optional<InStockProduct> findByProductProductIDAndInStockProductIDAndCampaignCampaignID(String productID, Integer inStockProductID, String campaignID);

    List<InStockProduct> findInStockProductByProductProductID(String productID);

    @Transactional
    void deleteByProductProductID(String productID);

    List<InStockProduct> findByProductProductID(String productID);

    List<InStockProduct> findByCampaignCampaignID(String campaignID);
}
