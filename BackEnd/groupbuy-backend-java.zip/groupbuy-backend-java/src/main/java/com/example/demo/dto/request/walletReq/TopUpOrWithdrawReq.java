package com.example.demo.dto.request.walletReq;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TopUpOrWithdrawReq {
    private Integer money;
}
