package com.example.demo.dto.request.campaignReq;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetLstCampaignByShopIdReq extends GetAllCampaignReq {
    private Integer shopId;
}
