package com.example.demo.dto.response.wardRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Ward;

public class WardRes extends IdNameRes {
    public WardRes(Integer id, String name) {
        super(id, name);
    }

    public static WardRes convertFromEntity(Ward ward) {
        return new WardRes(ward.getWardID(), ward.getName());
    }
}
