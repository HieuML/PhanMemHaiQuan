package com.example.demo.dto.response.cartItemRes;

import com.example.demo.dto.response.IdNameRes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class ListCartItemCheckoutRes {
    private IdNameRes shop;
    private List<CartItemRes> listCartItemRes;
    private Integer sumDeposit;
    private Integer shippingFee;
    private Integer sumPrice;
    private Integer buyTypeID;
    private Integer deliveryID;
}
