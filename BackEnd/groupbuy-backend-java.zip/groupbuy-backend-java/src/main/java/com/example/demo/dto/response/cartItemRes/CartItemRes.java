package com.example.demo.dto.response.cartItemRes;

import com.example.demo.constants.Status;
import com.example.demo.dto.response.IdNameRes;
import com.example.demo.dto.response.productRes.ProductRes;
import com.example.demo.entities.Campaign;
import com.example.demo.entities.CartItem;
import com.example.demo.dto.response.productRes.InStockProductRes;
import com.example.demo.entities.InStockProduct;
import com.example.demo.repository.CampaignRepository;
import com.example.demo.repository.InStockProductRepository;
import com.example.demo.repository.ValuePropertyRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
public class CartItemRes {
    private Integer cartItemId;
    private ProductRes productRes;
    private Integer quantity;
    private IdNameRes buyType;
    private Integer deposit;
    private Integer priceCurrent;
    private Boolean status;
    private InStockProductRes inStockProduct;
    private String campaignID;
    private List<InStockProductRes> listInStockCampaign;

    public CartItemRes(CartItem cartItem, CampaignRepository campaignRepository, InStockProductRepository inStockProductRepository, ValuePropertyRepository valuePropertyRepository) {
        this.cartItemId = cartItem.getCartItemId();
        this.productRes = new ProductRes(cartItem.getProduct(), inStockProductRepository, valuePropertyRepository);
        this.quantity = cartItem.getQuantity();
        this.deposit = cartItem.getDeposit();
        this.priceCurrent = cartItem.getPriceCurrent();
        this.buyType = new IdNameRes(cartItem.getBuyType().getBuyTypeID(), cartItem.getBuyType().getName());
        this.status = cartItem.getStatus();
        if (cartItem.getBuyType().getBuyTypeID() == 1) {
            if (cartItem.getInStockProduct() != null) {
                this.inStockProduct = InStockProductRes.convertFromEntity(cartItem.getInStockProduct());
            }
        } else {
            if (cartItem.getStatus() == false) {
//                Campaign campaign = campaignRepository.findByProductProductIDAndStatus(cartItem.getProduct().getProductID(), Status.ENDED).get();
//                this.campaignID = campaign.getCampaignID();
                if (cartItem.getInStockProduct() != null)
                    this.inStockProduct = InStockProductRes.convertFromEntity(cartItem.getInStockProduct());
            } else {
                Campaign campaign = campaignRepository.findByProductProductIDAndStatus(cartItem.getProduct().getProductID(), Status.STARTING).get();
                this.campaignID = campaign.getCampaignID();
                if (cartItem.getInStockProduct() != null) {
                    this.inStockProduct = InStockProductRes.convertFromEntity(cartItem.getInStockProduct());
                    List<InStockProduct> listInStockCampaign = inStockProductRepository.findByCampaignCampaignID(campaign.getCampaignID());
                    this.listInStockCampaign = listInStockCampaign.stream().map(s -> InStockProductRes.convertFromEntity(s)).toList();
                }
            }
        }
        //TH1: Nếu là mua riêng thì campaignID vs listInStockCampaign = null
        // Check xem só instockProduct không
        // Nếu có thì inStockProduct khác null
        // Nếu không thì inStockProduct = null.
        //TH2: Nếu là mua chung thì
        // Check status:
        // Nếu status = false thì campaignID =  null và listInStockCampaign = null
        // Check xem có inStockProduct không
        // Nếu có thì inStockProduct khác null
        // Nếu không thì inStockProduct = null
        // Nếu status = true thì campaignID khác null
        // Check xem có inStockProduct không?
        // Nếu có thì inStockProduct khác null và listInStockCampaign khác null
        // Nếu không thì inStockProduct null và listInStockCampaign = null
    }
}
