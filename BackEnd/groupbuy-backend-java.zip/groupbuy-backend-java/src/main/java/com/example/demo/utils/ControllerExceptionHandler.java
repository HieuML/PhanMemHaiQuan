package com.example.demo.utils;

import com.example.demo.constants.TextStatus;
import com.example.demo.exception.*;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import io.jsonwebtoken.JwtException;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class ControllerExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public BaseRes resourceNotFoundException(ResourceNotFoundException ex) {
        return new BaseRes<>(HttpStatus.NOT_FOUND.value(), ex.getMessage());
    }

    @ExceptionHandler(BadRequestException.class)
    public BaseRes badRequestException(BadRequestException ex) {
        return new BaseRes<>(HttpStatus.BAD_REQUEST.value(), ex.getMessage());
    }

    @ExceptionHandler(UnauthorizedException.class)
    public BaseRes unauthorizedException(UnauthorizedException ex) {
        return new BaseRes<>(HttpStatus.UNAUTHORIZED.value(), ex.getMessage());
    }

    @ExceptionHandler(ForbiddenException.class)
    public BaseRes forbiddenException(ForbiddenException ex) {
        return new BaseRes<>(HttpStatus.FORBIDDEN.value(), ex.getMessage());
    }

    @ExceptionHandler(AuthenticationException.class)
    public BaseRes authenticationException(ResourceNotFoundException ex) {
        return new BaseRes<>(HttpStatus.UNAUTHORIZED.value(), ex.getMessage());
    }

    @ExceptionHandler(JwtException.class)
    public BaseRes handleJwtException() {
        return new BaseRes(HttpStatus.UNAUTHORIZED.value(), TextStatus.INVALID_ACCESS_TOKEN);
    }
}
