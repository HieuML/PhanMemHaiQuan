package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.userReq.ChangePasswordReq;
import com.example.demo.dto.request.userReq.GetLstAllUserReq;
import com.example.demo.dto.request.walletReq.TopUpOrWithdrawReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.userService.UserService;
import com.example.demo.service.walletService.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    WalletService walletService;

    @PostMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAllUser(@RequestBody GetLstAllUserReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_USER, userService.getAll(req)));
    }

    @GetMapping(Path.GET_USER_BY_ID)
    public ResponseEntity<BaseRes> getUserById(@PathVariable Integer userID) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_USER_BY_ID, userService.getById(userID)));
    }

    @PostMapping(Path.GET_USE_BY_FIRST_NAME)
    public ResponseEntity<BaseRes> findByFirstName(@PathVariable String firstName) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_USER_BY_FIRST_NAME, userService.findByFirstName(firstName)));
    }

    @GetMapping(Path.GET_INFO_WALLET)
    public ResponseEntity<?> getInfoWalletByUser(HttpServletRequest request) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_DETAIL_WALLET_SUCCESS, userService.getInfoWalletByUser(request)));
    }

    @PostMapping(Path.TOP_UP)
    public ResponseEntity<?> topUp(HttpServletRequest request, @RequestBody TopUpOrWithdrawReq topUpOrWithdrawReq) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.DEPOSIT_SUCCESS, userService.topUp(request, topUpOrWithdrawReq)));
    }

    @PostMapping(Path.WITHDRAW)
    public ResponseEntity<?> withdraw(HttpServletRequest request, @RequestBody TopUpOrWithdrawReq topUpOrWithdrawReq) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.WITHDRAW_SUCCESS, userService.withdraw(request, topUpOrWithdrawReq)));
    }

    @PostMapping(Path.CHANGE_PASSWORD)
    public ResponseEntity<?> changePassword(HttpServletRequest request, @RequestBody ChangePasswordReq changePasswordReq) {
        return ResponseEntity.ok(userService.changePassword(request, changePasswordReq));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.UPDATE_STATUS_USER)
    public ResponseEntity<BaseRes> updateStatus(@PathVariable Integer userID) {
        return ResponseEntity.ok(userService.updateStatusUser(userID));
    }
}
