package com.example.demo.dto.response.statisticalRes.admin;

import com.example.demo.dto.response.statisticalRes.OrderStatistical;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StatisticalForAdminRes {
    private OrderStatistical orderStatistical;
    private SystemStatistical systemStatistical;
}
