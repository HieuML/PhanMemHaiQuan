package com.example.demo.dto.response.statisticalRes.admin;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.*;

@Getter
@Setter
@NoArgsConstructor
public class SystemStatistical {
    private Long sumCampaignRun;
    private Long sumProductActive;
    private Long sumUserActive;
    private Long sumShopActive;
    private Long sumUserJoinInTime;
    private Long sumShopJoinInTime;


}
