package com.example.demo.dto.request;

import lombok.Getter;

@Getter
public class PageReq {
    private Integer pageIndex;
    private Integer limit;
}
