package com.example.demo.dto.response.productRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.InStockProduct;
import com.example.demo.entities.ValueProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class InStockProductRes {
    private Integer inStockProductID;
    private IdNameRes valueProperty;
    private Integer inStock;
    private Integer campaignInStock;

    public static InStockProductRes convertFromEntity(InStockProduct inStockProduct) {
        ValueProperty valueProperty = inStockProduct.getValueProperty();
        return new InStockProductRes(inStockProduct.getInStockProductID(), new IdNameRes(valueProperty.getValuePropertyID(), valueProperty.getName()), inStockProduct.getInStock(), inStockProduct.getCampaignInStock());
    }
}
