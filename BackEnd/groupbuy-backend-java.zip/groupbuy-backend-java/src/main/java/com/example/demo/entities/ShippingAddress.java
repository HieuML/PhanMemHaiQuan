package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "shipping_address")
@Setter
@Getter
@NoArgsConstructor
public class ShippingAddress {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "shipping_address_id")
    private Integer shippingAddressID;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_inform_id", nullable = false)
    User user;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ward_id", nullable = false)
    Ward ward;
    private Boolean type;
    @Column(name = "is_default")
    private Boolean isDefault;
    @Column(name = "address_detail")
    private String addressDetail;
    @Column(name = "consignee_name")
    private String consigneeName;
    @Column
    private String street;
    @Column(length = 20)
    private String phone;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public ShippingAddress(User user, Ward ward, Boolean type, String addressDetail, String phone, String consigneeName, String street) {
        this.user = user;
        this.consigneeName = consigneeName;
        this.street = street;
        this.ward = ward;
        this.type = type;
        this.isDefault = false;
        this.addressDetail = addressDetail;
        this.phone = phone;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
    }
}
