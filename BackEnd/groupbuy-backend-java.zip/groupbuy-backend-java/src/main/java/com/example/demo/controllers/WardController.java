package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.wardService.WardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/ward")
public class WardController {
    @Autowired
    private WardService wardService;

    @GetMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAll() {
        return ResponseEntity.ok(wardService.getAll());
    }

    @GetMapping(Path.GET_WARD_BY_DISTRICT)
    public ResponseEntity<BaseRes> getByDistrict(@PathVariable Integer districtID) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(),
                TextStatus.GET_DISTRICT_BY_CITY_ID,
                wardService.getWardByDistrict(districtID)));
    }
}
