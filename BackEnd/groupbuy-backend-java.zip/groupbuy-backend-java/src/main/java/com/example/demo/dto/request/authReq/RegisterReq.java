package com.example.demo.dto.request.authReq;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

@Getter
@Setter
public class RegisterReq {
    @NotBlank
    @Size(min = 3, max = 45)
    private String username;

    @NotBlank
    private String password;

    @NotBlank
    @Size(max = 45)
    @Email
    private String email;

    @Size(max = 100)
    private String firstName;

    @Size(max = 100)
    private String lastName;

    private String gender;

    @Temporal(TemporalType.DATE)
    private Date birthday;

    @Size(max = 20)
    private String phone;
    
    @NotBlank
    private String role;
}
