package com.example.demo.service.adminService.impl;

import com.example.demo.constants.AdminAccount;
import com.example.demo.constants.RoleName;
import com.example.demo.constants.Status;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.adminReq.ConfirmOrCancelTransactionReq;
import com.example.demo.dto.request.adminReq.StatisticalReq;
import com.example.demo.dto.response.campaignRes.CampaignRes1;
import com.example.demo.dto.response.productRes.ProductRes;
import com.example.demo.dto.response.shopRes.ShopDetailRes;
import com.example.demo.dto.response.statisticalRes.OrderStatistical;
import com.example.demo.dto.response.statisticalRes.admin.StatisticalForAdminRes;
import com.example.demo.dto.response.statisticalRes.SumObjectByDate;
import com.example.demo.dto.response.statisticalRes.admin.SystemStatistical;
import com.example.demo.dto.response.statisticalRes.seller.ShopStatistical;
import com.example.demo.dto.response.statisticalRes.seller.StatisticalForSellerRes;
import com.example.demo.entities.*;
import com.example.demo.exception.*;
import com.example.demo.repository.*;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.adminService.AdminService;
import com.example.demo.utils.CommonMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private MoneyTransferActivityRepo moneyTransferActivityRepo;
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private WalletRepository walletRepository;
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ShopRepository shopRepository;

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private InStockProductRepository inStockProductRepository;

    @Autowired
    private ValuePropertyRepository valuePropertyRepository;

    @Autowired
    private PriceLevelRepository priceLevelRepository;

    @Override
    public void confirmTransaction(HttpServletRequest request, ConfirmOrCancelTransactionReq confirmOrCancelTransactionReq) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        if (!userRepository.findByUsername(username).get().getUsername().equals(AdminAccount.USERNAME)) {
            throw new ForbiddenException(TextStatus.UNAUTHORIZED);
        }
        Integer moneyTransferActivityID = confirmOrCancelTransactionReq.getMoneyTransferActivityID();
        Optional<MoneyTransferActivity> moneyTransferActivityData = moneyTransferActivityRepo.findById(moneyTransferActivityID);
        if (moneyTransferActivityData.isEmpty())
            throw new ResourceNotFoundException(TextStatus.MONEY_TRANSFER_ACTIVITY_NOT_FOUND);
        MoneyTransferActivity moneyTransferActivity = moneyTransferActivityData.get();
        if (!moneyTransferActivity.getStatus().equals(Status.WAITING_CONFIRM))
            throw new BadRequestException(TextStatus.ERROR_TRANSACTION_HAS_CONFIRMED_OR_CANCELLED);
        Integer fromUserID = moneyTransferActivity.getFromUserID();
        Integer toUserID = moneyTransferActivity.getToUserID();
        Integer amount = moneyTransferActivity.getAmount();
        if (amount > walletRepository.findByUserId(fromUserID).getMoney()) {
            if (userRepository.findById(fromUserID).get().getRole().getName().equals(RoleName.ADMIN)) {
                throw new BadRequestException(TextStatus.ADMIN_NOT_ENOUGH_MONEY);
            } else {
                moneyTransferActivity.setStatus(Status.CANCELLED);
                moneyTransferActivity.setDescription(TextStatus.USER_NOT_ENOUGH_MONEY);
                moneyTransferActivity.setUpdatedAt(new Date().getTime());
                moneyTransferActivityRepo.save(moneyTransferActivity);
            }
        } else {
            CommonMethod.moneyTransfer(fromUserID, toUserID, amount, walletRepository);
            moneyTransferActivity.setStatus(Status.CONFIRMED);
            moneyTransferActivity.setDescription(TextStatus.TRANSITION_SUCCESS_DESCRIPTION);
            moneyTransferActivity.setUpdatedAt(new Date().getTime());
            moneyTransferActivityRepo.save(moneyTransferActivity);
        }
    }



    @Override
    public StatisticalForAdminRes statisticalForAdmin(StatisticalReq req) {
        StatisticalForAdminRes statisticalForAdminRes = new StatisticalForAdminRes();
        OrderStatistical orderStatistical = new OrderStatistical();
        SystemStatistical systemStatistical = new SystemStatistical();
        //systemStatistical
        Long sumUserInTime  = Long.valueOf(0);
        Long sumShopInTime = Long.valueOf(0);
        //sumCampaignRun
        Long sumCampaignRun = campaignRepository.countByStatus(Status.STARTING);
        //sumProductActive
        Long sumProductActive =  productRepository.countByIsActiveTrue();
        //sumUserActive
        Long sumUserActive = userRepository.countByIsActiveTrue();
        //sumShopActive
        Long sumShopActive = shopRepository.countByUserIsActive(true);
        if(req.getStartTime() <= req.getEndTime()){
            //sau này nâng cấp chạy đa luồng
            sumUserInTime = userRepository.countByRoleNameAndCreatedAtBetween(RoleName.CUSTOMER, req.getStartTime(), req.getEndTime());
            sumShopInTime = shopRepository.countByCreatedAtBetween(req.getStartTime(), req.getEndTime());
        }
        systemStatistical.setSumCampaignRun(sumCampaignRun);
        systemStatistical.setSumProductActive(sumProductActive);
        systemStatistical.setSumUserActive(sumUserActive);
        systemStatistical.setSumShopActive(sumShopActive);
        systemStatistical.setSumUserJoinInTime(sumUserInTime);
        systemStatistical.setSumShopJoinInTime(sumShopInTime);

        //orderStatistical
        List<Invoice> invoicesEntities = invoiceRepository.findAll();
        //sumOrder
        Long sumOrder = Long.valueOf(invoicesEntities.size());
        //sumOrderCompleted
        Long sumOrderCompleted = invoicesEntities.stream().filter(x-> x.getStatus().equals(Status.COMPLETED)).count();
        //sumOrderCancel
        Long sumOrderCancel = invoicesEntities.stream().filter(x -> x.getStatus().equals(Status.CANCELLED)).count();
        //sumOrderReturn
        Long sumOrderReturn = invoicesEntities.stream().filter(x -> x.getStatus().equals(Status.RETURN)).count();
        List<java.sql.Date> lstDate = this.dateBetween(req.getStartTime(), req.getEndTime());
        List<SumObjectByDate> listSumOrderInTime = new ArrayList<>();
        List<SumObjectByDate> listSumOrderCompletedInTime = new ArrayList<>();
        List<SumObjectByDate> listSumOrderCancelledInTime = new ArrayList<>();
        List<SumObjectByDate> listSumOrderReturnInTime = new ArrayList<>();
        lstDate.stream().forEach(x-> {
            listSumOrderInTime.add(new SumObjectByDate(x.getTime(),
                    //SumOrderInTime
                    invoicesEntities.stream().filter(y ->
                            x.toString().equals(new java.sql.Date(y.getUpdatedAt()).toString())
                    ).count()));

            listSumOrderCompletedInTime.add(new SumObjectByDate(x.getTime(),
                    //SumOrderCompletedInTime
                    invoicesEntities.stream().filter(y ->
                           x.toString().equals(new java.sql.Date(y.getUpdatedAt()).toString())
                                   && y.getStatus().equals(Status.COMPLETED)
                    ).count()));

            listSumOrderCancelledInTime.add(new SumObjectByDate(x.getTime(),
                    //SumOrderCancelledInTime
                    invoicesEntities.stream().filter(y ->
                            x.toString().equals(new java.sql.Date(y.getUpdatedAt()).toString()) && y.getStatus().equals(Status.CANCELLED)
                    ).count()));

            listSumOrderReturnInTime.add(new SumObjectByDate(x.getTime(),
                    //SumOrderReturnInTime
                    invoicesEntities.stream().filter(y ->
                            x.toString().equals(new java.sql.Date(y.getUpdatedAt()).toString()) && y.getStatus().equals(Status.RETURN)
                    ).count()));
        });
        orderStatistical.setSumOrder(sumOrder);
        orderStatistical.setSumOrderCompleted(sumOrderCompleted);
        orderStatistical.setSumOrderCancel(sumOrderCancel);
        orderStatistical.setSumOrderReturn(sumOrderReturn);
        orderStatistical.setListSumOrderInTime(listSumOrderInTime);
        orderStatistical.setListSumOrderCompletedInTime(listSumOrderCompletedInTime);
        orderStatistical.setListSumOrderCancelledInTime(listSumOrderCancelledInTime);
        orderStatistical.setLstSumOrderReturnInTime(listSumOrderReturnInTime);

        statisticalForAdminRes.setOrderStatistical(orderStatistical);
        statisticalForAdminRes.setSystemStatistical(systemStatistical);
        return statisticalForAdminRes;
    }

    @Override
    public StatisticalForSellerRes statisticalForSeller(HttpServletRequest servletRequest, StatisticalReq req) {
        String username = CommonMethod.getUsernameFromJwt(servletRequest, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Integer shopId = shopRepository.findByUserId(userID).get().getShopID();
        StatisticalForSellerRes statisticalForSellerRes = new StatisticalForSellerRes();
        ShopStatistical shopStatistical = new ShopStatistical();
        OrderStatistical orderStatistical = new OrderStatistical();

        List<Campaign> campaignsEntitiesByShop = campaignRepository.findByShopShopID(shopId).stream()
                .sorted((a,b) -> b.getSoldQuantity().compareTo(a.getSoldQuantity())).collect(Collectors.toList());
        List<Product> productsEntitiesByShop = productRepository.findByShopShopID(shopId).stream()
                .sorted((a,b) -> b.getSoldQuantity().compareTo(a.getSoldQuantity())).collect(Collectors.toList());
        //sumCampaign
        Long sumCampaignByShop = Long.valueOf(campaignsEntitiesByShop.size());
        //sumCampaignRun
        Long sumCampaignRunByShop = campaignsEntitiesByShop.stream().filter(x -> x.getStatus().equals(Status.STARTING)).count();
        //sumProduct
        Long sumProductByShop = productsEntitiesByShop.stream().filter(x -> x.getIsActive() == true).count();
        //BestSellerCampaign
        List<CampaignRes1> lstBestSellerCampaign = new ArrayList<>();
        List<ProductRes> lstBestSellerProduct = new ArrayList<>();
        if(campaignsEntitiesByShop.size() > 0){
            Campaign campaignBestSeller = campaignsEntitiesByShop.get(0);
            lstBestSellerCampaign = campaignsEntitiesByShop
                    .stream().filter(x -> x.getSoldQuantity().equals(campaignBestSeller.getSoldQuantity()))
                    .map(x ->  {
                        ProductRes productRes = new ProductRes(x.getProduct(), inStockProductRepository, valuePropertyRepository);
                        ShopDetailRes shopDetailRes = new ShopDetailRes(x.getShop(),
                                x.getShop().getWard().getDistrict(), x.getShop().getWard().getDistrict().getCity(),
                                productRepository.findByShopShopID(x.getShop().getShopID()).size(),
                                campaignRepository.findByShopShopID(x.getShop().getShopID()).size());
                        return new CampaignRes1(x, productRes, shopDetailRes, priceLevelRepository, inStockProductRepository);
                    }).collect(Collectors.toList());
        }

        if(productsEntitiesByShop.size() > 0) {
            Product productBestSeller = productsEntitiesByShop.get(0);
            //BestSellerProduct
            lstBestSellerProduct = productsEntitiesByShop
                    .stream().filter(x -> x.getSoldQuantity().equals(productBestSeller.getSoldQuantity()))
                    .map(x ->
                            new ProductRes(x, inStockProductRepository, valuePropertyRepository)
                    ).collect(Collectors.toList());
        }

        shopStatistical.setSumCampaignByShop(sumCampaignByShop);
        shopStatistical.setSumCampaignRunByShop(sumCampaignRunByShop);
        shopStatistical.setSumProductByShop(sumProductByShop);
        shopStatistical.setBestSellerCampaign(lstBestSellerCampaign);
        shopStatistical.setBestSellerProduct(lstBestSellerProduct);

        List<Invoice> invoicesEntitiesByShop = invoiceRepository.findByShopShopID(shopId);
        //sumOrderByShop
        Long sumOrder = Long.valueOf(invoicesEntitiesByShop.size());
        //sumOrderCompletedByShop
        Long sumOrderCompleted = invoicesEntitiesByShop.stream().filter(x-> x.getStatus().equals(Status.COMPLETED)).count();
        //sumOrderCancelByShop
        Long sumOrderCancel = invoicesEntitiesByShop.stream().filter(x -> x.getStatus().equals(Status.CANCELLED)).count();
        //sumOrderReturnByShop
        Long sumOrderReturn = invoicesEntitiesByShop.stream().filter(x -> x.getStatus().equals(Status.RETURN)).count();
        List<java.sql.Date> lstDate = this.dateBetween(req.getStartTime(), req.getEndTime());
        List<SumObjectByDate> listSumOrderInTime = new ArrayList<>();
        List<SumObjectByDate> listSumOrderCompletedInTime = new ArrayList<>();
        List<SumObjectByDate> listSumOrderCancelledInTime = new ArrayList<>();
        List<SumObjectByDate> listSumOrderReturnInTime = new ArrayList<>();
        lstDate.stream().forEach(x-> {
            listSumOrderInTime.add(new SumObjectByDate(x.getTime(),
                    //SumOrderInTimeByShop
                    invoicesEntitiesByShop.stream().filter(y ->
                            x.toString().equals(new java.sql.Date(y.getUpdatedAt()).toString())
                    ).count()));

            listSumOrderCompletedInTime.add(new SumObjectByDate(x.getTime(),
                    //SumOrderCompletedInTimeByShop
                    invoicesEntitiesByShop.stream().filter(y ->
                            x.toString().equals(new java.sql.Date(y.getUpdatedAt()).toString()) && y.getStatus().equals(Status.COMPLETED)
                    ).count()));

            listSumOrderCancelledInTime.add(new SumObjectByDate(x.getTime(),
                    //SumOrderCancelledInTimeByShop
                    invoicesEntitiesByShop.stream().filter(y ->
                            x.toString().equals(new java.sql.Date(y.getUpdatedAt()).toString()) && y.getStatus().equals(Status.CANCELLED)
                    ).count()));

            listSumOrderReturnInTime.add(new SumObjectByDate(x.getTime(),
                    //SumOrderReturnInTimeByShop
                    invoicesEntitiesByShop.stream().filter(y ->
                            x.toString().equals(new java.sql.Date(y.getUpdatedAt()).toString()) && y.getStatus().equals(Status.RETURN)
                    ).count()));
        });
        orderStatistical.setSumOrder(sumOrder);
        orderStatistical.setSumOrderCompleted(sumOrderCompleted);
        orderStatistical.setSumOrderCancel(sumOrderCancel);
        orderStatistical.setSumOrderReturn(sumOrderReturn);
        orderStatistical.setListSumOrderInTime(listSumOrderInTime);
        orderStatistical.setListSumOrderCompletedInTime(listSumOrderCompletedInTime);
        orderStatistical.setListSumOrderCancelledInTime(listSumOrderCancelledInTime);
        orderStatistical.setLstSumOrderReturnInTime(listSumOrderReturnInTime);

        statisticalForSellerRes.setShopStatistical(shopStatistical);
        statisticalForSellerRes.setOrderStatisticalByShop(orderStatistical);
        return statisticalForSellerRes;
    }

    private static List<java.sql.Date> dateBetween(Long startTime, Long endTime){
        List<java.sql.Date> rs = new ArrayList<>();
        java.sql.Date startDateWithoutHours = new java.sql.Date(startTime);
        rs.add(startDateWithoutHours);
        java.sql.Date endDateWithoutHours = new java.sql.Date(endTime);
        Long startTimeFromStartDateWithoutHours = startDateWithoutHours.getTime();
        Long endTimeFromEndDateWithoutHours = endDateWithoutHours.getTime();
        if(startTimeFromStartDateWithoutHours < endTimeFromEndDateWithoutHours) {
            for (Long i = startTimeFromStartDateWithoutHours + 86400000;
                 i <= endTimeFromEndDateWithoutHours;
                 i += 86400000) {
                rs.add(new java.sql.Date(Long.valueOf(i)));
            }
        }
        return rs;
    }

}
