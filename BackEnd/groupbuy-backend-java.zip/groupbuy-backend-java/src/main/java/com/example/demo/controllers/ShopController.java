package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.userReq.GetLstAllUserReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.shopRes.ShopDetailRes;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.dto.request.UpdateShopRequest;
import com.example.demo.service.shopService.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/shop")
public class ShopController {
    @Autowired
    ShopService shopService;

    @PostMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAllShop(@RequestBody GetLstAllUserReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_USER, shopService.getAll(req)));
    }

    @PreAuthorize("hasRole('SELLER')")
    @PostMapping(Path.UPDATE)
    public ResponseEntity<?> updateShop(@RequestBody UpdateShopRequest shop) throws ResourceNotFoundException {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.UPDATE_SHOP_SUCCESS, new BaseUpdated(shopService.updateShop(shop), true)));
    }

    @GetMapping(Path.GET_DETAIL_SHOP)
    public ResponseEntity<?> getDetailShop(@PathVariable Integer shopID) {
        ShopDetailRes shopDetailRes = shopService.getDetailShop(shopID);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_DETAIL_SHOP_SUCCESS, shopDetailRes));
    }
}
