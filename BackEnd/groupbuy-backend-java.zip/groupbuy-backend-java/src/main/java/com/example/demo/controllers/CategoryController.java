package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.categoryService.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/category")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    @GetMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAll() {
        return ResponseEntity.ok(categoryService.getAll());
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<BaseRes> createCategory(@RequestBody RequestName name) {
        return ResponseEntity.ok(categoryService.create(name));
    }
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.UPDATE)
    public ResponseEntity<BaseRes> updateCategory(@RequestBody IdNameReq req){
        return ResponseEntity.ok(categoryService.update(req));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping(Path.DELETE_CATEGORY)
    public ResponseEntity<BaseRes> deleteCategory(@PathVariable Integer categoryID) {
        return ResponseEntity.ok(categoryService.delete(categoryID));
    }
}
