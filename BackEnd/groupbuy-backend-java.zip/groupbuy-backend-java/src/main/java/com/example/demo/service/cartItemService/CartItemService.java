package com.example.demo.service.cartItemService;

import com.example.demo.dto.request.cartItemReq.*;
import com.example.demo.dto.request.cartItemReq.CreateOrUpdateCartItemReq;
import com.example.demo.dto.response.cartItemRes.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface CartItemService {
    CartItemRes createCartItem(HttpServletRequest request, CreateOrUpdateCartItemReq cartItem);

    List<GetAllCartItemByUserRes> getAllCartItemByUser(HttpServletRequest request);

    void deleteCartItem(HttpServletRequest request, Integer cartItemID);

    void changeQuantity(HttpServletRequest request, ChangeQuantityReq changeQuantityReq);

    void changeProperty(HttpServletRequest request, ChangePropertyReq changePropertyReq);

    Integer getShippingFee(GetShippingFeeReq getShippingFeeReq) throws Exception;

    List<ListCartItemCheckoutRes> getListCartItemCheckout(HttpServletRequest request, CheckoutReq checkoutReq);
}
