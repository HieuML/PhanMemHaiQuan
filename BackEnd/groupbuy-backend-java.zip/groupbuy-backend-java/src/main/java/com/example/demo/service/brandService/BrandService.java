package com.example.demo.service.brandService;

import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import org.springframework.stereotype.Service;

@Service
public interface BrandService {
    /**
     * get all brand
     *
     * @return
     */
    BaseRes getAll();

    /**
     * create brand
     *
     * @param name
     * @return
     */
    BaseRes create(RequestName name);

    /**
     * update brand
     * @param req
     * @return
     */
    BaseRes update(IdNameReq req);

    /**
     * delete brand
     * @param brandID
     * @return
     */
    BaseRes delete(Integer brandID);
}
