package com.example.demo.dto.request;

import com.example.demo.dto.response.IdNameRes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class IdNameReq extends IdNameRes {
    public IdNameReq(Integer id, String name) {
        super(id, name);
    }
}
