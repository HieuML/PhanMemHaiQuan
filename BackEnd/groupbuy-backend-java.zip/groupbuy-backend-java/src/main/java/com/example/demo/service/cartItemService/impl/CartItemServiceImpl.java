package com.example.demo.service.cartItemService.impl;

import com.example.demo.constants.RoleName;
import com.example.demo.constants.Status;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.GetDistanceReq;
import com.example.demo.dto.request.cartItemReq.*;
import com.example.demo.dto.response.IdNameRes;
import com.example.demo.dto.response.cartItemRes.*;
import com.example.demo.entities.*;
import com.example.demo.exception.*;
import com.example.demo.dto.request.cartItemReq.CreateOrUpdateCartItemReq;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.*;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.campaignService.CampaignService;
import com.example.demo.service.cartItemService.CartItemService;
import com.example.demo.service.commonService.CommonService;
import com.example.demo.utils.CommonMethod;
import org.hibernate.annotations.Check;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@Service
public class CartItemServiceImpl implements CartItemService {
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    CartItemRepository cartItemRepository;
    @Autowired
    ShoppingCartRepository shoppingCartRepository;
    @Autowired
    BuyTypeRepository buyTypeRepository;
    @Autowired
    CampaignRepository campaignRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    CommonService commonService;
    @Autowired
    InStockProductRepository inStockProductRepository;
    @Autowired
    ValuePropertyRepository valuePropertyRepository;
    @Autowired
    ShippingAddressRepository shippingAddressRepository;

    @Autowired
    CampaignService campaignService;

    public CartItemRes createCartItem(HttpServletRequest request, CreateOrUpdateCartItemReq cartItemReq) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Optional<ShoppingCart> shoppingCart = shoppingCartRepository.findByUserId(userID);
        if (shoppingCart.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOPPING_CART_NOT_FOUND);
        }
        //Kiểm tra xem đã truyền quantity chưa
        if (cartItemReq.getQuantity() == null) {
            throw new BadRequestException(TextStatus.MISSING_QUANTITY);
        }
        Boolean buySeparatelyCheck;
        Product product;
        Campaign campaign = null;
        InStockProduct inStockProduct = null;
        BuyType buySeparatly = buyTypeRepository.findById(1).get();
        BuyType buyTogether = buyTypeRepository.findById(2).get();
        // Tìm ra sản phẩm đó và campaign đó
        if (cartItemReq.getId().startsWith("PD")) {
            buySeparatelyCheck = true;
            //Kiểm tra xem có tồn tại sản phấm đó ko
            Optional<Product> productData = productRepository.findById(cartItemReq.getId());
            if (productData.isEmpty()) {
                throw new ResourceNotFoundException(TextStatus.PRODUCT_NOT_FOUND);
            }
            product = productData.get();
        } else if (cartItemReq.getId().startsWith("CP")) {
            buySeparatelyCheck = false;
            Optional<Campaign> campaignData = campaignRepository.findById(cartItemReq.getId());
            if (campaignData.isEmpty()) {
                throw new ResourceNotFoundException(TextStatus.CAMPAIGN_NOT_FOUND);
            }
            campaign = campaignData.get();
            product = campaign.getProduct();
            if (!campaign.getStatus().equals(Status.STARTING))
                throw new BadRequestException(TextStatus.CAMPAIGN_NOT_STARTING);
        } else throw new ResourceNotFoundException(TextStatus.ID_INVALID);
        //Check xem sản phầm còn đang bán ko
        if (!product.getIsActive()) throw new BadRequestException(TextStatus.PRODUCT_NOT_ACTIVE);
        Boolean hasPropertyCheck = false;
        List<InStockProduct> listInStockProduct = inStockProductRepository.findByProductProductID(product.getProductID());
        if (listInStockProduct.size() > 0) {
            hasPropertyCheck = true;
            if (cartItemReq.getInStockProductID() == null)
                throw new BadRequestException(TextStatus.MISSING_IN_STOCK_PRODUCT);
            Optional<InStockProduct> inStockProductData = inStockProductRepository.findById(cartItemReq.getInStockProductID());
            if (inStockProductData.isEmpty())
                throw new ResourceNotFoundException(TextStatus.IN_STOCK_PRODUCT_NOT_FOUND);
            inStockProduct = inStockProductData.get();
            if (listInStockProduct.stream().noneMatch(s -> s.getInStockProductID().equals(cartItemReq.getInStockProductID())))
                throw new BadRequestException(TextStatus.IN_STOCK_INVALID);
        }
        Optional<CartItem> cartItemData;
        Integer shoppingCartID = shoppingCart.get().getShoppingCartID();
        String productID = product.getProductID();
        CartItem newCartItem = null;
        if (buySeparatelyCheck && !hasPropertyCheck) {
            //Kiểm tra quantity
            if (cartItemReq.getQuantity() > product.getInStock())
                throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
            //Kiểm tra xem đã có trong shoppingCart chưa
            cartItemData = cartItemRepository.findByShoppingCartShoppingCartIDAndProductProductIDAndBuyTypeBuyTypeID(shoppingCartID, productID, 1);
            if (cartItemData.isEmpty()) {
                newCartItem = new CartItem(shoppingCart.get(), product, buySeparatly, null, cartItemReq.getQuantity(), product.getPrice(), 0);
                cartItemRepository.save(newCartItem);
            } else {
                newCartItem = cartItemData.get();
                newCartItem.addQuantity(cartItemReq.getQuantity());
                //Kiểm tra lại quantity của cartItem có lớn hơn inStock k
                if (newCartItem.getQuantity() > product.getInStock())
                    throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
                newCartItem.setUpdatedAt(new Date().getTime());
                cartItemRepository.save(newCartItem);
            }
        } else if (buySeparatelyCheck && hasPropertyCheck) {
            Integer inStockProductID = inStockProduct.getInStockProductID();
            //Kiểm tra quantity
            if (cartItemReq.getQuantity() > inStockProduct.getInStock())
                throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
            //Kiểm tra xem đã có trong shoppingCart chưa
            cartItemData = cartItemRepository.findByShoppingCartShoppingCartIDAndProductProductIDAndBuyTypeBuyTypeIDAndInStockProductInStockProductID(shoppingCartID, productID, 1, inStockProductID);
            if (cartItemData.isEmpty()) {
                newCartItem = new CartItem(shoppingCart.get(), product, buySeparatly, inStockProduct, cartItemReq.getQuantity(), product.getPrice(), 0);
                cartItemRepository.save(newCartItem);
            } else {
                newCartItem = cartItemData.get();
                newCartItem.addQuantity(cartItemReq.getQuantity());
                //Kiểm tra lại quantity của cartItem có lớn hơn inStock k
                if (newCartItem.getQuantity() > inStockProduct.getInStock())
                    throw new BadRequestException(TextStatus.IN_STOCK_OF_PROPERTY_NOT_ENOUGH);
                newCartItem.setUpdatedAt(new Date().getTime());
                cartItemRepository.save(newCartItem);
            }
        } else if (!buySeparatelyCheck && !hasPropertyCheck) {
            //Kiểm tra quantity
            if (cartItemReq.getQuantity() > campaign.getInStock())
                throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
            //Kiểm tra xem đã có trong shoppingCart chưa
            cartItemData = cartItemRepository.findByShoppingCartShoppingCartIDAndProductProductIDAndBuyTypeBuyTypeID(shoppingCartID, productID, 2);
            if (cartItemData.isEmpty()) {
                newCartItem = cartItemRepository.save(new CartItem(shoppingCart.get(), product, buyTogether, null, cartItemReq.getQuantity(), campaign.getPriceCurrent(), campaign.getDeposit()));
                cartItemRepository.save(newCartItem);
            } else {
                newCartItem = cartItemData.get();
                newCartItem.addQuantity(cartItemReq.getQuantity());
                if (newCartItem.getQuantity() > campaign.getInStock())
                    throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
                newCartItem.setUpdatedAt(new Date().getTime());
                cartItemRepository.save(newCartItem);
            }
        } else {
            Integer inStockProductID = inStockProduct.getInStockProductID();
            //Kiểm tra quantity
            if (cartItemReq.getQuantity() > inStockProduct.getCampaignInStock())
                throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
            //Kiểm tra xem đã có trong shoppingCart chưa
            cartItemData = cartItemRepository.findByShoppingCartShoppingCartIDAndProductProductIDAndBuyTypeBuyTypeIDAndInStockProductInStockProductID(shoppingCartID, productID, 2, inStockProductID);
            if (cartItemData.isEmpty()) {
                newCartItem = new CartItem(shoppingCart.get(), product, buyTogether, inStockProduct, cartItemReq.getQuantity(), campaign.getPriceCurrent(), campaign.getDeposit());
                cartItemRepository.save(newCartItem);
            } else {
                newCartItem = cartItemData.get();
                newCartItem.addQuantity(cartItemReq.getQuantity());
                if (newCartItem.getQuantity() > inStockProduct.getCampaignInStock())
                    throw new BadRequestException(TextStatus.IN_STOCK_OF_PROPERTY_NOT_ENOUGH);
                newCartItem.setUpdatedAt(new Date().getTime());
                cartItemRepository.save(newCartItem);
            }
        }
        return new CartItemRes(newCartItem, campaignRepository, inStockProductRepository, valuePropertyRepository);
        // Kiểm tra xem đã có trong giỏ hàng chưa xong rổi tạo cartItem
        // TH1: Mua riêng và sản phầm đó không có property
        // Kiểm tra xem quantity của cartItem có vượt quá instock của product
        // thì tìm kiếm trong giỏ hàng xem có cartItem nào
        //  mà có productID đó và byteType = 1 thì cộng quantity vào cartItem đó nếu ko thì tạo cartItem mới
        // TH2: Mua riêng và sản phẩm đó có property
        // Thì kiểm tra quantity của cartItem có vượt qua instock của InstockProduct đó ko
        // thì tìm trong giỏ hàng xem có cartItem nào có productID đó ko
        // và byteType = 1 và có InStockProductID đó thì cộng quantity vào cartItem đó nếu không thì tạo cartItem mới
        // TH3: Nếu là mua chung và không có property
        //Kểm tra xem quantity của cartItem có vượt quá instock của campaign ko
        //thì tìm kiếm trong giỏ hàng xem có cartItem nào
        // mà có productID đó và byteType = 2 thì cộng quantity vào cartItem đó nếu ko thì tạo cartItem mới
        // TH4: Nếu là mua chung và có property
        // Kiểm tra xem quantity của cartItem có vượt quá campaign in stock của InStockProduct đó ko
        // thì tìm kiếm trong giỏ hàng xem có cartItem nào
        // mà có productID đó và byteType = 2 và có InStockProductID đó thì cộng quantity vào cartItem đó nếu ko thì tạo cartItem mới
    }

    @Override
    public List<GetAllCartItemByUserRes> getAllCartItemByUser(HttpServletRequest request) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.USER_NOT_FOUND);
        }
        Integer userID = user.get().getId();
        Set<Integer> setShopID = new HashSet<>();
        List<GetAllCartItemByUserRes> listData = new ArrayList<>();
        Optional<ShoppingCart> shoppingCart = shoppingCartRepository.findByUserId(userID);
        if (shoppingCart.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOPPING_CART_NOT_FOUND);
        }

        List<CartItem> listCartItem = cartItemRepository.findByShoppingCartShoppingCartID(shoppingCart.get().getShoppingCartID());

        //Sắp xếp theo thời gian tạo
        listCartItem = listCartItem.stream().sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt())).collect(Collectors.toList());
        listCartItem.forEach(s -> {
                    setShopID.add(s.getProduct().getShop().getShopID());
//                    Check status campaign
                    Optional<Campaign> _campaign = campaignRepository.findByProductProductIDAndStatus(s.getProduct().getProductID(), Status.STARTING);
                    if (_campaign.isPresent()) {
                        campaignService.checkStatusCampaign(_campaign.get().getCampaignID());
                    }
                }
        );
        Iterator<Integer> iterator = setShopID.iterator();
        while (iterator.hasNext()) {
            List<CartItemRes> listCartItemRes = new ArrayList<>();
            Integer shopID = iterator.next();
            AtomicReference<Integer> totalItem = new AtomicReference<>(0);

            listCartItem.stream().filter(s -> s.getProduct().getShop().getShopID() == shopID).forEach(s -> {
                totalItem.getAndSet(totalItem.get() + 1);
                listCartItemRes.add(new CartItemRes(s, campaignRepository, inStockProductRepository, valuePropertyRepository));
            });
            listData.add(new GetAllCartItemByUserRes(shopRepository.findById(shopID).get(), listCartItemRes, totalItem.get()));
        }
        return listData;
    }

    public Integer getSumDeposit(List<CartItem> listCartItem) {
        AtomicReference<Integer> sumDeposit = new AtomicReference<>(0);
        listCartItem.stream().forEach(s -> {
            sumDeposit.updateAndGet(v -> v + s.getDeposit() * s.getQuantity());
        });
        return sumDeposit.get();
    }

    public Integer getShippingFee(GetShippingFeeReq getShippingFeeReq) throws Exception {
        Integer shopID = getShippingFeeReq.getShopID();
        Integer shippingFee;
        String userLocation = getShippingFeeReq.getUserLocation().replaceAll(" ", "").trim();
        Ward wardShop = shopRepository.findById(shopID).get().getWard();
        String shopLocation = (wardShop.getName() + "," + wardShop.getDistrict().getName() + "," + wardShop.getDistrict().getCity().getName()).replaceAll(" ", "").trim();
        Long distance = commonService.getDistance(new GetDistanceReq(userLocation, shopLocation));
        if (distance <= 5000) {
            shippingFee = 10000;
        } else if (distance <= 50000) {
            shippingFee = 25000;
        } else if (distance <= 100000) {
            shippingFee = 50000;
        } else if (distance <= 300000) {
            shippingFee = 50000 + distance.intValue() * 500 / 1000;
        } else if (distance <= 1000000) {
            shippingFee = 50000 + distance.intValue() * 100 / 1000;
        } else {
            shippingFee = 50000 + distance.intValue() * 50 / 1000;
        }
        if (getShippingFeeReq.getDeliveryID() == 1) {
            return shippingFee;
        }
        return shippingFee + 30000;
    }

    Integer getSumPrice(List<CartItem> listCartItem) {
        AtomicReference<Integer> sumPrice = new AtomicReference<>(0);
        listCartItem.stream().forEach(s -> {
            sumPrice.updateAndGet(v -> v + s.getPriceCurrent() * s.getQuantity());
        });
        return sumPrice.get();
    }

    public boolean testOwnCartItem(HttpServletRequest request, Integer cartItemID) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Optional<ShoppingCart> shoppingCart = shoppingCartRepository.findByUserId(userID);
        if (shoppingCart.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOPPING_CART_NOT_FOUND);
        }
        List<CartItem> listCartItem = cartItemRepository.findByShoppingCartShoppingCartID(shoppingCart.get().getShoppingCartID());
        return listCartItem.stream().anyMatch(s -> s.getCartItemId().equals(cartItemID));
    }

    @Override
    public void deleteCartItem(HttpServletRequest request, Integer cartItemID) {
        Optional<CartItem> cartItemData = cartItemRepository.findById(cartItemID);
        if (cartItemData.isPresent()) {
            if (!testOwnCartItem(request, cartItemID)) throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            cartItemRepository.deleteById(cartItemID);
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_CART_ITEM_ERROR);
        }
    }

    @Override
    public void changeQuantity(HttpServletRequest request, ChangeQuantityReq changeQuantityReq) {
        Optional<CartItem> cartItemData = cartItemRepository.findById(changeQuantityReq.getCartItemID());
        if (cartItemData.isEmpty()) throw new ResourceNotFoundException(TextStatus.CART_ITEM_NOT_FOUND);
        if (!testOwnCartItem(request, changeQuantityReq.getCartItemID()))
            throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
        CartItem cartItem_ = cartItemData.get();
        Product product = cartItem_.getProduct();
        Boolean buySeparatelyCheck;
        Boolean hasPropertyCheck;
        buySeparatelyCheck = cartItem_.getBuyType().getBuyTypeID() == 1;
        hasPropertyCheck = cartItem_.getInStockProduct() != null;
        if (buySeparatelyCheck && !hasPropertyCheck) {
            if (changeQuantityReq.getQuantity() > product.getInStock())
                throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
        } else if (buySeparatelyCheck && hasPropertyCheck) {
            InStockProduct inStockProduct = cartItem_.getInStockProduct();
            if (changeQuantityReq.getQuantity() > inStockProduct.getInStock())
                throw new BadRequestException(TextStatus.IN_STOCK_OF_PROPERTY_NOT_ENOUGH);
        } else if (!buySeparatelyCheck && !hasPropertyCheck) {
            if (changeQuantityReq.getQuantity() > product.getInStock())
                throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
        } else {
            InStockProduct inStockProduct = cartItem_.getInStockProduct();
            if (changeQuantityReq.getQuantity() > inStockProduct.getInStock())
                throw new BadRequestException(TextStatus.IN_STOCK_NOT_ENOUGH);
        }
        cartItem_.setQuantity(changeQuantityReq.getQuantity());
        cartItem_.setStatus(true);
        cartItem_.setUpdatedAt(new Date().getTime());
        cartItemRepository.save(cartItem_);
        // TH1. CartItem đó là mua riêng cà không có property thì sẽ check lại quantity có vượt quá instock của sản phẩm không nếu vượt quá thif thông báo ra ỗi
        // nếu ko thì update lại quantity
        // TH2. CartItem đó là mua riêng và có property thì sẽ
        // check xem property đó có tồn tại không
        // check xem sản phẩm đó có property đó ko
        // kiểm tra xem quantity có vượt qua instock của property đó ko
        // Nếu thoả mãn hết thì cập nhật lại instock cho nó và quantity cho nó
        // TH3. CartItem đó là mua chung và không có campaign thì sẽ check lại quantity có vượt quá inStock của campaign ko nếu vượt => lỗi
        //TH4. CartItem đó là mua chung và có property thì sẽ
        //Check xem instock đó có tồn tại ko
        //Check xem campaign đó có chứa property đó ko
    }

    @Override
    public void changeProperty(HttpServletRequest request, ChangePropertyReq changePropertyReq) {
        Optional<CartItem> cartItemData = cartItemRepository.findById(changePropertyReq.getCartItemID());
        if (cartItemData.isEmpty()) throw new ResourceNotFoundException(TextStatus.CART_ITEM_NOT_FOUND);
        if (!testOwnCartItem(request, changePropertyReq.getCartItemID()))
            throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
        Optional<InStockProduct> inStockProductData = inStockProductRepository.findById(changePropertyReq.getInStockProductID());
        if (inStockProductData.isEmpty()) throw new ResourceNotFoundException(TextStatus.PROPERTY_NOT_FOUND);
        InStockProduct inStockProduct = inStockProductData.get();
        CartItem cartItem_ = cartItemData.get();
        Product product = cartItem_.getProduct();
        if (cartItem_.getInStockProduct() != null) {
            if (inStockProductRepository.findByProductProductIDAndInStockProductID(product.getProductID(), inStockProduct.getInStockProductID()).isEmpty())
                throw new BadRequestException(TextStatus.IN_STOCK_PROPERTY_INVALID);
            if (cartItem_.getBuyType().getBuyTypeID() == 1) {
                if (cartItem_.getQuantity() > inStockProduct.getInStock())
                    throw new BadRequestException(TextStatus.IN_STOCK_OF_PROPERTY_NOT_ENOUGH);
            } else {
                Campaign campaign = campaignRepository.findByProductProductIDAndStatus(product.getProductID(), Status.STARTING).get();
                if (inStockProductRepository.findByProductProductIDAndInStockProductIDAndCampaignCampaignID(product.getProductID(), inStockProduct.getInStockProductID(), campaign.getCampaignID()).isEmpty())
                    throw new BadRequestException(TextStatus.CAMPAIGN_NOT_HAVE_PROPERTY);
                if (cartItem_.getQuantity() > inStockProduct.getCampaignInStock())
                    throw new BadRequestException(TextStatus.IN_STOCK_OF_PROPERTY_NOT_ENOUGH);
            }
            cartItem_.setInStockProduct(inStockProduct);
            cartItem_.setUpdatedAt(new Date().getTime());
            cartItemRepository.save(cartItem_);
        } else throw new BadRequestException(TextStatus.CART_ITEM_NOT_HAVE_PROPERTY);
    }

    @Override
    public List<ListCartItemCheckoutRes> getListCartItemCheckout(HttpServletRequest request, CheckoutReq checkoutReq) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isEmpty() || !(user.get().getRole().getName().equals(RoleName.CUSTOMER))) {
            throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
        }
        if (checkoutReq.getUserLocation().isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.ERROR_GET_DEFAULT_SHIPPING_ADDRESS);
        }
        //Tìm ra listCartItem từ listCartItemID
        List<CartItem> listCartItem = new ArrayList<>();
        checkoutReq.getListCartItemID().stream().forEach(s -> {
            listCartItem.add(cartItemRepository.findById(s).get());
        });
        Map<Shop, List<CartItem>> mapShopAndLstCartItem = new HashMap<>();
        listCartItem.stream().forEach(s -> {
            Shop shop = s.getProduct().getShop();
            if (!mapShopAndLstCartItem.containsKey(shop)) {
                List<CartItem> listCartItem1 = listCartItem.stream().filter(
                        a -> a.getProduct().getShop().getShopID() == shop.getShopID()
                                && a.getBuyType().getBuyTypeID() == 1).toList();
                if (listCartItem1.size() > 0)
                    mapShopAndLstCartItem.put(shop, listCartItem1);

                List<CartItem> listCartItem2 = listCartItem.stream().filter(
                        a -> a.getProduct().getShop().getShopID() == shop.getShopID()
                                && a.getBuyType().getBuyTypeID() == 2).toList();
                if (listCartItem1.size() > 0 && listCartItem2.size() > 0) {
                    mapShopAndLstCartItem.put(new Shop(shop.getShopID(), shop.getName()), listCartItem2);
                } else if (listCartItem2.size() > 0) mapShopAndLstCartItem.put(shop, listCartItem2);
            }
        });
        AtomicReference<Integer> shippingFee = new AtomicReference<>(0);
        AtomicReference<Integer> sumDeposit = new AtomicReference<>(0);
        AtomicReference<Integer> sumPrice = new AtomicReference<>(0);
        List<ListCartItemCheckoutRes> response = new ArrayList<>();
        //Tính userLocation
        String userLocation = checkoutReq.getUserLocation();
        mapShopAndLstCartItem.entrySet().stream().forEach(s -> {
            List<CartItem> listCartItemOfShop = s.getValue();
            //Tính shippingFee
            Boolean testCalculateShippingFee = true;
            try {
                shippingFee.set(getShippingFee(new GetShippingFeeReq(userLocation, s.getKey().getShopID(), 1)));
            } catch (Exception e) {
                testCalculateShippingFee = false;
            }
            if (!testCalculateShippingFee)
                throw new BadRequestException(TextStatus.CALCULATE_SHIPPING_FEE_ERROR);
            //Tính sumDeposit và sumPrice
            if (listCartItemOfShop.get(0).getBuyType().getBuyTypeID() == 2)
                sumDeposit.set(getSumDeposit(listCartItemOfShop));
            sumPrice.set(getSumPrice(listCartItemOfShop));
            response.add(new ListCartItemCheckoutRes(new IdNameRes(s.getKey().getShopID(), s.getKey().getName()),
                    s.getValue().stream().map(y -> new CartItemRes(y, campaignRepository, inStockProductRepository, valuePropertyRepository)).toList(), sumDeposit.get(), shippingFee.get(), sumPrice.get(), s.getValue().get(0).getBuyType().getBuyTypeID(), 1));
        });
        return response;
    }
}


