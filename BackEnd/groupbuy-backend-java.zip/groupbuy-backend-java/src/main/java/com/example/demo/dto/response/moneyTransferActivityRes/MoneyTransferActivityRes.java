package com.example.demo.dto.response.moneyTransferActivityRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.MoneyTransferActivity;
import com.example.demo.repository.UserRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class MoneyTransferActivityRes {
    private Integer moneyTransferID;
    private IdNameRes fromUser;
    private IdNameRes toUser;
    private Integer amount;
    private String status;
    private String description;
    private Long createdAt;
    private Long updatedAt;
    
    public static MoneyTransferActivityRes convertFromEntity(MoneyTransferActivity object, UserRepository userRepository) {
        IdNameRes fromUser = null;
        IdNameRes toUser = null;
        if (object.getFromUserID() != null) {
            fromUser = new IdNameRes(object.getFromUserID(), userRepository.findById(object.getFromUserID()).get().getUsername());
        }
        if (object.getToUserID() != null) {
            toUser = new IdNameRes(object.getToUserID(), userRepository.findById(object.getToUserID()).get().getUsername());
        }
        return new MoneyTransferActivityRes(object.getMoneyTransferID(), fromUser, toUser,
                object.getAmount(), object.getStatus(), object.getDescription(), object.getCreatedAt(), object.getUpdatedAt());
    }
}
