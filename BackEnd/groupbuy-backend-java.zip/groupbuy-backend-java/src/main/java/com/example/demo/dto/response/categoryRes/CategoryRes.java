package com.example.demo.dto.response.categoryRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Category;

public class CategoryRes extends IdNameRes {
    public CategoryRes(Integer id, String name) {
        super(id, name);
    }

    public static CategoryRes convertFromEntity(Category category) {
        return new CategoryRes(category.getCategoryID(), category.getName());
    }
}
