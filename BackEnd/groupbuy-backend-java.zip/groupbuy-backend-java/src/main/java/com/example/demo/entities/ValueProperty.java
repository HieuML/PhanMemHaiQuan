package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "value_property")
@Setter
@Getter
@NoArgsConstructor
public class ValueProperty {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "value_property_id")
    private Integer valuePropertyID;
    private String name;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "property_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Property property;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public ValueProperty(String name, Property property) {
        this.name = name;
        this.property = property;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
    }
}
