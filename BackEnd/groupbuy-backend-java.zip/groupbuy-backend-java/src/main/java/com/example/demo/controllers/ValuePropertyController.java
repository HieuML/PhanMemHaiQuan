package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyCreateReq;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyUpdateReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.valuePropertyService.ValuePropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/value-property")
public class ValuePropertyController {
    @Autowired
    private ValuePropertyService valuePropertyService;

    @GetMapping(Path.GET_BY_PROPERTY_ID)
    public ResponseEntity<?> getAllValueOfProperty(@PathVariable Integer propertyID) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_VALUE_PROPERTY_SUCCESS, valuePropertyService.getAllValueOfProperty(propertyID)));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<BaseRes> createValueProperty(@RequestBody ValuePropertyCreateReq req) {
        return ResponseEntity.ok(valuePropertyService.create(req));
    }
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.UPDATE)
    public ResponseEntity<BaseRes> updateValueProperty(@RequestBody ValuePropertyUpdateReq req){
        return ResponseEntity.ok(valuePropertyService.update(req));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping(Path.DELETE_VALUE_PROPERTY)
    public ResponseEntity<BaseRes> deleteValueProperty(@PathVariable Integer valuePropertyID){
        return ResponseEntity.ok(valuePropertyService.delete(valuePropertyID));
    }
}
