package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "inStock_product")
@Setter
@Getter
@NoArgsConstructor
public class InStockProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "inStock_product_id")
    private Integer inStockProductID;
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "product_id", nullable = true)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Product product;
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "campaign_id", nullable = true)
    private Campaign campaign;
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "value_property_id", nullable = true)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private ValueProperty valueProperty;
    private Integer inStock;
    private Integer campaignInStock;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public InStockProduct(Integer inStock, Product product, ValueProperty valueProperty) {
        this.inStock = inStock;
        this.product = product;
        this.valueProperty = valueProperty;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
        product.setInStock(product.getInStock() + inStock);
    }
}
