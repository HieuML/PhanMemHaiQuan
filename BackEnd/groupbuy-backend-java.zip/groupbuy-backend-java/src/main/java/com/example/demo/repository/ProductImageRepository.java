package com.example.demo.repository;

import com.example.demo.entities.ProductImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;

@Transactional
public interface ProductImageRepository extends JpaRepository<ProductImage, Integer> {
    @Transactional
    void deleteByProductProductID(String productID);

    ArrayList<ProductImage> findByProductProductID(String productID);
}