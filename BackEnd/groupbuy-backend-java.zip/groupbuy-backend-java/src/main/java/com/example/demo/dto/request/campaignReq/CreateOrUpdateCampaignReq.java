package com.example.demo.dto.request.campaignReq;

import com.example.demo.dto.request.priceLevelRequest.PriceLevelReq;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
public class CreateOrUpdateCampaignReq {
    private String name;
    private Integer deposit;
    private Long startTime;
    private Long endTime;
    private String productID;
    private Integer inStock;
    private ArrayList<PriceLevelReq> listPriceLevel;
    private ArrayList<InStockProductCreCam> listInStock;
}
