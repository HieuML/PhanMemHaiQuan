package com.example.demo.service.deliveryService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.deliveryRes.DeliveryRes;
import com.example.demo.dto.response.originRes.OriginRes;
import com.example.demo.entities.Delivery;
import com.example.demo.entities.Origin;
import com.example.demo.repository.DeliveryRepository;
import com.example.demo.service.deliveryService.DeliveryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class DeliveryServiceImpl implements DeliveryService {

    @Autowired
    private DeliveryRepository deliveryRepository;

    @Override
    @Transactional
    public BaseRes getAll() {
        try {
            return new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_DELIVERY_SUCCESS,
                    deliveryRepository.findAll()
                            .stream()
                            .map(x -> DeliveryRes.convertFromEntity(x))
                            .collect(Collectors.toList()));
        } catch (Exception error) {
            return new BaseRes<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), TextStatus.INTERNAL_SERVER_ERROR, null);
        }
    }

    @Override
    public BaseRes create(RequestName name) {
        Optional<Delivery> entity = deliveryRepository.findByName(name.getName());
        if (entity.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(), TextStatus.NAME_HAS_EXISTED, null);
        Delivery newDelivery = new Delivery(name.getName());
        newDelivery.setCreatedAt(new Date().getTime());
        newDelivery.setUpdatedAt(new Date().getTime());
        deliveryRepository.save(newDelivery);
        return new BaseRes(HttpStatus.OK.value(), TextStatus.CREATE_SUCCESS, DeliveryRes.convertFromEntity(deliveryRepository.findByName(name.getName()).get())
        );
    }

    @Override
    public BaseRes update(IdNameReq req) {
        Optional<Delivery> entity = deliveryRepository.findById(req.getId());
        Optional<Delivery> deliveryHasSameName = deliveryRepository.findByName(req.getName());
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);

        if (deliveryHasSameName.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(),
                    TextStatus.NAME_HAS_EXISTED,
                    null);

        Delivery entityUpdate = entity.get();
        entityUpdate.setName(req.getName());
        entityUpdate.setUpdatedAt(new Date().getTime());
        deliveryRepository.save(entityUpdate);
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.UPDATE_SUCCESS,
                new BaseUpdated<>(entityUpdate.getDeliveryID(), true)
        );
    }

    @Override
    public BaseRes delete(Integer categoryID) {
        Optional<Delivery> entity = deliveryRepository.findById(categoryID);
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);

        deliveryRepository.delete(entity.get());
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.DELETE_SUCCESS,
                new BaseUpdated<>(entity.get().getDeliveryID(), true));
    }
}
