package com.example.demo.dto.response.cityRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.City;

public class CityRes extends IdNameRes {
    public CityRes(Integer id, String name) {
        super(id, name);
    }

    public static CityRes convertFromEntity(City city) {
        return new CityRes(city.getCityID(), city.getName());
    }
}
