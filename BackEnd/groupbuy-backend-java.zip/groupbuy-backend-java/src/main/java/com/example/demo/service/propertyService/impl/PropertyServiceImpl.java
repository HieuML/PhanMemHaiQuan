package com.example.demo.service.propertyService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.originRes.OriginRes;
import com.example.demo.dto.response.propertyRes.PropertyRes;
import com.example.demo.entities.Origin;
import com.example.demo.entities.Property;
import com.example.demo.repository.PropertyRepository;
import com.example.demo.service.propertyService.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyServiceImpl implements PropertyService {
    @Autowired
    private PropertyRepository propertyRepository;

    @Override
    public List<PropertyRes> getAllProperty() {
        return propertyRepository.findAll().stream().map(s -> PropertyRes.convertFromEntity(s)).toList();
    }

    @Override
    public BaseRes create(RequestName requestName) {
        Optional<Property> entity = propertyRepository.findByName(requestName.getName());
        if (entity.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(), TextStatus.NAME_HAS_EXISTED, null);
        Property newProperty = new Property();
        newProperty.setName(requestName.getName());
        newProperty.setCreatedAt(new Date().getTime());
        newProperty.setUpdatedAt(new Date().getTime());
        propertyRepository.save(newProperty);
        return new BaseRes(HttpStatus.OK.value(), TextStatus.CREATE_SUCCESS, PropertyRes.convertFromEntity(propertyRepository.findByName(requestName.getName()).get())
        );
    }

    @Override
    public BaseRes update(IdNameReq req) {
        Optional<Property> entity = propertyRepository.findById(req.getId());
        Optional<Property> propertyHasSameName = propertyRepository.findByName(req.getName());
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);

        if (propertyHasSameName.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(),
                    TextStatus.NAME_HAS_EXISTED,
                    null);

        Property entityUpdate = entity.get();
        entityUpdate.setName(req.getName());
        entityUpdate.setUpdatedAt(new Date().getTime());
        propertyRepository.save(entityUpdate);
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.UPDATE_SUCCESS,
                new BaseUpdated<>(entityUpdate.getPropertyID(), true)
        );
    }
}
