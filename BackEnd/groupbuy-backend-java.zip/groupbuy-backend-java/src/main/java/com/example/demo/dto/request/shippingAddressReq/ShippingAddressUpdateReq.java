package com.example.demo.dto.request.shippingAddressReq;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShippingAddressUpdateReq extends ShippingAddressCreateReq {
    private Integer shippingAddressID;
}
