package com.example.demo.constants;

public interface Path {
    // Crud
    String GET_ALL = "/get-all";
    String CREATE = "/create";
    String UPDATE = "/update";
    String DELETE = "/delete";

    //share
    String GET_BY_SHOP = "/get-by-shop";
    String GET_BY_USER = "/get-by-user";
    // Auth
    String LOGIN = "/login";
    String REGISTER = "/register";
    String INFO = "/info";
    String LOGOUT = "/logout";
    String REFRESH_TOKEN = "/refresh-token";
    String SENDING_OTP = "/send-otp";
    String CONFIRM_OTP = "/confirm-otp";
    String UPDATE_NEW_PASSWORD = "/change-password";
    String UPDATE_INFO_USER = "/update-info-user";

    // Wallet
    String GET_INFO_WALLET = "/get-info-wallet";
    String WITHDRAW = "/withdraw";
    String TOP_UP = "/topup";

    // Product
    String CHANGE_STATUS_PRODUCT = "/change-status/{productID}";
    String GET_DETAIL_PRODUCT = "/detail/{productID}";
    String DELETE_PRODUCT = "/delete/{productID}";
    String UPDATE_PRODUCT = "/update/{productID}";
    String GET_ALL_IMAGE_OF_PRODUCT = "/get-all-image-of-product/{productID}";
    String CHANGE_DEFAULT_IMAGE = "/change-default-image";

    // Shop
    String GET_DETAIL_SHOP = "/detail/{shopID}";

    /**
     * District
     */
    String GET_DISTRICT_BY_CITY = "/get-by-city/{cityID}";

    /**Origin*/

    String DELETE_ORIGIN = DELETE + "/{originID}";
    /**Category*/

    String DELETE_CATEGORY = DELETE + "/{categoryID}";
    /**Brand*/
    String DELETE_BRAND = DELETE + "/{brandID}";

    /**
     * ShippingAddress
     */
    String GET_SHIPPING_ADDRESS_DEFAULT_BY_USER = "/get-address-default";
    String CHANGE_DEFAULT_SHIPPING_ADDRESS = "/change-default/{shippingAddressID}";
    String DELETE_ADDRESS = "/delete/{shippingAddressID}";

    /**Delivery*/
    String DELETE_DELIVERY = DELETE + "/deliveryID";


    /**
     * User
     */
    String GET_USER_BY_ID = "/get-by-id/{userID}";
    String GET_USE_BY_FIRST_NAME = "/get-by-first-name/{firstName}";
    String CHANGE_PASSWORD = "/change-password";
    String UPDATE_STATUS_USER = "/change-status/{userID}";

    /**City*/

    /**
     * Ward
     */
    String GET_WARD_BY_DISTRICT = "/get-by-district/{districtID}";

    /**Payment*/

    /**
     * Campaign
     */
    String GET_DETAIL_CAMPAIGN = "/detail/{campaignID}";
    String DELETE_CAMPAIGN = "/delete/{campaignID}";
    String CHANGE_ACTIVE_CAMPAIGN = "/change-active/{campaignID}";
    String UPDATE_CAMPAIGN = "/update/{campaignID}";

    //Cart Item
    String GET_ALL_CART_ITEM = "/get-all-by-user";
    String DELETE_CART_ITEM = "/delete/{cartItemID}";
    String GET_SHIPPING_FEE = "/get-shipping-fee";
    String CHANGE_QUANTITY = "/change-quantity";
    String CHANGE_PROPERTY = "/change-property";
    String GET_LIST_CART_ITEM_CHECKOUT = "/get-all-cart-item-checkout";

    /**
     * Common
     */
    String GET_DISTANCE = "/get-distance";

    // Admin
    String CONFIRM_TRANSACTION = "/confirm-transaction";

    String STATISTICAL = "/statistical";

    //Value property
    String GET_BY_PROPERTY_ID = "/get-all-value-of-property/{propertyID}";
    String DELETE_VALUE_PROPERTY = DELETE + "/{valuePropertyID}";
    //Invoice
    String GET_DETAIL_INVOICE = "/detail/{invoiceID}";
    String CHANGE_STATUS_INVOICE = "/change-status/{invoiceID}";

    //Money transfer
    String CANCEL_TRANSACTION = "/cancel-transaction";
    String COMPLETED_INVOICE = "/completed/{invoiceID}";
    String RETURNED_INVOICE = "/returned/{invoiceID}";
    String CANCEL_RETURN_INVOICE = "/cancel-return/{invoiceID}";
}
