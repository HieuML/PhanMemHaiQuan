package com.example.demo.dto.request.authReq;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import java.util.Date;

@Setter
@Getter
public class UpdateUserReq {
    @Size(max = 100)
    private String firstName;
    @Size(max = 100)
    private String lastName;
    private String gender;
    @Temporal(TemporalType.DATE)
    private Date birthday;
    @Size(max = 20)
    private String phone;
    private String avatar;
}
