package com.example.demo.dto.response.originRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Origin;

public class OriginRes extends IdNameRes {
    public OriginRes(Integer id, String name) {
        super(id, name);
    }

    public static OriginRes convertFromEntity(Origin origin) {
        return new OriginRes(origin.getOriginID(), origin.getName());
    }
}
