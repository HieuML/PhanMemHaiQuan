package com.example.demo.dto.response.propertyRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Property;

public class PropertyRes extends IdNameRes {
    public PropertyRes(Integer id, String name) {
        super(id, name);
    }

    public static PropertyRes convertFromEntity(Property property) {
        return new PropertyRes(property.getPropertyID(),
                property.getName());
    }
}
