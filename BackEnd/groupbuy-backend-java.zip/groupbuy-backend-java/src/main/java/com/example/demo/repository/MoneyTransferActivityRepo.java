package com.example.demo.repository;

import com.example.demo.entities.MoneyTransferActivity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MoneyTransferActivityRepo extends JpaRepository<MoneyTransferActivity, Integer> {


    Page<MoneyTransferActivity> findByFromUserIDOrToUserID(Integer fromUserID, Integer toUserID, Pageable pageable);

    Page<MoneyTransferActivity> findByStatus(String status,Pageable pageable);

    Page<MoneyTransferActivity> findByStatusAndFromUserIDOrStatusAndToUserID(String status, Integer fromUserID,String status1, Integer toUserID, Pageable pageable);

}
