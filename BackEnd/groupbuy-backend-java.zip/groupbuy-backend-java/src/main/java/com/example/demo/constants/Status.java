package com.example.demo.constants;

public interface Status {

    //status campaign
    String WAITING_START = "WAITING_START";
    String STARTING = "STARTING";
    String ENDED = "ENDED";

    // status invoice
    String WAITING_CONFIRM = "WAITING_CONFIRM";
    String CONFIRMED = "CONFIRMED";
    String PROCESSING = "PROCESSING";
    String SHIPPING = "SHIPPING";
    String SHIPPING_COMPLETED = "SHIPPING_COMPLETED";
    String COMPLETED = "COMPLETED";
    String CANCELLED = "CANCELLED";
    String RETURNING = "RETURNING";
    String RETURNED = "RETURNED";
    String CANCELED_RETURN = "CANCELED_RETURN";
    String DEFAULT = "DEFAULT";
    String RETURN = "RETURN";
}
