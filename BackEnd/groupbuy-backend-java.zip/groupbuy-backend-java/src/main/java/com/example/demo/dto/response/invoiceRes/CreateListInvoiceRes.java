package com.example.demo.dto.response.invoiceRes;

import com.example.demo.dto.request.invoiceReq.InvoiceReq;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CreateListInvoiceRes {
    private List<InvoiceRes> listInvoiceRes;

    // Tổng deposit cuả các đơn hàng
    private Integer totalDeposit;

    // Tổng tiền của các đơn hàng phải trả
    private Integer totalPrice;

    // Tổng tiền ship của các đơn hàng
    private Integer totalShippingFee;

    // Tổng tiền thanh toán
    private Integer totalPay;

    // Tổng số tiền đã trả của các đơn hàng
    private Integer totalPaidAmount;

    // Tiền còn lại phải trả
    private Integer totalRemainPayAmount;

    // Thông tin chung của các invoice được tạo
    private String consigneeName;
    private String consigneePhone;
    private String shippingAddress;


}
