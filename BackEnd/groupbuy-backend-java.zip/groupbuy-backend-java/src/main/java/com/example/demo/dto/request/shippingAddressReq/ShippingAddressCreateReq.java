package com.example.demo.dto.request.shippingAddressReq;

import lombok.Getter;

@Getter
public class ShippingAddressCreateReq {
    private String consigneeName;
    private String phone;
    private Boolean type;
    private String addressDetail;
    private String street;
    private Integer wardID;
}
