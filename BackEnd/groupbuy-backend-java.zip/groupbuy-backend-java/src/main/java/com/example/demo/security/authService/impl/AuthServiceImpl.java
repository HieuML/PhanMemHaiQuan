package com.example.demo.security.authService.impl;

import com.example.demo.constants.RoleName;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.authReq.*;
import com.example.demo.entities.*;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.*;
import com.example.demo.security.authService.AuthService;
import com.example.demo.security.authService.RefreshTokenService;
import com.example.demo.security.authService.UserDetailsImpl;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.authRes.UserRes;
import com.example.demo.dto.response.authRes.LoginRes;
import com.example.demo.dto.response.authRes.TokenRefreshRes;
import com.example.demo.service.userService.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

@Service
public class AuthServiceImpl implements AuthService {
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserService userService;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    RefreshTokenService refreshTokenService;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    PasswordEncoder encoder;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    ShoppingCartRepository shoppingCartRepository;
    @Autowired
    WalletRepository walletRepository;

    public BaseRes<?> getMe(HttpServletRequest request) {
        String username = getUsernameFromJwt(request);
        User user = userRepository.findByUsername(username).get();
        Optional<Shop> shop = shopRepository.findByUserId(user.getId());
        UserRes userRes = new UserRes(user);
        userRes.setShopId(shop.isEmpty() ? null : shop.get().getShopID());
        return new BaseRes<UserRes>(HttpStatus.OK.value(), TextStatus.GET_INFO_SUCCESS, userRes);
    }

    public String getUsernameFromJwt(HttpServletRequest request) {
        String headerAuth = request.getHeader("Authorization");
        String jwt = null;
        if (StringUtils.hasText(headerAuth) && headerAuth.startsWith("Bearer ")) {
            jwt = headerAuth.substring(7);
        } else throw new ResourceNotFoundException(TextStatus.INVALID_ACCESS_TOKEN);
        if (jwt != null && jwtUtils.validateJwtToken(jwt)) {
            return jwtUtils.getUserNameFromJwtToken(jwt);
        } else throw new ResourceNotFoundException(TextStatus.INVALID_ACCESS_TOKEN);
    }

    public BaseRes<?> updateInfoUser(HttpServletRequest request, UpdateUserReq updateUserReq) {
        String username = getUsernameFromJwt(request);
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.USER_NOT_FOUND);
        }
        User newUser = user.get();
        newUser.setFirstName(updateUserReq.getFirstName());
        newUser.setLastName(updateUserReq.getLastName());
        newUser.setGender(updateUserReq.getGender());
        newUser.setBirthday(updateUserReq.getBirthday());
        newUser.setPhone(updateUserReq.getPhone());
        newUser.setAvatar(updateUserReq.getAvatar());
        userRepository.save(newUser);
        UserRes userRes = new UserRes(newUser);
        return new BaseRes<UserRes>(HttpStatus.OK.value(), TextStatus.UPDATE_INFO_USER_SUCCESS, userRes);
    }


    @Override
    public BaseRes<?> authenticateUser(LoginReq registerRequest) {
        Optional<User> user = userRepository.findUserByUsername(registerRequest.getUsername());
        if (!user.isPresent()) throw new ResourceNotFoundException(TextStatus.LOGIN_ERROR);
        User userData = user.get();
        if (userData.getIsActive()) {
            Authentication authentication = authenticationManager
                    .authenticate(new UsernamePasswordAuthenticationToken(registerRequest.getUsername(), registerRequest.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            String jwt = jwtUtils.generateJwtToken(userDetails);
            refreshTokenService.deleteByUserId(userDetails.getId());
            RefreshToken refreshToken = refreshTokenService.createRefreshToken(userDetails.getId());
            LoginRes loginRes = new LoginRes(
                    jwt, refreshToken.getToken());
            userRepository.save(userData);
            return new BaseRes<LoginRes>(HttpStatus.OK.value(), TextStatus.LOGIN_SUCCESS, loginRes);
        } else {
            return new BaseRes<>(HttpStatus.LOCKED.value(), TextStatus.ACCOUNT_LOCKED);
        }
    }

    @Override
    public BaseRes<?> registerUser(RegisterReq registerReq) {
        if (userRepository.existsByUsername(registerReq.getUsername())) {
            return new BaseRes<>(HttpStatus.BAD_REQUEST.value(), TextStatus.USERNAME_EXIST);
        }
        if (userRepository.existsByEmail(registerReq.getEmail().toLowerCase())) {
            return new BaseRes<>(HttpStatus.BAD_REQUEST.value(), TextStatus.EMAIL_EXIST);
        }
        User user = new User(registerReq.getUsername(),
                encoder.encode(registerReq.getPassword()), registerReq.getEmail().toLowerCase(), registerReq.getFirstName(),
                registerReq.getLastName(), registerReq.getGender(), registerReq.getBirthday(), registerReq.getPhone());
        String roleStr = registerReq.getRole();
        if (roleStr.equals(RoleName.SELLER)) {
            Role role = roleRepository.findByName(RoleName.SELLER);
            user.setRole(role);
            userRepository.save(user);
            shopRepository.save(new Shop(user));
        } else if (roleStr.equals(RoleName.CUSTOMER)) {
            Role role = roleRepository.findByName(RoleName.CUSTOMER);
            user.setRole(role);
            userRepository.save(user);
            shoppingCartRepository.save(new ShoppingCart(user));
        } else {
            throw new ResourceNotFoundException(TextStatus.ROLE_NOT_FOUND);
        }
        walletRepository.save(new Wallet(user));
        return new BaseRes<>(HttpStatus.OK.value(), TextStatus.REGISTER_SUCCESS);
    }

    @Override
    public BaseRes<?> refreshtokenUser(TokenRefreshReq request) {
        String requestRefreshToken = request.getRefreshToken();
        return refreshTokenService.findByToken(requestRefreshToken)
                .map(refreshTokenService::verifyExpiration)
                .map(RefreshToken::getUser)
                .map(user -> {
                    String token = jwtUtils.generateTokenFromUsername(user.getUsername());
                    return new BaseRes(HttpStatus.OK.value(), TextStatus.REFRESH_TOKEN_SUCCESS, new TokenRefreshRes(token, requestRefreshToken));
                })
                .orElseThrow(() -> new ResourceNotFoundException(TextStatus.REFRESH_TOKEN_NOT_FOUND));
    }

    @Override
    public BaseRes<?> logoutUser(LogOutReq logOutReq) {
        Optional<User> userData = userRepository.findById(logOutReq.getUserID());
        if (!userData.isPresent())
            return new BaseRes<>(HttpStatus.BAD_REQUEST.value(), TextStatus.LOGOUT_ERROR, null);
//            throw new ResourceNotFoundException(TextStatus.LOGOUT_ERROR);
        refreshTokenService.deleteByUserId(logOutReq.getUserID());
//      User userData = userRepository.findById(logOutRequest.getUserId()).get();
        return new BaseRes<>(HttpStatus.OK.value(), TextStatus.LOGOUT_SUCCESS);
    }
}
