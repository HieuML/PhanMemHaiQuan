package com.example.demo.service.moneyTransferService;

import com.example.demo.dto.request.adminReq.ConfirmOrCancelTransactionReq;
import com.example.demo.dto.request.productReq.GetAllMoneyTransferReq;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

public interface MoneyTransferService {

    Map<String, Object> getAllMoneyTransfer(HttpServletRequest request, GetAllMoneyTransferReq req);

    void cancelTransaction(HttpServletRequest request, ConfirmOrCancelTransactionReq req);

}
