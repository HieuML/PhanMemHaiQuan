package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "invoice")
@Setter
@Getter
@NoArgsConstructor
public class Invoice {
    @Id
    @GeneratedValue(generator = "my_generator")
    @GenericGenerator(name = "my_generator", parameters = {@org.hibernate.annotations.Parameter(name = "prefix", value = "OD")}, strategy = "com.example.demo.utils.generatorIDHandler")
    @Column(name = "invoice_id")
    private String invoiceID;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_inform_id", nullable = false)
    private User user;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "delivery_id", nullable = false)
    private Delivery delivery;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "payment_id", nullable = false)
    private Payment payment;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "shop_id", nullable = false)
    private Shop shop;
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "buy_type_id", nullable = false)
    private BuyType buyType;
    private String status;
    @Column(name = "shipping_address")
    private String shippingAddress;
    @Column(name = "shipping_fee")
    private Integer shippingFee;
    @Column(name = "total_amount")
    private Integer totalAmount;
    @Column(name = "paid_amount")
    private Integer paidAmount;
    @Column(name = "consignee_phone", length = 20)
    private String consigneePhone;
    @Column(name = "consignee_name", length = 100)
    private String consigneeName;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;
}
