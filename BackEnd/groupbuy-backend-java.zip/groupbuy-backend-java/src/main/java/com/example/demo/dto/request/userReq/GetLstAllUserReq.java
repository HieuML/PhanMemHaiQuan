package com.example.demo.dto.request.userReq;

import com.example.demo.dto.request.PageReq;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;

@Getter
@Service
@AllArgsConstructor
@NoArgsConstructor
public class GetLstAllUserReq extends PageReq {
    private String sort;
}
