package com.example.demo.dto.request.productReq;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GetAllProductReq {
    private Integer shopID;
    private String sort;
    private String productName;
    private Integer limit;
    private Integer pageIndex;
}
