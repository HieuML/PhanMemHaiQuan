package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "money_transfer_activity")
@Setter
@Getter
@NoArgsConstructor
public class MoneyTransferActivity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "money_transfer_activity_id")
    private Integer moneyTransferID;
    @Column(name = "from_user_id")
    private Integer fromUserID;
    @Column(name = "to_user_id")
    private Integer toUserID;
    private Integer amount;
    private String status;
    private String description;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public MoneyTransferActivity(Integer fromUserID, Integer toUserID, Integer amount, String status, String description) {
        this.fromUserID = fromUserID;
        this.toUserID = toUserID;
        this.amount = amount;
        this.status = status;
        this.description = description;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
    }
}
