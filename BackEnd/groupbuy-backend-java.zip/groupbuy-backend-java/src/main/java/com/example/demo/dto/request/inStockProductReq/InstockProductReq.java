package com.example.demo.dto.request.inStockProductReq;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InstockProductReq {
    private String valueProperty;
    private Integer inStock;
}
