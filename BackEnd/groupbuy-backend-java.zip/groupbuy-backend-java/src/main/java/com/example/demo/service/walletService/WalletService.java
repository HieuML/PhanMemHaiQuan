package com.example.demo.service.walletService;

import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.walletRes.DetailWalletRes;
import org.springframework.stereotype.Service;

@Service
public interface WalletService {
    public BaseRes<DetailWalletRes> getByUserId(Integer UserId);
}
