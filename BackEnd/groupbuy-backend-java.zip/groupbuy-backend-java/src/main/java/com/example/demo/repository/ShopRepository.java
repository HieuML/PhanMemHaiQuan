package com.example.demo.repository;

import com.example.demo.entities.Shop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ShopRepository extends JpaRepository<Shop, Integer> {
    Optional<Shop> findByUserId(Integer userID);

    Long countByUserIsActive(Boolean isActiveByUser);

//    @Query("select count (t.shopID) from Shop t where t.createdAt >= ?1 and t.createdAt <= ?2")
    Long countByCreatedAtBetween (Long startTime, Long endTime);
}
