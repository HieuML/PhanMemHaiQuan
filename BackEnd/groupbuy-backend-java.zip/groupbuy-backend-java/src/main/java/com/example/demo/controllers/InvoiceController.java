package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.invoiceReq.CreateListInvoiceReq;
import com.example.demo.dto.request.invoiceReq.GetLstInvoiceReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.service.invoiceService.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/invoice")
public class InvoiceController {
    @Autowired
    private InvoiceService invoiceService;

    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<?> createListInvoice(HttpServletRequest request, @RequestBody CreateListInvoiceReq createListInvoiceReq) {
        invoiceService.createListInvoice(request, createListInvoiceReq);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.PAYMENT_SUCCESS, null));
    }

    @PostMapping(Path.GET_ALL)
    public ResponseEntity<?> getLstInvoice(HttpServletRequest request, @RequestBody GetLstInvoiceReq getLstInvoiceReq) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_LIST_INVOICE_SUCCESS, invoiceService.getAll(request, getLstInvoiceReq)));
    }

    @GetMapping(Path.GET_DETAIL_INVOICE)
    public ResponseEntity<?> getDetailInvoice(@PathVariable String invoiceID) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_DETAIL_INVOICE_SUCCESS, invoiceService.getDetailInvoice(invoiceID)));
    }

    //Customer + seller
    @PreAuthorize("hasRole('CUSTOMER') or hasRole('SELLER')")
    @PostMapping(Path.CHANGE_STATUS_INVOICE)
    public ResponseEntity<?> changeStatusInvoice(HttpServletRequest request, @PathVariable String invoiceID) {
        invoiceService.changeStatusInvoice(request, invoiceID);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CHANGE_STATUS_INVOICE_SUCCESS, new BaseUpdated(invoiceID, true)));
    }

    //Admin
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.COMPLETED_INVOICE)
    public ResponseEntity<?> completedInvoice (@PathVariable String invoiceID)  {
        invoiceService.completedInvoice(invoiceID);
        return  ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.COMPLETED_INVOICE_SUCCESS,new BaseUpdated(invoiceID,true)));
    }

    @PostMapping(Path.RETURNED_INVOICE)
    public ResponseEntity<?> returnedInvoice (@PathVariable String invoiceID)  {
        invoiceService.returnedInvoice(invoiceID);
        return  ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.COMPLETED_INVOICE_SUCCESS,new BaseUpdated(invoiceID,true)));
    }

    @PostMapping(Path.CANCEL_RETURN_INVOICE)
    public ResponseEntity<?> cancelReturnInvoice (@PathVariable String invoiceID)  {
        invoiceService.cancelReturnInvoice(invoiceID);
        return  ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CANCEL_RETURN_INVOICE_SUCCESS,new BaseUpdated(invoiceID,true)));
    }
}
