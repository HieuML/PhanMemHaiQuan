package com.example.demo.dto.response.invoiceRes;

import com.example.demo.dto.response.PageRes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GetLstInvoiceRes {
    private List<InvoiceRes> lstInvoiceRes;
    private PageRes pageRes;
    private Integer totalItem;
}
