package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.cartItemReq.*;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.service.cartItemService.CartItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

//Customer
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/cart-item")
public class CartItemController {
    @Autowired
    private CartItemService cartItemService;

    @PostMapping(Path.CREATE)
    public ResponseEntity<?> createCartItem(HttpServletRequest request, @RequestBody CreateOrUpdateCartItemReq cartItem) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CREATE_CART_ITEM_SUCCESS, cartItemService.createCartItem(request, cartItem)));
    }

    @GetMapping(Path.GET_ALL_CART_ITEM)
    public ResponseEntity<?> getAllCartItemByUser(HttpServletRequest request) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.FIND_CART_ITEM_BY_USERID_SUCCESS, cartItemService.getAllCartItemByUser(request)));
    }

    @PostMapping(Path.GET_SHIPPING_FEE)
    public ResponseEntity<?> getShippingFee(@RequestBody GetShippingFeeReq getShippingFeeReq) throws Exception {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_SHIPPING_FEE_SUCCESS, cartItemService.getShippingFee(getShippingFeeReq)));
    }

    @PostMapping(Path.DELETE_CART_ITEM)
    public ResponseEntity<?> deleteCartItem(HttpServletRequest request, @PathVariable Integer cartItemID) {
        cartItemService.deleteCartItem(request, cartItemID);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.DELETE_CART_ITEM_SUCCESS));
    }

    @PostMapping(Path.CHANGE_QUANTITY)
    public ResponseEntity<?> changeQuantity(HttpServletRequest request, @RequestBody ChangeQuantityReq changeQuantityReq) {
        cartItemService.changeQuantity(request, changeQuantityReq);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CHANGE_QUANTITY_CART_ITEM_SUCCESS, new BaseUpdated(changeQuantityReq.getCartItemID(), true)));
    }

    @PostMapping(Path.CHANGE_PROPERTY)
    public ResponseEntity<?> changeProperty(HttpServletRequest request, @RequestBody ChangePropertyReq changePropertyReq) {
        cartItemService.changeProperty(request, changePropertyReq);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CHANGE_PROPERTY_CART_ITEM_SUCCESS, new BaseUpdated(changePropertyReq.getCartItemID(), true)));
    }

    @PostMapping(Path.GET_LIST_CART_ITEM_CHECKOUT)
    public ResponseEntity<?> getListCartItemCheckout(HttpServletRequest request, @RequestBody CheckoutReq checkoutReq) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_LIST_CART_ITEM_CHECKOUT_SUCCESS, cartItemService.getListCartItemCheckout(request, checkoutReq)));
    }
}
