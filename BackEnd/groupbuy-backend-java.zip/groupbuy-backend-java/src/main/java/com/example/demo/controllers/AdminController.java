package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.adminReq.ConfirmOrCancelTransactionReq;
import com.example.demo.dto.request.adminReq.StatisticalReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.service.adminService.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
//All admin
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.CONFIRM_TRANSACTION)
    public ResponseEntity<?> confirmTransaction(HttpServletRequest request, @RequestBody ConfirmOrCancelTransactionReq confirmOrCancelTransactionReq) {
        adminService.confirmTransaction(request, confirmOrCancelTransactionReq);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CONFIRM_TRANSACTION_SUCCESS, new BaseUpdated(confirmOrCancelTransactionReq.getMoneyTransferActivityID(), true)));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.STATISTICAL)
    public ResponseEntity<?> statistical(@RequestBody StatisticalReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_STATISTICAL_SUCCESS, adminService.statisticalForAdmin(req)));
    }
}
