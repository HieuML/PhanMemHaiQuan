package com.example.demo.dto.request.cartItemReq;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ChangePropertyReq {
    Integer cartItemID;
    Integer inStockProductID;
}
