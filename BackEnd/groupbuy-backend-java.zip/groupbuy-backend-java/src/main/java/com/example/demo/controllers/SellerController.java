package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.adminReq.StatisticalReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.adminService.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

import static com.example.demo.constants.TextStatus.GET_STATISTICAL_SUCCESS;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/seller")
public class SellerController {
    @Autowired
    private AdminService adminService;

    @PreAuthorize("hasRole('SELLER')")
    @PostMapping(Path.STATISTICAL)
    public ResponseEntity<BaseRes> statistical(HttpServletRequest servletRequest, @RequestBody StatisticalReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_STATISTICAL_SUCCESS, adminService.statisticalForSeller(servletRequest, req)));
    }
}
