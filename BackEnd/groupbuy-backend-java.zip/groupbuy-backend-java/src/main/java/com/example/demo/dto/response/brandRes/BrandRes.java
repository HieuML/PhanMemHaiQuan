package com.example.demo.dto.response.brandRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Brand;

public class BrandRes extends IdNameRes {
    public BrandRes(Integer id, String name) {
        super(id, name);
    }

    public static BrandRes convertFromEntity(Brand brand) {
        return new BrandRes(brand.getBrandID(), brand.getName());
    }
}
