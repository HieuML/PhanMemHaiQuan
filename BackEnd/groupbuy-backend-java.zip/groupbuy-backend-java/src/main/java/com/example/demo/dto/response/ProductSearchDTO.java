package com.example.demo.dto.response;

import com.example.demo.entities.Product;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
public class ProductSearchDTO {
    private String productID;
    private String productName;
    private Integer price;
    private String slug;
    private BigDecimal rating;

    public static ProductSearchDTO convertFromEntity(Product product) {
        return new ProductSearchDTO(product.getProductID(),
                product.getName(),
                product.getPrice(),
                product.getSlug(),
                product.getRating()
        );
    }
}
