package com.example.demo.dto.response.productImageRes;

import com.example.demo.entities.ProductImage;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class ProductImageRes {
    private Integer productImageID;
    private String url;
    private Boolean isDefault;

    public static ProductImageRes convertFromEntity(ProductImage productImage) {
        return new ProductImageRes(productImage.getProductImageID(), productImage.getUrl(), productImage.getIsDefault());
    }
}
