package com.example.demo.entities;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.*;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "product")
@Setter
@Getter
public class Product {
    @Id
    @GeneratedValue(generator = "generator")
    @GenericGenerator(name = "generator", parameters = {@Parameter(name = "prefix", value = "pd")}, strategy = "com.example.demo.utils.generatorIDHandler")
    @Column(name = "product_id")
    private String productID;
    private String name;
    private String description;
    private Integer price;
    @Column(name = "origin_price")
    private Integer originPrice;
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "brand_id", nullable = true)
    private Brand brand;
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "category_id", nullable = true)
    private Category category;
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "shop_id", nullable = false)
    private Shop shop;
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "origin_id", nullable = true)
    private Origin origin;
    @Column(name = "sold_quantity")
    private Integer soldQuantity;
    @Column(name = "in_stock")
    private Integer inStock;
    @Column(precision = 2, scale = 1)
    @Type(type = "big_decimal")
    private java.math.BigDecimal rating;
    private String slug;
    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "product_image")
    private String productImage;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public void changeIsActive() {
        isActive = !isActive;
    }

    public Product(String name, String description, Integer price, Integer originPrice, Shop shop) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.originPrice = originPrice;
        this.shop = shop;
        this.soldQuantity = 0;
        this.inStock = 0;
        this.rating = new BigDecimal(0);
        this.isActive = false;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
    }

    public Product() {
    }
}
