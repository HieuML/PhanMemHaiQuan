package com.example.demo.service.brandService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.brandRes.BrandRes;
import com.example.demo.entities.Brand;
import com.example.demo.repository.BrandRepository;
import com.example.demo.service.brandService.BrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.swing.text.html.Option;
import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BrandServiceImpl implements BrandService {
    @Autowired
    private BrandRepository brandRepository;

    @Override
    @Transactional
    public BaseRes getAll() {
        try {
            return new BaseRes<>(HttpStatus.OK.value(),
                    TextStatus.GET_ALL_BRAND,
                    brandRepository.findAll().stream()
                            .map(x -> BrandRes.convertFromEntity(x))
                            .collect(Collectors.toList()));
        } catch (Exception error) {
            return new BaseRes<>(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    TextStatus.INTERNAL_SERVER_ERROR,
                    null);
        }
    }

    @Override
    public BaseRes create(RequestName name) {
        Optional<Brand> entity = brandRepository.findBrandByName(name.getName());
        if (entity.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(),
                    TextStatus.NAME_HAS_EXISTED,
                    null);
        Brand newBrand = new Brand();
        newBrand.setName(name.getName());
        newBrand.setCreatedAt(new Date().getTime());
        newBrand.setUpdatedAt(new Date().getTime());
        brandRepository.save(newBrand);
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.CREATE_SUCCESS,
                BrandRes.convertFromEntity(brandRepository.findBrandByName(name.getName()).get()));
    }

    @Override
    public BaseRes update(IdNameReq req) {
        Optional<Brand> entity = brandRepository.findById(req.getId());
        Optional<Brand> brandHasSameName = brandRepository.findBrandByName(req.getName());
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);

        if (brandHasSameName.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(),
                    TextStatus.NAME_HAS_EXISTED,
                    null);

        Brand entityUpdate = entity.get();
        entityUpdate.setName(req.getName());
        entityUpdate.setUpdatedAt(new Date().getTime());
        brandRepository.save(entityUpdate);
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.UPDATE_SUCCESS,
                new BaseUpdated<>(entityUpdate.getBrandID(), true)
        );
    }

    @Override
    public BaseRes delete(Integer brandID) {
        Optional<Brand> entity = brandRepository.findById(brandID);
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);

        brandRepository.delete(entity.get());
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.DELETE_SUCCESS,
                new BaseUpdated<>(entity.get().getBrandID(), true)
        );
    }
}
