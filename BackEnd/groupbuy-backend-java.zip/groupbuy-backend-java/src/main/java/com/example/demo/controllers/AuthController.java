package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.UpdatePasswordRequest;
import com.example.demo.dto.request.authReq.*;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.security.authService.AuthService;
import com.example.demo.service.userService.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @Autowired
    private AuthService authService;
    @Autowired
    private UserService userService;

    @PostMapping(Path.LOGIN)
    public ResponseEntity<?> login(@Valid @RequestBody LoginReq loginReq) {
        return ResponseEntity.ok(authService.authenticateUser(loginReq));
    }

    @PostMapping(Path.REGISTER)
    public ResponseEntity<?> register(@Valid @RequestBody RegisterReq signUpRequest) {
        return ResponseEntity.ok(authService.registerUser(signUpRequest));
    }

    @GetMapping(Path.INFO)
    public ResponseEntity<?> getInfo(HttpServletRequest request) {
        return ResponseEntity.ok(authService.getMe(request));
    }

    @PostMapping(Path.UPDATE_INFO_USER)
    public ResponseEntity<?> updateInfoUser(HttpServletRequest request, @RequestBody UpdateUserReq updateUserReq) {
        return ResponseEntity.ok(authService.updateInfoUser(request, updateUserReq));
    }

    @PostMapping(Path.REFRESH_TOKEN)
    public ResponseEntity<?> refreshtoken(@Valid @RequestBody TokenRefreshReq request) {
        return ResponseEntity.ok(authService.refreshtokenUser(request));
    }

    @PostMapping(Path.LOGOUT)
    public ResponseEntity<?> logoutUser(@Valid @RequestBody LogOutReq logOutReq) {
        return ResponseEntity.ok(authService.logoutUser(logOutReq));
    }

    @PostMapping(Path.SENDING_OTP)
    public ResponseEntity<BaseRes> send(@RequestParam("email") String email) {
        if (userService.sendOTP(email))
            return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.SEND_EMAIL_SUCCESS, null));
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.BAD_REQUEST.value(), TextStatus.SEND_EMAIL_SUCCESS, null));
    }

    @PostMapping(Path.CONFIRM_OTP)
    public ResponseEntity<BaseRes> confirm(@RequestParam("otp") String otp) {
        if (userService.confirmOTP(otp).isPresent())
            return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CONFIRM_OTP_SUCCESS, userService.confirmOTP(otp).get()));
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CONFIRM_OTP_FAIL, null));
    }

    @PostMapping(Path.UPDATE_NEW_PASSWORD)
    public ResponseEntity<BaseRes> updatePassword(@RequestBody UpdatePasswordRequest updatePasswordRequest) {
        if (userService.updatePassword(updatePasswordRequest))
            return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CHANGE_PASSWORD_SUCCESS, null));
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.BAD_REQUEST.value(), TextStatus.CHANGE_PASSWORD_ERROR, null));
    }
}
