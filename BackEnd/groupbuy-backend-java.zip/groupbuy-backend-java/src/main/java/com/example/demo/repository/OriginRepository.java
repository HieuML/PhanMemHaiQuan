package com.example.demo.repository;

import com.example.demo.entities.Origin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OriginRepository extends JpaRepository<Origin, Integer> {
    Optional<Origin> findOriginByName(String name);
}
