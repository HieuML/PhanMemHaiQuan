package com.example.demo.repository;

import com.example.demo.entities.ValueProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ValuePropertyRepository extends JpaRepository<ValueProperty, Integer> {
    @Query("SELECT t.valuePropertyID from ValueProperty t where t.name = ?1")
    Optional<Integer> findByNameLike(String name);

    List<ValueProperty> findByPropertyPropertyID(Integer propertyID);

    Optional<ValueProperty> findValuePropertyByName(String name);
}
