package com.example.demo.dto.response.priceLevelRes;

import com.example.demo.entities.PriceLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class PriceLevelRes {
    private Integer quantity;
    private Integer price;
    private Boolean isCurrent;

    public static PriceLevelRes convertFromEntity(PriceLevel priceLevel) {
        return new PriceLevelRes(priceLevel.getQuantity(), priceLevel.getPrice(), priceLevel.getIsCurrent());
    }
}
