package com.example.demo.service.walletService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.repository.WalletRepository;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.walletRes.DetailWalletRes;
import com.example.demo.service.walletService.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class WalletServiceImpl implements WalletService {
    @Autowired
    WalletRepository walletRepository;

    @Override
    public BaseRes<DetailWalletRes> getByUserId(Integer userID) {
        return new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_DETAIL_WALLET_SUCCESS, new DetailWalletRes(walletRepository.findByUserId(userID).getMoney()));
    }
}
