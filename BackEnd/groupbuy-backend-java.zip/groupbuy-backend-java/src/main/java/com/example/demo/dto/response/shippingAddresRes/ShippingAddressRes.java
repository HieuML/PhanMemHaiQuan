package com.example.demo.dto.response.shippingAddresRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.dto.response.authRes.UserRes;
import com.example.demo.dto.response.cityRes.CityRes;
import com.example.demo.dto.response.districtRes.DistrictRes;
import com.example.demo.dto.response.wardRes.WardRes;
import com.example.demo.entities.ShippingAddress;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShippingAddressRes extends IdNameRes {
    private UserRes userRes;
    private WardRes wardRes;
    private Boolean type;
    private Boolean isDefault;
    private String consigneePhone;
    private String consigneeName;
    private String addressDetail;
    private String street;
    private DistrictRes districtRes;
    private CityRes cityRes;

    public ShippingAddressRes(ShippingAddress shippingAddress) {
        super(shippingAddress.getShippingAddressID(),
                null);
        this.userRes = new UserRes(shippingAddress.getUser());
        this.type = shippingAddress.getType();
        this.isDefault = shippingAddress.getIsDefault();
        this.addressDetail = shippingAddress.getAddressDetail();
        this.consigneePhone = shippingAddress.getPhone();
        this.consigneeName = shippingAddress.getConsigneeName();
        this.street = shippingAddress.getStreet();
        this.wardRes = WardRes.convertFromEntity(shippingAddress.getWard());
        this.districtRes = DistrictRes.convertFromEntity(shippingAddress.getWard().getDistrict());
        this.cityRes = CityRes.convertFromEntity(shippingAddress.getWard().getDistrict().getCity());
    }
}
