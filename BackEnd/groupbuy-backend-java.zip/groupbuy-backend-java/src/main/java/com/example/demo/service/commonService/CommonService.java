package com.example.demo.service.commonService;

import com.example.demo.dto.request.GetDistanceReq;

public interface CommonService {
    Long getDistance(GetDistanceReq getDistanceReq) throws Exception;
}


