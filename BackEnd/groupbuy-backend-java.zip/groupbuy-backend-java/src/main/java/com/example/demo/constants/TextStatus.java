package com.example.demo.constants;

public interface TextStatus {

    // Auth
    String REGISTER_SUCCESS = "Success: User registered successfully!";
    String LOGIN_SUCCESS = "Success: User login successfully ";
    String REFRESH_TOKEN_SUCCESS = "Success: refresh token successfully";
    String LOGOUT_SUCCESS = "Success: Log out successful!";
    String GET_INFO_SUCCESS = "Success: Get info successfully";
    String UPDATE_INFO_USER_SUCCESS = "Success: Update info user successfully";
    String UPDATE_STATUS = "Success: Update status user successfully";

    // Success wallet
    String GET_DETAIL_WALLET_SUCCESS = "Success: Get detail wallet by user's id successfully";

    /**
     * Error
     */
    String INTERNAL_SERVER_ERROR = "Internal Server Error";
    String BRAND_NOT_FOUND = "Error: Brand not found!";
    String CATEGORY_NOT_FOUND = "Error: Category not found!";
    String SHOP_NOT_FOUND = "Error: Shop not found!";
    String SHOPPING_CART_NOT_FOUND = "Error: Shopping cart not found!";
    String ORIGIN_NOT_FOUND = "Error: Origin not found!";
    String WARD_NOT_FOUND = "Error: Ward not found!";
    String ROLE_NOT_FOUND = "Error: Role not found!";
    String UNAUTHORIZED = "Error: User doesn't have permission";
    String NAME_HAS_EXISTED = "Error: name has existed";

    String NOT_FOUND = "Error: not found!";

    /**
     * Success
     */
    String DELETE_SUCCESS = "Success: delete successfully";
    String UPDATE_SUCCESS = "Success: update successfully";

    //Product
    String UPDATE_PRODUCT_SUCCESS = "Success: Update product successfully";
    String CREATE_PRODUCT_SUCCESS = "Success: Create product successfully";
    String GET_ALL_PRODUCT_SUCCESS = "Success: Get all product successfully";
    String GET_DETAIL_PRODUCT_SUCCESS = "Success: Get detail product successfully";
    String CHANGE_STATUS_PRODUCT_SUCCESS = "Success: Change status product successfully";
    String DELETE_PRODUCT_SUCCESS = "Success: Delete product successfully";
    String PROPERTY_NOT_FOUND = "Error: property not found";
    String MISSING_INSTOCK = "Error: You have to enter in stock of product";
    String MISSING_VALUE_PROPERTY = "Error: You have to enter valueProperty and in stock";
    String GET_PRODUCT_BY_SHOP_SUCCESS = "Success: Get all product by shop successfully";
    String GET_IMAGE_BY_PRODUCT_SUCCESS = "Success: Get all image by product successfully";
    String CHANGE_DEFAULT_IMAGE_SUCCESS = "Success: Change default image of product successfully";
    String NOT_FOUND_PRODUCT_ERROR = "Error: Product not found!";

    // Campaign
    String CREATE_CAMPAIGN_SUCCESS = "Success: Create campaign successfully";
    String UPDATE_CAMPAIGN_SUCCESS = "Success: Update campaign successfully";
    String PRODUCT_NOT_ACTIVE = "Error: Product is not for sale";
    String PRODUCT_NO_CHANGE = "Error: Product can't be changed";
    String IN_STOCK_INVALID = "Error: In stock invalid";
    String PRICE_INVALID = "Error: Price invalid!";
    String MISSING_QUANTITY = "Error: You have to enter quantity of cart item";
    String QUANTITY_INVALID = "Error: Quantity invalid!";
    String PRICE_NOT_DESC = "Error: Price not desc";
    String QUANTITY_NOT_ASC = "Error: Quantity not asc";
    String DELETE_CAMPAIGN_SUCCESS = "Success: Delete campaign successfully";
    String NOT_FOUND_CAMPAIGN_ERROR = "Error: Campaign not found!";
    String CHANGE_STATUS_CAMPAIGN_SUCCESS = "Success: Change status campaign successfully";
    String START_TIME_INVALID = "Error: Start time invalid!";
    String CAMPAIGN_STARTING = "Error: Campaign is starting so can not be changed";
    String CAMPAIGN_ENDED = "Error: Campaign ended so can not be changed";
    String SHOP_MISSING_WARD = "Error: Shop is missing ward information, please add ward for shop";
    String CAMPAIGN_NOT_STARTING = "Error: Campaign not starting";
    String PRODUCT_NOT_HAVE_THIS_INSTOCK = "Error: product not have this instock!";
    String IN_STOCK_NOT_FOUND = "Error: in stock not found!";
    String IN_STOCK_PRODUCT_NOT_ENOUGH = "Error: The inStock of value property not enough!";
    String PRODUCT_IN_ANOTHER_CAMPAIGN_WAITING_START = "Error: product is in another campaign that is waiting start!";
    String PRODUCT_IN_ANOTHER_CAMPAIGN_STARTING = "Error: product is in another campaign that is starting!";

    // Shop
    String GET_DETAIL_SHOP_SUCCESS = "Success: Get detail shop successfully";
    String UPDATE_SHOP_SUCCESS = "Success: update shop information successfully";

    // Auth

    String USERNAME_EXIST = "Error: Username is already taken!";
    String EMAIL_EXIST = "Error: Email is already in use!";
    String ACCOUNT_LOCKED = "Error: Account is locked";
    String LOGIN_ERROR = "Username or password incorrect";
    String REFRESH_TOKEN_NOT_FOUND = "Error: Refresh token is not in database!";
    String REFRESH_TOKEN_EXPIRED = "Error: Refresh token was expired. Please make a new login request";
    String INVALID_ACCESS_TOKEN = "Error: Invalid access token";
    String LOGOUT_ERROR = "Error: UserId not exist";
    String TOKEN_EXPRIED = "Error: Token is expried";

    /**
     * Origin
     */
    String GET_ALL_ORIGIN = "Success: get all origin successfully";

    /**
     * Category
     */
    String GET_ALL_CATEGORY = "Success: get all Category successfully";

    /**
     * Brand
     */
    String GET_ALL_BRAND = "Success: get all brand successfully";

    /**
     * District
     */
    String GET_ALL_DISTRICT = "Success: get all distric successfully";
    String GET_DISTRICT_BY_CITY_ID = "Success: get distric by cityId successfully";

    /**
     * Delivery
     */
    String GET_ALL_DELIVERY_SUCCESS = "Success: get all delivery successfully";

    /**
     * Payment
     */
    String GET_ALL_PAYMENT = "Success: get all payment successfully";

    /**
     * User
     */
    String GET_ALL_USER = "Success: get all user successfully";
    String GET_USER_BY_ID = "Success: get user by id successfully";
    String GET_USER_BY_FIRST_NAME = "Success: get user by firstname successfully";
    String CHANGE_PASSWORD_SUCCESS = "Success: change password successfully";
    String CHANGE_PASSWORD_ERROR = "Error: Password incorrect";
    String SEND_EMAIL_SUCCESS = "Success: send otp successfully";
    String SEND_EMAIL_FAIL = "Fail : send OTP failed! . Because email doesn`t exist or not valid";
    String CONFIRM_OTP_SUCCESS = "Success: confirm otp successfully";
    String CONFIRM_OTP_FAIL = "Fail; confirm otp failed!";
    String DEPOSIT_SUCCESS = "Success: Deposit request has sent successfully";
    String WITHDRAW_SUCCESS = "Success: Withdraw request has sent successfully";
    String WITHDRAW_ERROR = "Error: Money in the wallet is not enough";

    /**
     * City
     */
    String GET_ALL_CITY = "Success: get all city successfully";

    /**
     * Ward
     */
    String GET_ALL_WARD = "Success: get all ward successfully";
    String GET_WARD_BY_DISTRICT_ID = "Success: get ward by districtId successfully";
    String GET_WARD_BY_ID_FAIL = "Fail: get ward by id failed!";

    /**
     * Campaign
     */
    String GET_ALL_CAMPAIGN_SUCCESS = "Success: get all Campaign successfully";
    String GET_CAMPAIGN_BY_SHOP_SUCCESS = "Success: get campaign by shop successfully";
    String GET_CAMPAIGN_BY_SHOP_ID_FAIL = "Fail: get campaign by shopId failed!";
    String GET_CAMPAIGN_BY_ID_SUCCESS = "Success: get campaign by id successfully";
    String GET_CAMPAIGN_BY_ID_FAIL = "Fail: get campaign by id failed!";
    String GET_CAMPAIGN_BY_USER_ID_SUCCESS = "Success: get campaing by userId successfully";
    String GET_CAMPAIGN_BY_USER_ID_FAIL = "Fail: get campaign by userId failed!";
    String CAMPAIGN_NOT_FOUND = "Campaign not found";
    String PERMISSION_NOT_FOUND = "Permission not found";
    String CITY_NOT_FOUND = "City not found";
    String PRODUCT_IMAGE_NOT_FOUND = "Product image not found";
    String SHIPPING_ADDRESS_NOT_FOUND = "Shipping not found";
    String PRODUCT_NOT_FOUND = "Product not found";
    String WALLET_NOT_FOUND = "Wallet not found!";
    String ORDER_NOT_FOUND = "Order not found!";
    String USER_NOT_FOUND = "User not found!";
    String PAYMENT_NOT_FOUND = "Payment not found!";
    String DELIVERY_NOT_FOUND = "Delivery not found!";
    String ORDERITEM_NOT_FOUND = "OrderItem not found!";
    String BUY_TYPE_NOT_FOUND = "BuyType not found!";

    // CartItem
    String CREATE_CART_ITEM_SUCCESS = "Success: Add product to cart successfully";
    String FIND_CART_ITEM_BY_USERID_SUCCESS = "Success: Get all cart item in shopping cart successfully";
    String DELETE_CART_ITEM_SUCCESS = "Success: Delete cart item successfully";
    String CHANGE_QUANTITY_CART_ITEM_SUCCESS = "Success: Change quantity of cart item successfully ";
    String CHANGE_PROPERTY_CART_ITEM_SUCCESS = "Success: Change property of cart item successfully ";
    String NOT_FOUND_CART_ITEM_ERROR = "Error: Cart item not found!";
    String GET_SHIPPING_FEE_SUCCESS = "Success: Get sum shipping fee successfully";
    String IN_STOCK_PROPERTY_INVALID = "Error: Product don't have this in stock product";
    String CAMPAIGN_NOT_HAVE_PROPERTY = "Error: Campaign don't have this in stock product";
    String ID_INVALID = "Error: Id invalid";
    String IN_STOCK_PRODUCT_NOT_FOUND = "Error: In stock product not found";
    String MISSING_IN_STOCK_PRODUCT = "Error: You have to enter in stock product";
    String CART_ITEM_NOT_FOUND = "Error: Cart item not found";
    String GET_LIST_CART_ITEM_CHECKOUT_SUCCESS = "Success: get list cart item checkout successfully";

    /**
     * ShippingAddress
     */
    String CREATE_SHIPPING_ADDRESS_SUCCESS = "Success: create shipping address successfully";
    String CREATE_SHIPPING_ADDRESS_FAIL = "Fail: create shipping address failed!";
    String GET_SHIPPING_ADDRESS_BY_USER_ID_SUCCESS = "Success: get shipping address by userId successfully";
    String GET_SHIPPING_ADDRESS_BY_ID_FAIL = "Fail: get shipping address by id fail";
    String UPDATE_SHIPPING_ADDRESS_FAIL = "Fail: update shipping address failed!";
    String UPDATE_SHIPPING_ADDRESS_SUCCESS = "Success: update shipping address successfully";
    String DELETE_SHIPPING_ADDRESS_FAIL = "Fail: delete shipping address failed!";
    String DELETE_SHIPPING_ADDRESS_SUCCESS = "Success: delete shipping address successfully";
    String CHANGE_DEFAULT_SHIPPING_ADDRESS_FAIL = "Fail: change default shipping address failed!";
    String CHANGE_DEFAULT_SHIPPING_ADDRESS_SUCCESS = "Success: change default shipping address successfully";
    String GET_DEFAULT_SHIPPING_ADDRESS_SUCCESS = "Success: get shipping address successfully!";
    String ERROR_GET_DEFAULT_SHIPPING_ADDRESS = "Error: get shipping address failed! Please create shipping address";

    //Common
    String GET_DISTANCE = "Success: get distance between two addresses successfully";
    String CREATE_SUCCESS = "Success: create successfully ";

    // productImage
    String DEFAULT_URL_INVALID = "Success: index's default product image invalid";

    //Admin
    String CONFIRM_TRANSACTION_SUCCESS = "Success: confirm transaction successfully";
    String TRANSITION_SUCCESS_DESCRIPTION = "Success:transition successfully";
    String TRANSITION_CANCEL_DESCRIPTION = "Cancel:transition has been canceled";
    String MONEY_TRANSFER_ACTIVITY_NOT_FOUND = "Error: money transfer activity not found!";
    String ERROR_TRANSACTION_HAS_CONFIRMED_OR_CANCELLED = "Error: transaction has confirmed or cancelled";
    String ADMIN_NOT_ENOUGH_MONEY = "Error: admin not have enough money, please deposit";
    String USER_NOT_ENOUGH_MONEY = "Error: user not have enough money in wallet";

    String GET_ALL_MONEY_TRANSFER_SUCCESS = "Success: get all money transfer successfully";

    String FILTER_MONEY_TRANSFER_STATUS_NOT_FOUND = "Error: filter money transfer not found";


    // Property
    String GET_ALL_PROPERTY_SUCCESS = "Success: get all property successfully";

    // Value property
    String GET_ALL_VALUE_PROPERTY_SUCCESS = "Success: get all value property successfully";
    String UPDATE_PRODUCT_ERROR = "Error: Campaign that have this product is ongoing or not start!";

    //Create list invoice
    String PRODUCT_OUT_OF_STOCK = "Error: Product is out of stock, check again please!";
    String CALCULATE_SHIPPING_FEE_ERROR = "Error: An error occurred when calculating the shipping fee";
    String WALLET_NOT_ENOUGH_MONEY = "Error: Wallet not have enough money";
    String PAYMENT_SUCCESS = "Success: Payment successfully";
    String IN_STOCK_NOT_ENOUGH = "Error: In stock of product not enough";
    String IN_STOCK_OF_PROPERTY_NOT_ENOUGH = "Error: In stock of this property not enough";
    String CART_ITEM_NOT_HAVE_PROPERTY = "Error: cartItem not have property ";
    String GET_LIST_INVOICE_SUCCESS = "Success: get list invoice successfully";
    String FILTER_INVOICE_STATUS_NOT_FOUND = "Error: filter invoice status not found";
    String GET_DETAIL_INVOICE_SUCCESS = "Success: Get detail invoice successfully";
    String NOT_FOUND_INVOICE_ERROR = "Error: Invoice not found!";
    String CHANGE_STATUS_INVOICE_SUCCESS = "Success: Change status invoice successfully";
    String INVOICE_NOT_FOUND = "Error: Invoice not found";
    String COMPLETED_INVOICE_SUCCESS = "Success: Completed invoice successfully";
    String CHANGE_STATUS_INVOICE_ERROR = "Status of this invoice can not change";
    String NOT_FOUND_SHIPPING_ADDRESS_ERROR = "Not found shipping address";
    String CANCEL_RETURN_INVOICE_SUCCESS = "Success: cancel return invoice successfully";

    //Wallet
    String MONEY_TOP_UP_INVALID = "Error: The amount you want to topup must be greater than 0";
    String MONEY_WITHDRAW_INVALID = "Error: The amount you want to withdraw must be greater than 0";
    String DESCRIPTION_ACTIVITY_WAITING = "Waiting: Request is pending confirmation";

    String GET_STATISTICAL_SUCCESS = "Success: get statistical successfully";
}
