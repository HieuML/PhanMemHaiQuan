package com.example.demo.security.authService;

import com.example.demo.dto.request.authReq.*;
import com.example.demo.dto.response.BaseRes;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Service
public interface AuthService {
    BaseRes<?> getMe(HttpServletRequest request);

    BaseRes<?> authenticateUser(LoginReq loginReq);

    BaseRes<?> registerUser(RegisterReq registerReq);

    BaseRes<?> refreshtokenUser(TokenRefreshReq request);

    BaseRes<?> logoutUser(LogOutReq logOutReq);

    BaseRes<?> updateInfoUser(HttpServletRequest request, UpdateUserReq updateUserReq);

}
