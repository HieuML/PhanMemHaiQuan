package com.example.demo.service.wardService;

import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.wardRes.WardRes;

import java.util.List;

public interface WardService {
    /**
     * get all ward
     *
     * @return
     */
    BaseRes getAll();

    /**
     * get ward by districID
     *
     * @param districtID
     * @return
     */
    List<WardRes> getWardByDistrict(Integer districtID);
}
