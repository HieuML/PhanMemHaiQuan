package com.example.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class PageRes {
    private Integer totalPage;
    private Integer pageSize;
    private Integer pageIndex;
    private Boolean hasNextPage;

    public PageRes() {

    }
}
