package com.example.demo.dto.request.productReq;

import com.example.demo.dto.request.inStockProductReq.InstockProductReq;
import lombok.Data;

import java.util.ArrayList;

@Data
public class CreateOrUpdateProductReq {
    private String name;
    private String description;
    private Integer price;
    private Integer originPrice;
    private Integer brandID;
    private Integer categoryID;
    private Integer originID;
    private ArrayList<String> listUrl;
    private Integer defaultUrl;
    private Integer propertyID;
    private Integer inStock;
    private ArrayList<InstockProductReq> listInStockProduct;
}
