package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.districtService.DistrictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
//all
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/district")
public class DistrictController {
    @Autowired
    private DistrictService districtService;

    @GetMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAll() {
        return ResponseEntity.ok(districtService.getAll());
    }

    @GetMapping(Path.GET_DISTRICT_BY_CITY)
    public ResponseEntity<BaseRes> getByCity(@PathVariable Integer cityID) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(),
                TextStatus.GET_DISTRICT_BY_CITY_ID,
                districtService.getDistrictByCity(cityID)));
    }
}
