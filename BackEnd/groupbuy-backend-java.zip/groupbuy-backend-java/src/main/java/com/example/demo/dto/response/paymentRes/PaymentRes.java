package com.example.demo.dto.response.paymentRes;

import com.example.demo.dto.response.IdNameRes;

public class PaymentRes extends IdNameRes {
    public PaymentRes(Integer id, String name) {
        super(id, name);
    }
}
