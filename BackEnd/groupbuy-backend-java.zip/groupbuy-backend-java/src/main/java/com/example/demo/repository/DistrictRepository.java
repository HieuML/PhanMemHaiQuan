package com.example.demo.repository;

import com.example.demo.entities.District;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DistrictRepository extends JpaRepository<District, Integer> {
    District findByDistrictID(Integer districtID);

    /**
     * get district by cityId
     *
     * @param cityId
     * @return
     */
    List<District> getDistrictsByCityCityID(Integer cityId);
}
