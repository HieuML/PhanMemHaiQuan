package com.example.demo.service.categoryService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.categoryRes.CategoryRes;
import com.example.demo.entities.Brand;
import com.example.demo.entities.Category;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.service.categoryService.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public BaseRes getAll() {
        try {
            return new BaseRes<>(HttpStatus.OK.value(),
                    TextStatus.GET_ALL_CATEGORY,
                    categoryRepository.findAll()
                            .stream()
                            .map(x -> CategoryRes.convertFromEntity(x))
                            .collect(Collectors.toList()));
        } catch (Exception error) {
            return new BaseRes<>(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    TextStatus.INTERNAL_SERVER_ERROR,
                    null);
        }
    }

    @Override
    public BaseRes create(RequestName name) {
        Optional<Category> entity = categoryRepository.findCategoryByName(name.getName());
        if (entity.isPresent()) {
            return new BaseRes(HttpStatus.BAD_REQUEST.value(),
                    TextStatus.NAME_HAS_EXISTED,
                    null);
        }
        Category newCategory = new Category();
        newCategory.setName(name.getName());
        newCategory.setCreatedAt(new Date().getTime());
        newCategory.setUpdatedAt(new Date().getTime());
        categoryRepository.save(newCategory);
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.CREATE_SUCCESS,
                CategoryRes.convertFromEntity(categoryRepository.findCategoryByName(name.getName()).get()));
    }

    @Override
    public BaseRes update(IdNameReq req) {
        Optional<Category> entity = categoryRepository.findById(req.getId());
        Optional<Category> categoryHasSameName = categoryRepository.findCategoryByName(req.getName());
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);

        if (categoryHasSameName.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(),
                    TextStatus.NAME_HAS_EXISTED,
                    null);

        Category entityUpdate = entity.get();
        entityUpdate.setName(req.getName());
        entityUpdate.setUpdatedAt(new Date().getTime());
        categoryRepository.save(entityUpdate);
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.UPDATE_SUCCESS,
                new BaseUpdated<>(entityUpdate.getCategoryID(), true)
        );
    }

    @Override
    public BaseRes delete(Integer categoryID) {
        Optional<Category> entity = categoryRepository.findById(categoryID);
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);

        categoryRepository.delete(entity.get());
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.DELETE_SUCCESS,
                new BaseUpdated<>(entity.get().getCategoryID(), true)
        );
    }
}
