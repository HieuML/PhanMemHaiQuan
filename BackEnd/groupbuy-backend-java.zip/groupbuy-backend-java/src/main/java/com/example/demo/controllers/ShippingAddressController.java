package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.dto.request.shippingAddressReq.ShippingAddressCreateReq;
import com.example.demo.dto.request.shippingAddressReq.ShippingAddressUpdateReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.shippingAddressService.ShippingAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;



@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/shipping-address")
public class ShippingAddressController {
    @Autowired
    private ShippingAddressService shippingAddressService;

    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<BaseRes> createShippingAddress(HttpServletRequest request, @RequestBody ShippingAddressCreateReq req) {
        return ResponseEntity.ok(shippingAddressService.create(request, req));
    }

    @PreAuthorize("hasRole('CUSTOMER')")
    @GetMapping(Path.GET_SHIPPING_ADDRESS_DEFAULT_BY_USER)
    public ResponseEntity<BaseRes> getShippingAddressDefault(HttpServletRequest request) {
        return ResponseEntity.ok(shippingAddressService.getAddressDefault(request));
    }

    //All cac cai khac la Customer
    @GetMapping(Path.GET_BY_USER)
    public ResponseEntity<BaseRes> getShippingAddressByUser(HttpServletRequest request) {
        return ResponseEntity.ok(shippingAddressService.getByUser(request));
    }

    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping(Path.UPDATE)
    public ResponseEntity<BaseRes> updateShippingAddress(HttpServletRequest request, @RequestBody ShippingAddressUpdateReq req) {
        return ResponseEntity.ok(shippingAddressService.update(request, req));
    }

    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping(Path.DELETE_ADDRESS)
    public ResponseEntity<BaseRes> deleteShippingAddress(HttpServletRequest request, @PathVariable Integer shippingAddressID) {
        return ResponseEntity.ok(shippingAddressService.delete(request, shippingAddressID));
    }

    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping(Path.CHANGE_DEFAULT_SHIPPING_ADDRESS)
    public ResponseEntity<BaseRes> changeDefaultShippingAddress(HttpServletRequest request, @PathVariable Integer shippingAddressID) {
        return ResponseEntity.ok(shippingAddressService.changeDefaultAddress(request, shippingAddressID));
    }
}
