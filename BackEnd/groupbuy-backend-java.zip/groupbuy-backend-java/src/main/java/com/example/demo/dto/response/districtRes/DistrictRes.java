package com.example.demo.dto.response.districtRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.District;

public class DistrictRes extends IdNameRes {
    public DistrictRes(Integer id, String name) {
        super(id, name);
    }

    public static DistrictRes convertFromEntity(District district) {
        return new DistrictRes(district.getDistrictID(), district.getName());
    }
}
