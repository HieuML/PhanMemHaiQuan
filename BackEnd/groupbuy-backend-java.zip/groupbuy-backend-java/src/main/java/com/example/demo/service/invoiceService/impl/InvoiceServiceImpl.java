package com.example.demo.service.invoiceService.impl;

import com.example.demo.constants.AdminAccount;
import com.example.demo.constants.RoleName;
import com.example.demo.constants.Status;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.cartItemReq.GetShippingFeeReq;
import com.example.demo.dto.request.invoiceReq.CreateListInvoiceReq;
import com.example.demo.dto.request.invoiceReq.GetLstInvoiceReq;
import com.example.demo.dto.request.invoiceReq.InvoiceReq;
import com.example.demo.dto.response.PageRes;
import com.example.demo.dto.response.invoiceRes.GetLstInvoiceRes;
import com.example.demo.dto.response.invoiceRes.InvoiceItemRes;
import com.example.demo.dto.response.invoiceRes.InvoiceRes;
import com.example.demo.entities.*;
import com.example.demo.exception.*;
import com.example.demo.repository.*;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.campaignService.CampaignService;
import com.example.demo.service.invoiceService.InvoiceService;
import com.example.demo.service.cartItemService.CartItemService;
import com.example.demo.utils.CommonMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@Service
public class InvoiceServiceImpl implements InvoiceService {
    @Autowired
    private InvoiceRepository invoiceRepository;
    @Autowired
    private ShippingAddressRepository shippingAddressRepository;
    @Autowired
    private CartItemRepository cartItemRepository;
    @Autowired
    private DeliveryRepository deliveryRepository;
    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private ShopRepository shopRepository;
    @Autowired
    private CartItemService cartItemService;
    @Autowired
    private WalletRepository walletRepository;
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private MoneyTransferActivityRepo moneyTransferActivityRepo;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CampaignRepository campaignRepository;
    @Autowired
    private InStockProductRepository inStockProductRepository;
    @Autowired
    private PriceLevelRepository priceLevelRepository;
    @Autowired
    private InvoiceItemRepository invoiceItemRepository;
    @Autowired
    private BuyTypeRepository buyTypeRepository;

    @Autowired
    private CampaignService campaignService;

    private void convertToDTO(GetLstInvoiceRes rs, Page<Invoice> invoicePage) {
        List<InvoiceRes> lstInvoiceRes = new ArrayList<>();
        PageRes pageRes = new PageRes();
        Map<Invoice, List<InvoiceItemRes>> mapInvoiceToLstInvoiceItem = new LinkedHashMap<>();
        pageRes.setPageIndex(invoicePage.getNumber());
        pageRes.setPageSize(invoicePage.getSize());
        pageRes.setTotalPage(invoicePage.getTotalPages());
        pageRes.setHasNextPage(invoicePage.hasNext());
        List<Invoice> entitiesInvoice = invoicePage.getContent();
        entitiesInvoice.stream().forEach(x ->
                mapInvoiceToLstInvoiceItem.put(x,
                        invoiceItemRepository
                                .findByInvoiceInvoiceID(x.getInvoiceID())
                                .stream().map(y -> new InvoiceItemRes(y, campaignRepository))
                                .collect(Collectors.toList())));
        //check status campaign
        entitiesInvoice.stream().forEach(x -> {
            invoiceItemRepository.findByInvoiceInvoiceID(x.getInvoiceID()).stream().forEach(s -> {
                Optional<Campaign> _campaign = campaignRepository.findByProductProductIDAndStatus(s.getProduct().getProductID(), Status.STARTING);
                if (_campaign.isPresent()) {
                    campaignService.checkStatusCampaign(_campaign.get().getCampaignID());
                }
            });
        });

        mapInvoiceToLstInvoiceItem.entrySet().stream().forEach(x ->
                lstInvoiceRes.add(new InvoiceRes(x.getValue(), x.getKey()))
        );
        List<InvoiceRes> lstInvoiceResSort = lstInvoiceRes.stream().sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt())).collect(Collectors.toList());
        rs.setLstInvoiceRes(lstInvoiceResSort);
        rs.setPageRes(pageRes);
        rs.setTotalItem(lstInvoiceRes.size());
    }

    @Override
    public String createListInvoice(HttpServletRequest servletRequest, CreateListInvoiceReq createListInvoiceReq) {
        Map<InvoiceReq, List<CartItem>> mapLstCartItemToInvoiceReq = new HashMap<>();
        createListInvoiceReq.getListInvoiceReq().stream()
                .forEach(x -> {
                    List<CartItem> lstCartItemOfInvoice = x.getListCartItemID()
                            .stream()
                            .map(y -> cartItemRepository.findById(y).get()).collect(Collectors.toList());
                    mapLstCartItemToInvoiceReq.put(x, lstCartItemOfInvoice);
                });
        //Check số lượng sản phẩm
        AtomicReference<Boolean> checkQuantityOfProduct = new AtomicReference<>(true);
        List<CartItem> allCartItemFromUI = new ArrayList<>();
        mapLstCartItemToInvoiceReq.entrySet().stream().forEach((x) ->
                allCartItemFromUI.addAll(x.getValue())
        );
        allCartItemFromUI.stream().takeWhile(x -> checkQuantityOfProduct.get() == true).forEach(x -> {
            if (!x.getStatus())
                checkQuantityOfProduct.set(false);
        });
        if (!checkQuantityOfProduct.get())
            throw new BadRequestException(TextStatus.PRODUCT_OUT_OF_STOCK);
        //lấy ra thông tin ví người dùng
        Integer userId = userRepository.findByUsername(CommonMethod.getUsernameFromJwt(servletRequest, jwtUtils)).get().getId();
        Wallet walletUser = walletRepository.findByUserId(userId);
        List<Invoice> lstInvoice = new ArrayList<>();
        AtomicReference<Integer> moneyMustBePaid = new AtomicReference<>(0);
        List<InvoiceItem> lstNewInvoiceItem = new ArrayList<>();
        Payment paymentOfListInvoice = paymentRepository.findById(createListInvoiceReq.getPaymentID()).get();
        Payment paymentOfByTogether = paymentRepository.findById(2).get();
        //Thanh toán tiền sau khi nhận hàng
        Optional<ShippingAddress> _shippingAddress = shippingAddressRepository
                .findById(createListInvoiceReq.getShippingAddressID());
        if (_shippingAddress.isEmpty())
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_SHIPPING_ADDRESS_ERROR);
        ShippingAddress shippingAddress = _shippingAddress.get();
        mapLstCartItemToInvoiceReq.entrySet().stream().forEach(x -> {
            Invoice newInvoice = new Invoice();
            //số tiền phải thanh toán phải bằng tổng số tiền deposit
            newInvoice.setDelivery(deliveryRepository.findById(x.getKey().getDeliveryID()).get());
            // Nếu là mua chung thì payment luôn là trả sau
            newInvoice.setPayment((x.getKey().getBuyTypeID() == 2) ? paymentOfByTogether : paymentOfListInvoice);
            newInvoice.setStatus(Status.WAITING_CONFIRM);
            newInvoice.setShop(shopRepository.findById(x.getKey().getShopID()).get());
            newInvoice.setCreatedAt(new Date().getTime());
            newInvoice.setUpdatedAt(new Date().getTime());
            newInvoice.setShippingAddress(shippingAddress.getAddressDetail());
            newInvoice.setConsigneeName(shippingAddress.getConsigneeName());
            newInvoice.setConsigneePhone(shippingAddress.getPhone());
            newInvoice.setUser(shippingAddress.getUser());
            newInvoice.setBuyType(buyTypeRepository.findById(x.getKey().getBuyTypeID()).get());
            //shipping fee
            Integer shippingFee = 0;
            GetShippingFeeReq getShippingFeeReq = new GetShippingFeeReq();
            getShippingFeeReq.setUserLocation(shippingAddressRepository.findById(createListInvoiceReq.getShippingAddressID()).get().getAddressDetail());
            getShippingFeeReq.setShopID(x.getKey().getShopID());
            getShippingFeeReq.setDeliveryID(x.getKey().getDeliveryID());
            Boolean testCalculateShippingFee = true;
            try {
                shippingFee = cartItemService.getShippingFee(getShippingFeeReq);
            } catch (Exception e) {
                testCalculateShippingFee = false;
            }
            if (!testCalculateShippingFee)
                throw new BadRequestException(TextStatus.CALCULATE_SHIPPING_FEE_ERROR);
            //sumPrice
            AtomicReference<Integer> sumPrice = new AtomicReference<>(0);
            //sumDeposit (Theo xử lý của Hiếu)
            AtomicReference<Integer> sumDeposit = new AtomicReference<>(0);
            x.getValue().stream().forEach(y ->
                    sumDeposit.updateAndGet(v -> v + (y.getDeposit() * y.getQuantity())));
            x.getValue().stream().forEach(y ->
                    sumPrice.updateAndGet(v -> v + (y.getPriceCurrent() * y.getQuantity())));
            //thanh toán sau khi nhận hàng
            if (createListInvoiceReq.getPaymentID() == 2) {
                //nếu là mua chung
                if (x.getKey().getBuyTypeID() == 2)
                    newInvoice.setPaidAmount(sumDeposit.get());
                else
                    newInvoice.setPaidAmount(0);
            } else {
                //thanh toán qua ví
                //set paidAmount theo buyType
                if (x.getKey().getBuyTypeID() == 1) {
                    newInvoice.setPaidAmount(sumPrice.get() + shippingFee);
                } else {
                    newInvoice.setPaidAmount(sumDeposit.get());
                }
            }
            newInvoice.setShippingFee(shippingFee);
            newInvoice.setTotalAmount(sumPrice.get());
            lstInvoice.add(newInvoice);
            //tạo invoiceItem
            x.getValue().stream().forEach(ci -> {
                InvoiceItem invoiceItem = new InvoiceItem();
                invoiceItem.setInvoice(newInvoice);
                invoiceItem.setQuantity(ci.getQuantity());
                invoiceItem.setPriceCurrent(ci.getPriceCurrent());
                invoiceItem.setDeposit(ci.getDeposit());
                invoiceItem.setProduct(ci.getProduct());
                invoiceItem.setInStockProduct(ci.getInStockProduct());
                invoiceItem.setBuyType(ci.getBuyType());
                invoiceItem.setCreatedAt(new Date().getTime());
                invoiceItem.setUpdatedAt(new Date().getTime());
                invoiceItem.setIsFinalPrice(ci.getBuyType().getBuyTypeID() == 2 ? false : true);
                lstNewInvoiceItem.add(invoiceItem);
            });
        });
        lstInvoice.stream().forEach(invoice -> moneyMustBePaid.updateAndGet(v -> v + invoice.getPaidAmount()));
        //check tiền trong ví xem có đủ để thanh toán hay không
        if (walletUser.getMoney() < moneyMustBePaid.get())
            throw new BadRequestException(TextStatus.WALLET_NOT_ENOUGH_MONEY);
        CommonMethod.moneyTransfer(userId, userRepository.findUserByUsername(AdminAccount.USERNAME).get().getId(),
                moneyMustBePaid.get(),
                walletRepository);
        //tạo lịch sử chuyển tiền
        MoneyTransferActivity moneyTransferActivity = new MoneyTransferActivity(
                userId, userRepository.findUserByUsername(AdminAccount.USERNAME).get().getId(),
                moneyMustBePaid.get(), Status.CONFIRMED, TextStatus.TRANSITION_SUCCESS_DESCRIPTION);
        //lưu lịch sử chuyển tiền
        moneyTransferActivityRepo.save(moneyTransferActivity);
        //tạo list invoice
        invoiceRepository.saveAll(lstInvoice);
        //tạo invoiceItem dựa theo cardItem
        invoiceItemRepository.saveAll(lstNewInvoiceItem);
//        cartItemRepository.deleteAll(allCartItemFromUI);
        Map<CartItem, Product> lstProductBuySeparately = new HashMap<>();
        Map<CartItem, Product> lstProductBuyTogether = new HashMap<>();
        mapLstCartItemToInvoiceReq.entrySet().stream()
                .forEach(x -> {
                    if (x.getKey().getBuyTypeID() == 1) {
                        x.getValue().stream().forEach(y -> {

                            Product product = y.getProduct();
                            lstProductBuySeparately.put(y, y.getProduct());
                        });
                    } else {
                        x.getValue().stream().forEach(y -> lstProductBuyTogether.put(y, y.getProduct()));
                    }
                });
        //Nếu là mua riêng: trừ instock của sản phẩm và cộng soldQuantity
        if (lstProductBuySeparately.size() > 0) {
            lstProductBuySeparately.entrySet().stream().forEach(x -> {
                Product updateProduct = x.getValue();
                updateProduct.setSoldQuantity(updateProduct.getSoldQuantity() + x.getKey().getQuantity());
                updateProduct.setInStock(updateProduct.getInStock() - x.getKey().getQuantity());
                //trừ instock của value_property
                if (x.getKey().getInStockProduct() != null) {
                    InStockProduct instockProductUpdate = inStockProductRepository
                            .findByProductProductIDAndInStockProductID(updateProduct.getProductID()
                                    , x.getKey().getInStockProduct().getInStockProductID()).get();
                    //set instock cho instockProduct
                    instockProductUpdate.setInStock(instockProductUpdate.getInStock() - x.getKey().getQuantity());
                    //set status cho các cartItem khác
                    List<CartItem> lstCartItemUpdateStatus = cartItemRepository
                            .findByProductProductIDAndBuyTypeBuyTypeID
                                    (updateProduct.getProductID(), 1);
                    lstCartItemUpdateStatus.stream().forEach(cartItem -> {
                        cartItem.setStatus(cartItem.getQuantity() > instockProductUpdate.getInStock() ? false : true);
                    });
                    inStockProductRepository.save(instockProductUpdate);
                } else {
                    //cập nhật status cho các cardItem
                    List<CartItem> lstCartItemUpdateStatus = cartItemRepository
                            .findByProductProductIDAndBuyTypeBuyTypeID(updateProduct.getProductID(), 1);
                    lstCartItemUpdateStatus.stream().forEach(cartItem -> {
                        cartItem.setStatus(cartItem.getQuantity() > updateProduct.getInStock() ? false : true);
                    });
                    cartItemRepository.saveAll(lstCartItemUpdateStatus);
                }
                productRepository.save(updateProduct);
            });
        }
        //Nếu là mua chung thì trừ instock của campaign cộng soldQuantity
        List<Campaign> campaignsUpdatePriceCurrent = new ArrayList<>();
        if (lstProductBuyTogether.size() > 0) {
            lstProductBuyTogether.entrySet().stream().forEach(x -> {
                Product updateProduct = x.getValue();
                Campaign updateCampaignSoldQuantity = campaignRepository.findByProductProductIDAndIsActive(updateProduct.getProductID(), true).get();
                updateCampaignSoldQuantity.setSoldQuantity(updateCampaignSoldQuantity.getSoldQuantity() + x.getKey().getQuantity());
                updateCampaignSoldQuantity.setInStock(updateCampaignSoldQuantity.getInStock() - x.getKey().getQuantity());
                updateCampaignSoldQuantity.setUpdatedAt(new Date().getTime());
                //Xét price_current của từng campaign có trong list cartItem
                List<PriceLevel> priceLevels = priceLevelRepository.findByCampaignCampaignID(updateCampaignSoldQuantity.getCampaignID()).stream()
                        .sorted((a, b) -> a.getQuantity().compareTo(b.getQuantity())).collect(Collectors.toList());
                PriceLevel priceLevelNow = priceLevels.stream().filter(y -> y.getIsCurrent() == true).findAny().get();
                //cập nhật lại price level
                PriceLevel priceLevelUpdate = priceLevels.stream().filter(y -> y.getQuantity() <= updateCampaignSoldQuantity.getSoldQuantity())
                        .sorted((a, b) -> b.getQuantity().compareTo(a.getQuantity())).findFirst().get();
                priceLevelNow.setIsCurrent(false);
                priceLevelNow.setUpdatedAt(new Date().getTime());
                priceLevelUpdate.setIsCurrent(true);
                priceLevelUpdate.setUpdatedAt(new Date().getTime());
                //cập nhật lại giá cho campaign
                updateCampaignSoldQuantity.setPriceCurrent(priceLevelUpdate.getPrice());
                priceLevelRepository.save(priceLevelNow);
                priceLevelRepository.save(priceLevelUpdate);
                if (x.getKey().getInStockProduct() != null) {
                    InStockProduct inStockProductUpdate =
                            inStockProductRepository.findByProductProductIDAndCampaignCampaignIDAndInStockProductID(
                                    updateProduct.getProductID(), updateCampaignSoldQuantity.getCampaignID(), x.getKey().getInStockProduct().getInStockProductID()).get();
                    inStockProductUpdate.setCampaignInStock(inStockProductUpdate.getCampaignInStock() - x.getKey().getQuantity());
                    inStockProductUpdate.setUpdatedAt(new Date().getTime());
                    List<CartItem> lstCartItemUpdateStatus = cartItemRepository
                            .findByProductProductIDAndBuyTypeBuyTypeID(updateProduct.getProductID(),
                                    2);
                    //láy các cartItem khác với cartItem đang xét
                    lstCartItemUpdateStatus.stream().forEach(cartItem -> {
                        cartItem.setStatus(cartItem.getQuantity() > inStockProductUpdate.getCampaignInStock() ? false : true);
                        cartItem.setPriceCurrent(updateCampaignSoldQuantity.getPriceCurrent());
                    });
                    inStockProductRepository.save(inStockProductUpdate);
                    cartItemRepository.saveAll(lstCartItemUpdateStatus);

                } else {
                    //Tìm kiếm những cartItem cũng tạo ra từ campaign đó. Những campaign đã kết thúc thì các cartItem sẽ có status = false
                    List<CartItem> lstCartItemUpdateStatus = cartItemRepository
                            .findByProductProductIDAndBuyTypeBuyTypeIDAndStatus(updateProduct.getProductID(), 2, true);
                    lstCartItemUpdateStatus.stream().forEach(cartItem -> {
                        cartItem.setStatus(cartItem.getQuantity() > updateCampaignSoldQuantity.getInStock() ? false : true);
                        cartItem.setPriceCurrent(updateCampaignSoldQuantity.getPriceCurrent());
                    });
                    cartItemRepository.saveAll(lstCartItemUpdateStatus);
                }
                campaignsUpdatePriceCurrent.add(updateCampaignSoldQuantity);
                //sau sẽ tối ưu tốc độ
                List<InvoiceItem> lstInvoiceItemUpdate = invoiceItemRepository.findByProductProductIDAndBuyTypeBuyTypeIDAndIsFinalPrice(updateProduct.getProductID(), 2, false);
                Map<Invoice, List<InvoiceItem>> mapInvoiceOfInvoiceItems = new HashMap<>();
                //update priceCurrent cho lst invoiceItem theo campaign
                lstInvoiceItemUpdate.stream().forEach(it -> {
                    it.setPriceCurrent(updateCampaignSoldQuantity.getPriceCurrent());
                    it.setUpdatedAt(new Date().getTime());
                    Invoice invoice = it.getInvoice();
                    if (!mapInvoiceOfInvoiceItems.containsKey(invoice))
                        mapInvoiceOfInvoiceItems.put(invoice,
                                lstInvoiceItemUpdate.stream().filter(y -> y.getInvoice().getInvoiceID().equals(invoice.getInvoiceID()))
                                        .collect(Collectors.toList()));
                });
                invoiceItemRepository.saveAll(lstInvoiceItemUpdate);
                //update toltal amount cho từng invoice
                List<Invoice> lstInvoiceUpdateToltalAmount = new ArrayList<>();
                mapInvoiceOfInvoiceItems.entrySet().stream().forEach(y -> {
                    AtomicReference<Integer> tolTalAmountPriceCurrentOfInvoiceItems = new AtomicReference<>(0);
                    y.getValue().stream().forEach(c -> tolTalAmountPriceCurrentOfInvoiceItems.updateAndGet(v -> v + c.getPriceCurrent() * c.getQuantity()));
                    y.getKey().setTotalAmount(tolTalAmountPriceCurrentOfInvoiceItems.get());
                    y.getKey().setUpdatedAt(new Date().getTime());
                    lstInvoiceUpdateToltalAmount.add(y.getKey());
                });
                //Kiểm tra xem đã vượt qua mốc lớn nhất chưa nếu rồi thì chốt giá cho các invoiceItem tạo ra từ campaign đó
                if (priceLevels.stream().noneMatch(s -> s.getQuantity() > priceLevelUpdate.getQuantity())) {
                    List<InvoiceItem> listInvoiceItem = invoiceItemRepository.findByProductProductIDAndBuyTypeBuyTypeID(updateProduct.getProductID(), 2);
                    listInvoiceItem.stream().forEach(s -> {
                        s.setIsFinalPrice(true);
                        s.setUpdatedAt(new Date().getTime());
                    });
                    invoiceItemRepository.saveAll(listInvoiceItem);
                }
                invoiceRepository.saveAll(lstInvoiceUpdateToltalAmount);
            });
        }
        campaignRepository.saveAll(campaignsUpdatePriceCurrent);
        //xóa các cartItem
        cartItemRepository.deleteAll(allCartItemFromUI);
        return lstInvoice.get(0).getInvoiceID();
    }

    @Override
    public GetLstInvoiceRes getAll(HttpServletRequest servletRequest, GetLstInvoiceReq req) {
        GetLstInvoiceRes rs = new GetLstInvoiceRes();
        org.springframework.data.domain.Sort.Order order = new org.springframework.data.domain.Sort.Order(CommonMethod.findDirection("desc"), "updatedAt");
        Pageable pagingSort = PageRequest.of(req.getPageIndex(), req.getLimit(), org.springframework.data.domain.Sort.by(order));
        String username = CommonMethod.getUsernameFromJwt(servletRequest, jwtUtils);
        Optional<User> userByUsername = userRepository.findByUsername(username);
        String filterInvoiceStatus = req.getFilterStatus();
        String roleNameUser = userByUsername.get().getRole().getName();
        Integer userID = userByUsername.get().getId();
        if (filterInvoiceStatus.equals(Status.DEFAULT) || filterInvoiceStatus.equals(Status.WAITING_CONFIRM)
                || filterInvoiceStatus.equals(Status.PROCESSING) || filterInvoiceStatus.equals(Status.SHIPPING)
                || filterInvoiceStatus.equals(Status.SHIPPING_COMPLETED) || filterInvoiceStatus.equals(Status.COMPLETED)
                || filterInvoiceStatus.equals(Status.CANCELLED) || filterInvoiceStatus.equals(Status.RETURN)) {
            switch (filterInvoiceStatus) {
                case Status.DEFAULT: {
                    //role là customer
                    if (roleNameUser.equals(RoleName.CUSTOMER)) {
                        convertToDTO(rs, invoiceRepository.findByUserId(userID, pagingSort));
                        break;
                    }
                    //role là seller
                    if (roleNameUser.equals(RoleName.SELLER)) {
                        convertToDTO(rs, invoiceRepository.findByShopShopID(
                                shopRepository.findByUserId(userID).get().getShopID(),
                                pagingSort));
                        break;
                    }
                    //role là admin
                    if (roleNameUser.equals(RoleName.ADMIN)) {
                        convertToDTO(rs, invoiceRepository.findByStatusReturningOrShippingCompletedOrCanceledReturn(pagingSort));
                        break;
                    }
                }
                case Status.RETURN: {
                    if (roleNameUser.equals(RoleName.CUSTOMER)) {
                        convertToDTO(rs, invoiceRepository.findByUserIdAndStatusContainingAndOrderByStatusDesc(userByUsername.get(), Status.RETURN, pagingSort));
                        break;
                    }
                    if (roleNameUser.equals(RoleName.SELLER)) {
                        convertToDTO(rs, invoiceRepository.findByShopShopIDAndStatusContainingAndOrderByStatusDesc(
                                shopRepository.findByUserId(userID).get(), Status.RETURN, pagingSort));
                        break;
                    }
                    if (roleNameUser.equals(RoleName.ADMIN)) {
                        convertToDTO(rs, invoiceRepository.findByStatus(Status.RETURNING, pagingSort));
                        break;
                    }
                }
                case Status.SHIPPING_COMPLETED: {
                    if (roleNameUser.equals(RoleName.CUSTOMER)) {
                        convertToDTO(rs, invoiceRepository.findByUserIdAndStatus(userID, Status.SHIPPING_COMPLETED, pagingSort));
                        break;
                    }
                    if (roleNameUser.equals(RoleName.SELLER)) {
                        convertToDTO(rs, invoiceRepository.findByShopShopIDAndStatus(shopRepository.findByUserId(userID).get().getShopID(), Status.SHIPPING_COMPLETED, pagingSort));
                        break;
                    }
                    if (roleNameUser.equals(RoleName.ADMIN)) {
                        convertToDTO(rs, invoiceRepository.findByStatus(Status.SHIPPING_COMPLETED, pagingSort));
                        break;
                    }
                }
                default: {
                    if (roleNameUser.equals(RoleName.CUSTOMER)) {
                        convertToDTO(rs, invoiceRepository.findByUserIdAndStatus(userID, filterInvoiceStatus, pagingSort));
                        break;
                    }
                    if (roleNameUser.equals(RoleName.SELLER)) {
                        convertToDTO(rs, invoiceRepository.findByShopShopIDAndStatus(shopRepository.findByUserId(userID).get().getShopID(), filterInvoiceStatus, pagingSort));
                        break;
                    }
                }
            }
            return rs;
        } else {
            throw new ResourceNotFoundException(TextStatus.FILTER_INVOICE_STATUS_NOT_FOUND);
        }
    }

    @Override
    public InvoiceRes getDetailInvoice(String invoiceID) {
        Optional<Invoice> invoiceData = invoiceRepository.findById(invoiceID);
        if (invoiceData.isEmpty())
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_INVOICE_ERROR);
        List<InvoiceItem> listInvoiceItem = invoiceItemRepository.findByInvoiceInvoiceID(invoiceID);
        //Check status campaign
        listInvoiceItem.stream().forEach(s -> {
            Optional<Campaign> _campaign = campaignRepository.findByProductProductIDAndStatus(s.getProduct().getProductID(), Status.STARTING);
            if (_campaign.isPresent()) {
                campaignService.checkStatusCampaign(_campaign.get().getCampaignID());
            }
        });
        List<InvoiceItemRes> listInvoiceItemRes = listInvoiceItem.stream().map(s -> new InvoiceItemRes(s, campaignRepository)).toList();
        return new InvoiceRes(listInvoiceItemRes, invoiceData.get());
    }

    @Override
    public void changeStatusInvoice(HttpServletRequest servletRequest, String invoiceID) {
        String username = CommonMethod.getUsernameFromJwt(servletRequest, jwtUtils);
        User user = userRepository.findByUsername(username).get();
        String roleNameUser = user.getRole().getName();
        Integer userID = user.getId();
        //Kiểm tra xem invoice có tồn tại không
        Optional<Invoice> invoiceData = invoiceRepository.findById(invoiceID);
        if (invoiceData.isEmpty())
            throw new ResourceNotFoundException(TextStatus.INVOICE_NOT_FOUND);
        Invoice invoice_ = invoiceData.get();
        if (roleNameUser.equals(RoleName.SELLER)) {
            //Kiểm tra xem shop có invoice đó không
            if (invoiceRepository.findByShopShopID(shopRepository.findByUserId(userID).get().getShopID())
                    .stream().noneMatch(s -> s.getInvoiceID() == invoiceID))
                throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            if (invoice_.getStatus().equals(Status.WAITING_CONFIRM))
                invoice_.setStatus(Status.PROCESSING);
            else if (invoice_.getStatus().equals(Status.PROCESSING))
                invoice_.setStatus(Status.SHIPPING);
            else if (invoice_.getStatus().equals(Status.SHIPPING))
                invoice_.setStatus(Status.SHIPPING_COMPLETED);
            else throw new BadRequestException(TextStatus.CHANGE_STATUS_INVOICE_ERROR);
            invoice_.setUpdatedAt(new Date().getTime());
            invoiceRepository.save(invoice_);
        } else {
            //Kiểm tra xem customer có invoice đó không
            if (invoiceRepository.findByUserId(userID)
                    .stream().noneMatch(s -> s.getInvoiceID() == invoiceID))
                throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            if (invoice_.getStatus().equals(Status.WAITING_CONFIRM))
                invoice_.setStatus(Status.CANCELLED);
            else if (invoice_.getStatus().equals(Status.SHIPPING_COMPLETED))
                invoice_.setStatus(Status.RETURNING);
            else throw new BadRequestException(TextStatus.CHANGE_STATUS_INVOICE_ERROR);
            invoice_.setUpdatedAt(new Date().getTime());
            invoiceRepository.save(invoice_);
        }
    }

    @Override
    public void completedInvoice(String invoiceID) {
        //Kiểm tra xem invoice có tồn tại không
        Optional<Invoice> invoiceData = invoiceRepository.findById(invoiceID);
        if (invoiceData.isEmpty())
            throw new ResourceNotFoundException(TextStatus.INVOICE_NOT_FOUND);
        Invoice invoice_ = invoiceData.get();

        if (!invoice_.getStatus().equals(Status.SHIPPING_COMPLETED) && !invoice_.getStatus().equals(Status.CANCELED_RETURN))
            throw new BadRequestException(TextStatus.CHANGE_STATUS_INVOICE_ERROR);
        if (invoice_.getPaidAmount() > 0) {
            Integer adminID = userRepository.findUserByUsername(AdminAccount.USERNAME).get().getId();
            Shop shop = invoice_.getShop();
            Integer userIdOfShop = shop.getUser().getId();
            // Tìm thông tin ví admin
            Wallet walletAdmin = walletRepository.findByUserId(adminID);
            Integer moneyTransfer = invoice_.getPaidAmount() - invoice_.getTotalAmount() * shop.getSystemFee().intValue() / 100;
            //Kiểm tra xem ví của Admin có đủ tiền ko
            if (walletAdmin.getMoney() > moneyTransfer) {
                CommonMethod.moneyTransfer(adminID, userIdOfShop, moneyTransfer, walletRepository);
                MoneyTransferActivity moneyTransferActivity = new MoneyTransferActivity(adminID, userIdOfShop, moneyTransfer, Status.CONFIRMED, TextStatus.TRANSITION_SUCCESS_DESCRIPTION);
                moneyTransferActivityRepo.save(moneyTransferActivity);
            } else throw new BadRequestException(TextStatus.WALLET_NOT_ENOUGH_MONEY);
        }
        invoice_.setStatus(Status.COMPLETED);
        invoice_.setUpdatedAt(new Date().getTime());
        invoiceRepository.save(invoice_);
    }


    @Override
    public void returnedInvoice(String invoiceID) {
        //Kiểm tra xem invoice có tồn tại không
        Optional<Invoice> invoiceData = invoiceRepository.findById(invoiceID);
        if (invoiceData.isEmpty())
            throw new ResourceNotFoundException(TextStatus.INVOICE_NOT_FOUND);
        Invoice invoice_ = invoiceData.get();
        if (!invoice_.getStatus().equals(Status.RETURNING))
            throw new BadRequestException(TextStatus.CHANGE_STATUS_INVOICE_ERROR);
        if (invoice_.getPaidAmount() > 0) {
            Integer adminID = userRepository.findUserByUsername(AdminAccount.USERNAME).get().getId();
            Shop shop = invoice_.getShop();
            Integer userIdOfShop = shop.getUser().getId();
            // Tìm thông tin ví admin
            Wallet walletAdmin = walletRepository.findByUserId(adminID);
            //Nếu mà paidAmount bé hơn tiền ship thì sao
            Integer moneyTransfer = invoice_.getPaidAmount() - invoice_.getShippingFee();
            //Kiểm tra xem ví của Admin có đủ tiền ko
            if (walletAdmin.getMoney() > moneyTransfer) {
                CommonMethod.moneyTransfer(adminID, userIdOfShop, moneyTransfer, walletRepository);
                MoneyTransferActivity moneyTransferActivity = new MoneyTransferActivity(adminID, userIdOfShop, moneyTransfer, Status.CONFIRMED, TextStatus.TRANSITION_SUCCESS_DESCRIPTION);
                moneyTransferActivityRepo.save(moneyTransferActivity);
            } else throw new BadRequestException(TextStatus.WALLET_NOT_ENOUGH_MONEY);
        }
        invoice_.setStatus(Status.RETURNED);
        invoice_.setUpdatedAt(new Date().getTime());
        invoiceRepository.save(invoice_);
    }

    @Override
    public void cancelReturnInvoice(String invoiceID) {
        //Kiểm tra xem invoice có tồn tại không
        Optional<Invoice> invoiceData = invoiceRepository.findById(invoiceID);
        if (invoiceData.isEmpty())
            throw new ResourceNotFoundException(TextStatus.INVOICE_NOT_FOUND);
        Invoice invoice_ = invoiceData.get();
        if (!invoice_.getStatus().equals(Status.RETURNING))
            throw new BadRequestException(TextStatus.CHANGE_STATUS_INVOICE_ERROR);
        if (invoice_.getPaidAmount() > 0) {
            Integer adminID = userRepository.findUserByUsername(AdminAccount.USERNAME).get().getId();
            Shop shop = invoice_.getShop();
            Integer userIdOfShop = shop.getUser().getId();
            // Tìm thông tin ví admin
            Wallet walletAdmin = walletRepository.findByUserId(adminID);
            Integer moneyTransfer = invoice_.getPaidAmount() - invoice_.getTotalAmount() * shop.getSystemFee().intValue() / 100;
            //Kiểm tra xem ví của Admin có đủ tiền ko
            if (walletAdmin.getMoney() > moneyTransfer) {
                CommonMethod.moneyTransfer(adminID, userIdOfShop, moneyTransfer, walletRepository);
                MoneyTransferActivity moneyTransferActivity = new MoneyTransferActivity(adminID, userIdOfShop, moneyTransfer, Status.CONFIRMED, TextStatus.TRANSITION_SUCCESS_DESCRIPTION);
                moneyTransferActivityRepo.save(moneyTransferActivity);
            } else throw new BadRequestException(TextStatus.WALLET_NOT_ENOUGH_MONEY);
        }
        invoice_.setStatus(Status.CANCELED_RETURN);
        invoice_.setUpdatedAt(new Date().getTime());
        invoiceRepository.save(invoice_);
    }
}
