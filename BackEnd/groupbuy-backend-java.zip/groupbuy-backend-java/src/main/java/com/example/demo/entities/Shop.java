package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "shop")
@Setter
@Getter
@NoArgsConstructor
public class Shop {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "shop_id")
    private Integer shopID;
    @Column(length = 45)
    private String name;
    @Column(name = "shop_image")
    private String shopImage;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_inform_id")
    private User user;
    @Column(precision = 2, scale = 1)
    @Type(type = "big_decimal")
    private java.math.BigDecimal rating;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ward_id")
    Ward ward;
    @Column(precision = 2, scale = 1, name = "system_fee")
    @Type(type = "big_decimal")
    private java.math.BigDecimal systemFee;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public Shop(User user) {
        this.user = user;
        this.name = "Shop" + user.getId();
        this.rating = new BigDecimal(0);
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
        this.systemFee = new BigDecimal(5);
    }

    public Shop(Integer shopID, String name) {
        this.shopID = shopID;
        this.name = name;
    }
}
