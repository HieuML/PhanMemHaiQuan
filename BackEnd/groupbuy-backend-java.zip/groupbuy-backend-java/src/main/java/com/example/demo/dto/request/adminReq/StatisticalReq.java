package com.example.demo.dto.request.adminReq;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
public class StatisticalReq {
    private Long startTime;
    private Long endTime;
}
