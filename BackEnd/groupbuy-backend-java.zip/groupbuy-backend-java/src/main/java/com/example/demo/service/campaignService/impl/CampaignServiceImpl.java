package com.example.demo.service.campaignService.impl;

import com.example.demo.constants.Sort;
import com.example.demo.constants.Status;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.campaignReq.*;
import com.example.demo.dto.request.priceLevelRequest.PriceLevelReq;
import com.example.demo.dto.request.campaignReq.CreateOrUpdateCampaignReq;
import com.example.demo.dto.request.campaignReq.GetAllCampaignReq;
import com.example.demo.dto.request.campaignReq.GetLstCampaignByUserIdReq;
import com.example.demo.dto.response.PageRes;
import com.example.demo.dto.response.campaignRes.CampaignRes1;
import com.example.demo.dto.response.campaignRes.GetLstCampaignRes;
import com.example.demo.dto.response.productRes.ProductRes;
import com.example.demo.dto.response.shopRes.ShopDetailRes;
import com.example.demo.entities.*;
import com.example.demo.exception.*;
import com.example.demo.repository.*;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.campaignService.CampaignService;
import com.example.demo.utils.CommonMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CampaignServiceImpl implements CampaignService {
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    PriceLevelRepository priceLevelRepository;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    CampaignRepository campaignRepository;
    @Autowired
    DistrictRepository districtRepository;
    @Autowired
    InStockProductRepository inStockProductRepository;
    @Autowired
    ValuePropertyRepository valuePropertyRepository;
    @Autowired
    CartItemRepository cartItemRepository;
    @Autowired
    InvoiceItemRepository invoiceItemRepository;

    public void checkPriceLevel(Product product_, CreateOrUpdateCampaignReq campaign, Campaign campaign_) {
        Integer product_price = product_.getPrice();
        if (campaign.getListPriceLevel() != null) {
            ArrayList<PriceLevelReq> listPriceLevel = campaign.getListPriceLevel();
            for (int i = 0; i < listPriceLevel.size(); i++) {
                Integer price = listPriceLevel.get(i).getPrice();
                Integer quantity = listPriceLevel.get(i).getQuantity();
                if (!(price >= campaign.getDeposit() && price < product_price))
                    throw new BadRequestException(TextStatus.PRICE_INVALID);
                if (i < listPriceLevel.size() - 1 && listPriceLevel.get(i + 1).getPrice() > price)
                    throw new BadRequestException(TextStatus.PRICE_NOT_DESC);
                if (!(quantity > 0 && quantity <= campaign_.getInStock()))
                    throw new BadRequestException(TextStatus.QUANTITY_INVALID);
                if (i < listPriceLevel.size() - 1 && listPriceLevel.get(i + 1).getQuantity() < quantity)
                    throw new BadRequestException(TextStatus.QUANTITY_NOT_ASC);
            }
        }
    }

    public Integer checkCreateCampaign(CreateOrUpdateCampaignReq campaign, Integer userID) {
        Integer inStock = 0;
        Optional<Product> productData = productRepository.findById(campaign.getProductID());
        if (!productData.isPresent()) {
            throw new ResourceNotFoundException(TextStatus.PRODUCT_NOT_FOUND);
        }
        Product productTmp = productData.get();
        // Kiểm tra xem sản phẩm này đã nằm trong một campaign chuẩn bị chạy hoặc đang chạy ko
        if (campaignRepository.findByProductProductIDAndStatus(productTmp.getProductID(), Status.WAITING_START).isPresent()) {
            throw new BadRequestException(TextStatus.PRODUCT_IN_ANOTHER_CAMPAIGN_WAITING_START);
        }
        if (campaignRepository.findByProductProductIDAndStatus(productTmp.getProductID(), Status.STARTING).isPresent()) {
            throw new BadRequestException(TextStatus.PRODUCT_IN_ANOTHER_CAMPAIGN_STARTING);
        }
        if (campaign.getListInStock() != null && inStockProductRepository.findByProductProductID(productTmp.getProductID()).size() != 0) {
            ArrayList<InStockProductCreCam> listInStock = campaign.getListInStock();
            Iterator<InStockProductCreCam> iterator = listInStock.iterator();
            while (iterator.hasNext()) {
                InStockProductCreCam inStockProductCreCam = iterator.next();
                //Kiểm tra các inStock xem có trong db không
                Optional<InStockProduct> inStockProductData = inStockProductRepository.findById(inStockProductCreCam.getInStockID());
                if (inStockProductData.isEmpty()) throw new ResourceNotFoundException(TextStatus.IN_STOCK_NOT_FOUND);
                InStockProduct inStockProduct = inStockProductData.get();
                //Kiểm tra xem product có các inStock đó không
                if (inStockProductRepository.findById(inStockProductCreCam.getInStockID()).get().getProduct().getProductID() != productTmp.getProductID()) {
                    throw new ResourceNotFoundException(TextStatus.PRODUCT_NOT_HAVE_THIS_INSTOCK);
                }
                //Kiểm tra xem các inStockCampaign có lớn hơn instock của các valueProperty ko
                if (inStockProductCreCam.getCampaignInStock() > inStockProduct.getInStock())
                    throw new BadRequestException(TextStatus.IN_STOCK_PRODUCT_NOT_ENOUGH);
                inStock += inStockProductCreCam.getCampaignInStock();
            }
        } else if (campaign.getInStock() != null && inStockProductRepository.findByProductProductID(productTmp.getProductID()).size() == 0) {
            inStock = campaign.getInStock();
            if (inStock > productTmp.getInStock()) throw new BadRequestException(TextStatus.IN_STOCK_INVALID);
        } else inStock = 0;

        Optional<Shop> shopData = shopRepository.findByUserId(userID);
        if (shopData.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
        }
        Shop shop = shopData.get();
        if (shop.getWard() == null) throw new BadRequestException(TextStatus.SHOP_MISSING_WARD);
        List<Product> product_list = productRepository.findByShopShopID(shop.getShopID());
        Optional<Product> product = product_list.stream().filter(s -> s.getProductID() == campaign.getProductID()).findFirst();
        if (!product.isPresent()) throw new ResourceNotFoundException(TextStatus.PRODUCT_NOT_FOUND);
        if (!product.get().getIsActive()) throw new BadRequestException(TextStatus.PRODUCT_NOT_ACTIVE);
        return inStock;
    }

    @Override
    public CampaignRes1 createCampaign(HttpServletRequest request, CreateOrUpdateCampaignReq campaign) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Integer inStock = checkCreateCampaign(campaign, userID);
        Product product = productRepository.findById(campaign.getProductID()).get();
        Shop shop = shopRepository.findByUserId(userID).get();
        Campaign newCampaign = new Campaign(campaign.getName(), campaign.getDeposit(), campaign.getStartTime(), campaign.getEndTime(), inStock, product, shop, product.getPrice());
        checkPriceLevel(product, campaign, newCampaign);
        campaignRepository.save(newCampaign);
        // Giảm instock của product và tăng instock của campaign
        if (campaign.getListInStock() != null && inStockProductRepository.findByProductProductID(campaign.getProductID()).size() != 0) {
            ArrayList<InStockProductCreCam> listInstock = campaign.getListInStock();
            Iterator<InStockProductCreCam> iterator = listInstock.iterator();
            while (iterator.hasNext()) {
                InStockProductCreCam inStockProductCreCam = iterator.next();
                InStockProduct inStockProduct = inStockProductRepository.findById(inStockProductCreCam.getInStockID()).get();
                inStockProduct.setInStock(inStockProduct.getInStock() - inStockProductCreCam.getCampaignInStock());
                inStockProduct.setCampaign(newCampaign);
                inStockProduct.setCampaignInStock(inStockProductCreCam.getCampaignInStock());
                inStockProduct.setUpdatedAt(new Date().getTime());
                inStockProductRepository.save(inStockProduct);
            }
            product.setInStock(product.getInStock() - inStock);
            product.setUpdatedAt(new Date().getTime());
            productRepository.save(product);
        } else if (campaign.getInStock() != null && inStockProductRepository.findByProductProductID(campaign.getProductID()).size() == 0) {
            newCampaign.setInStock(campaign.getInStock());
            campaignRepository.save(newCampaign);
            product.setInStock(product.getInStock() - campaign.getInStock());
            product.setUpdatedAt(new Date().getTime());
            productRepository.save(product);
        }
        if (campaign.getListPriceLevel() != null) {
            priceLevelRepository.save(new PriceLevel(0, product.getPrice(), true, newCampaign));
            campaign.getListPriceLevel().forEach(s ->
                    priceLevelRepository.save(new PriceLevel(s.getQuantity(), s.getPrice(), false, newCampaign))
            );
        }
        District district = shop.getWard().getDistrict();
        City city = district.getCity();
        Integer sumProduct = productRepository.findByShopShopID(shop.getShopID()).size();
        Integer sumCampaign = campaignRepository.findByShopShopID(shop.getShopID()).size();
        return new CampaignRes1(newCampaign, new ProductRes(product), new ShopDetailRes(shop, district, city, sumProduct, sumCampaign), priceLevelRepository, inStockProductRepository);
    }

    public boolean testOwnCampaign(HttpServletRequest request, String campaignID) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Optional<Shop> shopData = shopRepository.findByUserId(userID);
        if (shopData.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
        }

        Integer shopID = shopRepository.findByUserId(userID).get().getShopID();
        List<Campaign> campaign_list = campaignRepository.findByShopShopID(shopID);
        Optional<Campaign> campaign = campaign_list.stream().filter(s -> s.getCampaignID() == campaignID).findFirst();

        return campaign.isPresent();
    }

    public Integer checkUpdateCampaign(CreateOrUpdateCampaignReq campaign, Product product) {
        Integer inStock = 0;
        if (campaign.getListInStock() != null) {
            ArrayList<InStockProductCreCam> listInStock = campaign.getListInStock();
            Iterator<InStockProductCreCam> iterator = listInStock.iterator();
            while (iterator.hasNext()) {
                InStockProductCreCam inStockProductCreCam = iterator.next();
                //Kiểm tra các inStock xem có trong db không
                Optional<InStockProduct> inStockProductData = inStockProductRepository.findById(inStockProductCreCam.getInStockID());
                if (inStockProductData.isEmpty()) throw new ResourceNotFoundException(TextStatus.IN_STOCK_NOT_FOUND);
                InStockProduct inStockProduct = inStockProductData.get();
                //Kiểm tra xem product có các inStock đó không
                if (inStockProductRepository.findById(inStockProductCreCam.getInStockID()).get().getProduct().getProductID() != product.getProductID()) {
                    throw new ResourceNotFoundException(TextStatus.PRODUCT_NOT_HAVE_THIS_INSTOCK);
                }
                //Kiểm tra xem các inStockCampaign có lớn hơn instock của các valueProperty ko
                if (inStockProductCreCam.getCampaignInStock() > inStockProduct.getInStock() + (inStockProduct.getCampaignInStock() != null ? inStockProduct.getCampaignInStock() : 0))
                    throw new BadRequestException(TextStatus.IN_STOCK_PRODUCT_NOT_ENOUGH);
                inStock += inStockProductCreCam.getCampaignInStock();
            }
        }
        return inStock;
    }

    @Override
    public void updateCampaign(HttpServletRequest request, String campaignID, CreateOrUpdateCampaignReq campaign) {
        Optional<Campaign> campaignData = campaignRepository.findById(campaignID);
        if (campaignData.isPresent()) {
            if (!testOwnCampaign(request, campaignID)) throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            Campaign campaign_ = campaignData.get();
            if (campaign_.getProduct().getProductID() != campaign.getProductID()) {
                throw new BadRequestException(TextStatus.PRODUCT_NO_CHANGE);
            }
            if (campaign_.getStatus().equals(Status.ENDED)) {
                throw new BadRequestException(TextStatus.CAMPAIGN_ENDED);
            } else if (campaign_.getStatus().equals(Status.STARTING)) {
                throw new BadRequestException(TextStatus.CAMPAIGN_STARTING);
            }
            Product product = productRepository.findById(campaign_.getProduct().getProductID()).get();
            if (inStockProductRepository.findByCampaignCampaignID(campaignID).size() == 0) {
                if (campaign.getInStock() != null) {
                    if (campaign.getInStock() > campaign_.getInStock() + product.getInStock())
                        throw new BadRequestException(TextStatus.IN_STOCK_INVALID);
                    campaign_.setInStock(campaign.getInStock());
                } else {
                    campaign_.setInStock(0);
                }
            } else {
                campaign_.setInStock(checkUpdateCampaign(campaign, product));
            }
            checkPriceLevel(product, campaign, campaign_);
            campaign_.setName(campaign.getName());
            campaign_.setDeposit(campaign.getDeposit());
            campaign_.setStartTime(campaign.getStartTime());
            campaign_.setEndTime(campaign.getEndTime());
            campaign_.setUpdatedAt(new Date().getTime());
            campaignRepository.save(campaign_);
            // Cập nhật lại các instock của các instockProduct và product trong campaign này
            List<InStockProduct> listInStock = inStockProductRepository.findByCampaignCampaignID(campaignID);
            listInStock.forEach(s -> {
                s.setInStock(s.getInStock() + s.getCampaignInStock());
                product.setInStock(product.getInStock() + s.getCampaignInStock());
                s.setCampaign(null);
                s.setCampaignInStock(0);
                s.setUpdatedAt(new Date().getTime());
                inStockProductRepository.save(s);
            });
            if (campaign.getListInStock() != null) {
                ArrayList<InStockProductCreCam> listInstock = campaign.getListInStock();
                Integer inStock = 0;
                Iterator<InStockProductCreCam> iterator = listInstock.iterator();
                while (iterator.hasNext()) {
                    InStockProductCreCam inStockProductCreCam = iterator.next();
                    inStock += inStockProductCreCam.getCampaignInStock();
                    InStockProduct inStockProduct = inStockProductRepository.findById(inStockProductCreCam.getInStockID()).get();
                    inStockProduct.setInStock(inStockProduct.getInStock() - inStockProductCreCam.getCampaignInStock());
                    inStockProduct.setCampaign(campaign_);
                    inStockProduct.setCampaignInStock(inStockProductCreCam.getCampaignInStock());
                    inStockProduct.setUpdatedAt(new Date().getTime());
                    inStockProductRepository.save(inStockProduct);
                }
                product.setInStock(product.getInStock() - inStock);
                product.setUpdatedAt(new Date().getTime());
                productRepository.save(product);
            } else if (campaign.getInStock() != null && inStockProductRepository.findByProductProductID(campaign.getProductID()).size() == 0) {
                product.setInStock(product.getInStock() - campaign.getInStock());
                product.setUpdatedAt(new Date().getTime());
                productRepository.save(product);
            }
            //Cập nhật lại các pricelevel
            priceLevelRepository.deleteByCampaignCampaignID(campaignID);
            priceLevelRepository.save(new PriceLevel(0, campaign_.getPriceCurrent(), true, campaign_));
            campaign.getListPriceLevel().forEach(s ->
                    priceLevelRepository.save(new PriceLevel(s.getQuantity(), s.getPrice(), false, campaign_))
            );
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_CAMPAIGN_ERROR);
        }
    }

    @Override
    public void checkStatusCampaign(String campaignID) {
        Campaign campaign = campaignRepository.findById(campaignID).get();
        if (campaign.getIsActive() == true) {
            Long currentTime = new Date().getTime();
            if (currentTime > campaign.getEndTime()) {
                campaign.setStatus(Status.ENDED);
                campaign.setIsActive(false);
                campaign.setUpdatedAt(new Date().getTime());
                campaignRepository.save(campaign);
                //Cập nhật soldQuantity và instock cho product
                Product product = productRepository.findById(campaign.getProduct().getProductID()).get();
                product.setInStock(product.getInStock() + campaign.getInStock());
                product.setSoldQuantity(product.getSoldQuantity() + campaign.getSoldQuantity());
                product.setUpdatedAt(new Date().getTime());
                productRepository.save(product);
                //Cập nhật lại instock cho các inStockProduct nếu có
                List<InStockProduct> listInStockProduct = inStockProductRepository.findByCampaignCampaignID(campaignID);
                if (listInStockProduct.size() > 0) {
                    listInStockProduct.stream().forEach(s -> {
                        s.setInStock(s.getInStock() + s.getCampaignInStock());
                        s.setCampaignInStock(null);
                        s.setCampaign(null);
                        s.setUpdatedAt(new Date().getTime());
                    });
                    inStockProductRepository.saveAll(listInStockProduct);

                }
                //cập nhật lại status cho các cartItem
                List<CartItem> lstCartItemUpdateStatus = cartItemRepository.findByProductProductIDAndBuyTypeBuyTypeIDAndStatus(product.getProductID(), 2, true);
                lstCartItemUpdateStatus.stream().forEach(y -> {
                    y.setStatus(false);
                    y.setUpdatedAt(new Date().getTime());
                });
                cartItemRepository.saveAll(lstCartItemUpdateStatus);
                //cập nhật lại isFinalPrice cho các invoiceItem
                List<InvoiceItem> lstInvoiceItemUpdateIsFinalPrice = invoiceItemRepository.findByProductProductIDAndBuyTypeBuyTypeIDAndIsFinalPrice(product.getProductID(), 2, false);
                lstInvoiceItemUpdateIsFinalPrice.stream().forEach(k -> {
                    k.setIsFinalPrice(true);
                    k.setUpdatedAt(new Date().getTime());
                });
                invoiceItemRepository.saveAll(lstInvoiceItemUpdateIsFinalPrice);
            }
            if (currentTime >= campaign.getStartTime() && campaign.getStatus().equals(Status.WAITING_START)) {
                campaign.setStatus(Status.STARTING);
                campaign.setUpdatedAt(new Date().getTime());
                campaignRepository.save(campaign);
            }
        }
    }

    @Override
    public void changeActive(HttpServletRequest request, String campaignID) {
        Optional<Campaign> campaignData = campaignRepository.findById(campaignID);
        if (campaignData.isPresent()) {
            if (!testOwnCampaign(request, campaignID)) throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            Campaign campaign_ = campaignData.get();
            if (campaign_.getStatus().equals(Status.ENDED)) {
                throw new BadRequestException(TextStatus.CAMPAIGN_ENDED);
            } else if (campaign_.getStatus().equals(Status.STARTING)) {
                throw new BadRequestException(TextStatus.CAMPAIGN_STARTING);
            } else {
                if (new Date().getTime() > campaign_.getStartTime())
                    throw new BadRequestException(TextStatus.START_TIME_INVALID);
            }
            campaign_.changeIsActive();
            campaign_.setUpdatedAt(new Date().getTime());
            campaignRepository.save(campaign_);
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_CAMPAIGN_ERROR);
        }
    }

    @Override
    public void deleteCampaign(HttpServletRequest request, String campaignID) {
        Optional<Campaign> campaignData = campaignRepository.findById(campaignID);
        if (campaignData.isPresent()) {
            if (!testOwnCampaign(request, campaignID)) throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            campaignRepository.deleteById(campaignID);
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_CAMPAIGN_ERROR);
        }
    }

    public Map<String, Object> getAllCampaignByShop(GetAllCampaignReq getAllCampaignReq) {

        String campaignName = getAllCampaignReq.getCampaignName();
        Integer pageIndex = getAllCampaignReq.getPageIndex();
        Integer limit = getAllCampaignReq.getLimit();
        String sort = getAllCampaignReq.getSort();
        String sortTmp = "";
        String[] sortArr;
        if (sort.equals("DEFAULT") || sort.equals("CREATED_ASC") || sort.equals("CREATED_DESC") ||
                sort.equals("PRICE_ASC") || sort.equals("PRICE_DESC")) {
            switch (sort) {
                case "DEFAULT":
                    sortTmp = Sort.DEFAULT;
                    break;
                case "CREATED_ASC":
                    sortTmp = Sort.CREATED_ASC;
                    break;
                case "CREATED_DESC":
                    sortTmp = Sort.CREATED_DESC;
                    break;
                case "PRICE_ASC":
                    sortTmp = Sort.PRICE_ASC;
                    break;
                case "PRICE_DESC":
                    sortTmp = Sort.PRICE_DESC;
                    break;
            }
            sortArr = sortTmp.split(",");
        } else {
            throw new ResourceNotFoundException(TextStatus.ORDER_NOT_FOUND);
        }
        if (sortArr[0].equals("id")) {
            sortArr[0] = "campaignID";
        } else if (sortArr[0].equals("price")) {
            sortArr[0] = "priceCurrent";
        }
        org.springframework.data.domain.Sort.Order order = new org.springframework.data.domain.Sort.Order(CommonMethod.findDirection(sortArr[1]), sortArr[0]);
        Pageable pagingSort = PageRequest.of(pageIndex, limit, org.springframework.data.domain.Sort.by(order));
        Page<Campaign> pageCamps;
        if (getAllCampaignReq.getShopID() != null) {
            Optional<Shop> shop = shopRepository.findById(getAllCampaignReq.getShopID());
            if (shop.isEmpty()) {
                throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
            }
            if (campaignName != null && !campaignName.trim().equals("")) {
                pageCamps = campaignRepository.findByShopShopIDAndNameContaining(getAllCampaignReq.getShopID(), campaignName, pagingSort);
            } else {
                pageCamps = campaignRepository.findByShopShopID(getAllCampaignReq.getShopID(), pagingSort);
            }
        } else {
            if (campaignName != null && !campaignName.trim().equals("")) {
                pageCamps = campaignRepository.findByIsActiveAndNameContaining(true, campaignName, pagingSort);
            } else {
                pageCamps = campaignRepository.findByIsActive(true, pagingSort);
            }
        }
        List<CampaignRes1> listCampaignRes = pageCamps.getContent().stream()
                .map(x -> {
                    //Check status campaign
                    checkStatusCampaign(x.getCampaignID());
                    ProductRes productRes = new ProductRes(x.getProduct(), inStockProductRepository, valuePropertyRepository);
                    ShopDetailRes shopDetailRes = new ShopDetailRes(x.getShop(),
                            x.getShop().getWard().getDistrict(), x.getShop().getWard().getDistrict().getCity(),
                            productRepository.findByShopShopID(x.getShop().getShopID()).size(),
                            campaignRepository.findByShopShopID(x.getShop().getShopID()).size());
                    return new CampaignRes1(x, productRes, shopDetailRes, priceLevelRepository, inStockProductRepository);
                })
                .collect(Collectors.toList());

        Map<String, Object> response = new HashMap<>();
        response.put("totalItem", pageCamps.getTotalElements());
        response.put("listCampaign", listCampaignRes);
        PageRes pageRes = new PageRes(pageCamps.getTotalPages(),
                limit,
                pageIndex,
                pageIndex != pageCamps.getTotalPages() - 1
        );
        response.put("pageRes", pageRes);
        return response;
    }

    @Override
    public Optional<CampaignRes1> getByCampId(String campID) {
        //Check status campaign
        checkStatusCampaign(campID);
        Optional<Campaign> entity = campaignRepository.findById(campID);
        Integer sumProduct = productRepository.findByShopShopID(entity.get().getShop().getShopID()).size();
        Integer sumCampaign = campaignRepository.findByShopShopID(entity.get().getShop().getShopID()).size();
        if (entity.isPresent()) {
            ProductRes productRes = new ProductRes(entity.get().getProduct(), inStockProductRepository, valuePropertyRepository);
            ShopDetailRes shopDetailRes = new ShopDetailRes(entity.get().getShop(),
                    entity.get().getShop().getWard().getDistrict(), entity.get().getShop().getWard().getDistrict().getCity(),
                    sumProduct, sumCampaign);
            return Optional.of(new CampaignRes1(entity.get(), productRes, shopDetailRes, priceLevelRepository, inStockProductRepository));
        }
        throw new ResourceNotFoundException(TextStatus.NOT_FOUND_CAMPAIGN_ERROR);
    }

    public GetLstCampaignRes getByUserId(GetLstCampaignByUserIdReq req) {
        Optional<Shop> shopData = shopRepository.findByUserId(req.getUserID());
        if (shopData.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
        }
        Shop shopOption = shopData.get();
        List<String> sortArr = new ArrayList<>();
        String sortTmp = "";
        switch (req.getSort()) {
            case "DEFAULT":
                sortTmp = Sort.DEFAULT;
                break;
            case "CREATED_ASC":
                sortTmp = Sort.CREATED_ASC;
                break;
            case "CREATED_DESC":
                sortTmp = Sort.CREATED_DESC;
                break;
            case "PRICE_ASC":
                sortTmp = Sort.PRICE_ASC;
                break;
            case "PRICE_DESC":
                sortTmp = Sort.PRICE_DESC;
                break;
        }
        sortArr = Arrays.stream(sortTmp.split(",")).collect(Collectors.toList());
        if (sortArr.get(0).equals("id"))
            sortArr.set(0, "campaignID");
        org.springframework.data.domain.Sort.Order order = new org.springframework.data.domain.Sort.Order(CommonMethod.findDirection(sortArr.get(1)), sortArr.get(0));
        Pageable pageable = PageRequest.of(req.getPageIndex(),
                req.getLimit(),
                org.springframework.data.domain.Sort.by(order));
        Page<Campaign> entity = campaignRepository.findCampaignByShopShopID(shopOption.getShopID(), pageable);
        List<CampaignRes1> campaignResList = entity.getContent().stream()
                .map(x -> {
                    ProductRes productRes = new ProductRes(x.getProduct(), inStockProductRepository, valuePropertyRepository);
                    ShopDetailRes shopDetailRes = new ShopDetailRes(x.getShop(),
                            x.getShop().getWard().getDistrict(), x.getShop().getWard().getDistrict().getCity(),
                            productRepository.findByShopShopID(x.getShop().getShopID()).size(),
                            campaignRepository.findByShopShopID(x.getShop().getShopID()).size());
                    return new CampaignRes1(x, productRes, shopDetailRes, priceLevelRepository, inStockProductRepository);
                })
                .collect(Collectors.toList());
        PageRes pageRes = new PageRes(entity.getTotalPages(),
                entity.getSize(),
                entity.getPageable().getPageNumber(),
                entity.hasNext());
        GetLstCampaignRes rs = new GetLstCampaignRes(campaignResList, pageRes, entity.getTotalElements());
        return rs;
    }
}
