package com.example.demo.dto.response.deliveryRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Delivery;

public class DeliveryRes extends IdNameRes {
    public DeliveryRes(Integer id, String name) {
        super(id, name);
    }

    public static DeliveryRes convertFromEntity(Delivery delivery) {
        return new DeliveryRes(delivery.getDeliveryID(), delivery.getName());
    }
}
