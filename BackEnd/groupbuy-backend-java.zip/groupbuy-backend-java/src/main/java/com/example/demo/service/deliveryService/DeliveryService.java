package com.example.demo.service.deliveryService;

import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyCreateReq;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyUpdateReq;
import com.example.demo.dto.response.BaseRes;

public interface DeliveryService {
    /**
     * get all delivery
     *
     * @return
     */
    BaseRes getAll();

    /**
     * create delivery
     * @param req
     * @return
     */
    BaseRes create(RequestName req);

    /**
     * update delivery
     * @param req
     * @return
     */
    BaseRes update(IdNameReq req);

    /**
     * delete delivery
     * @param deliveryID
     * @return
     */
    BaseRes delete(Integer deliveryID);
}
