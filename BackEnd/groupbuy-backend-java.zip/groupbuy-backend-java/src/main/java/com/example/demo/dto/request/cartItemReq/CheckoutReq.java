package com.example.demo.dto.request.cartItemReq;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class CheckoutReq {
    List<Integer> listCartItemID;
    String userLocation;
}
