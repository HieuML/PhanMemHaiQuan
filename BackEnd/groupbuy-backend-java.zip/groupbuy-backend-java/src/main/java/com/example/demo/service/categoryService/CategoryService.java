package com.example.demo.service.categoryService;

import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import org.springframework.stereotype.Service;

@Service
public interface CategoryService {

    /**
     * get all category
     *
     * @return
     */
    BaseRes getAll();

    /**
     * create category
     *
     * @param name
     * @return
     */
    BaseRes create(RequestName name);

    /**
     * update category
     * @param req
     * @return
     */
    BaseRes update(IdNameReq req);

    /**
     * delete category
     * @param categoryID
     * @return
     */
    BaseRes delete(Integer categoryID);
}
