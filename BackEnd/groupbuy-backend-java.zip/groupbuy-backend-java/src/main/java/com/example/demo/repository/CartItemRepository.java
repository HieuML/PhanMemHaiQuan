package com.example.demo.repository;

import com.example.demo.entities.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Integer> {
    List<CartItem> findByShoppingCartShoppingCartID(Integer shoppingCartID);

    Optional<CartItem> findByShoppingCartShoppingCartIDAndProductProductIDAndBuyTypeBuyTypeID(Integer shoppingCartID, String productID, Integer BuyTypeID);

    Optional<CartItem> findByShoppingCartShoppingCartIDAndProductProductIDAndBuyTypeBuyTypeIDAndInStockProductInStockProductID(Integer shoppingCartID, String productID, Integer BuyTypeID, Integer inStockProductID);

    List<CartItem> findByProductProductIDAndBuyTypeBuyTypeIDAndStatus(String productID, Integer buyTypeID, Boolean status);

    List<CartItem> findByProductProductIDAndBuyTypeBuyTypeID(String productID, Integer buyTypeID);

    List<CartItem> findByProductProductIDAndBuyTypeBuyTypeIDAndInStockProductInStockProductID(String productID, Integer buyTypeID, Integer inStockProductID);
}
