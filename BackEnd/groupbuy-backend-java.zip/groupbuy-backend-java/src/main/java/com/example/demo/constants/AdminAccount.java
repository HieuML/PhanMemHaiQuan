package com.example.demo.constants;

public interface AdminAccount {
    String USERNAME = "admin123";
    String PASSWORD = "123456aA";
    String EMAIL = "admin123@gmail.com";
    Integer fee = 5;
}
