package com.example.demo.dto.response.statisticalRes;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
public class SumObjectByDate {
    private Long date;
    private Long sum;
}
