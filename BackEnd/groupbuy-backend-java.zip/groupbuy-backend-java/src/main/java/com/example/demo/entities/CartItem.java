package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "cart_item")
@Setter
@Getter
@NoArgsConstructor
public class CartItem {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "cart_item_id")
    private Integer cartItemId;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "shopping_cart_id", nullable = false)
    private ShoppingCart shoppingCart;
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "buy_type_id", nullable = false)
    private BuyType buyType;
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "inStock_product_id", nullable = true)
    private InStockProduct inStockProduct;
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id")
    private Product product;
    private Integer quantity;
    @Column(name = "price_current")
    private Integer priceCurrent;
    private Integer deposit;
    private Boolean status;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public CartItem(ShoppingCart shoppingCart, Product product, BuyType buyType, InStockProduct inStockProduct, Integer quantity, Integer priceCurrent, Integer deposit) {
        this.shoppingCart = shoppingCart;
        this.product = product;
        this.buyType = buyType;
        this.inStockProduct = inStockProduct;
        this.quantity = quantity;
        this.priceCurrent = priceCurrent;
        this.deposit = deposit;
        this.status = true;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
    }

    public void addQuantity(Integer quantity) {
        this.quantity += quantity;
    }
}
