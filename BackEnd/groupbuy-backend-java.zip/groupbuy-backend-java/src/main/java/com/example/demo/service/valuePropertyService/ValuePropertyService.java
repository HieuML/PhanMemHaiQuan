package com.example.demo.service.valuePropertyService;

import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyCreateReq;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyUpdateReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.valuePropertyRes.ValuePropertyRes;

import java.util.List;

public interface ValuePropertyService {
    List<ValuePropertyRes> getAllValueOfProperty(Integer propertyID);

    /**
     * create valueProperty
     * @param req
     * @return
     */
    BaseRes create(ValuePropertyCreateReq req);

    /**
     * update valueProperty
     * @param req
     * @return
     */
    BaseRes update(ValuePropertyUpdateReq req);

    /**
     * delete valueProperty
     * @param valuePropertyID
     * @return
     */
    BaseRes delete(Integer valuePropertyID);
}
