package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyCreateReq;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyUpdateReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.deliveryService.DeliveryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/delivery")
public class DeliveryController {
    @Autowired
    private DeliveryService deliveryService;

    @GetMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAll() {
        return ResponseEntity.ok(deliveryService.getAll());
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<BaseRes> createDelivery(@RequestBody ValuePropertyCreateReq req) {
        return ResponseEntity.ok(deliveryService.create(req));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.UPDATE)
    public ResponseEntity<BaseRes> updateDelivery(@RequestBody IdNameReq req){
        return ResponseEntity.ok(deliveryService.update(req));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping(Path.DELETE_DELIVERY)
    public ResponseEntity<BaseRes> deleteDelivery(@PathVariable Integer deliveryID){
        return ResponseEntity.ok(deliveryService.delete(deliveryID));
    }
}
