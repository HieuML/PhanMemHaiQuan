package com.example.demo.service.districtService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.districtRes.DistrictRes;
import com.example.demo.entities.District;
import com.example.demo.repository.DistrictRepository;
import com.example.demo.service.districtService.DistrictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DistrictServiceImpl implements DistrictService {
    @Autowired
    private DistrictRepository districtRepository;

    @Override
    @Transactional
    public BaseRes getAll() {
        try {
            return new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_DISTRICT,
                    districtRepository.findAll()
                            .stream()
                            .map(x -> DistrictRes.convertFromEntity(x))
                            .collect(Collectors.toList()));
        } catch (Exception error) {
            return new BaseRes<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), TextStatus.INTERNAL_SERVER_ERROR, null);
        }
    }

    @Override
    public List<DistrictRes> getDistrictByCity(Integer cityID) {
        List<District> entities = districtRepository.getDistrictsByCityCityID(cityID);
        return entities.stream().map(x -> DistrictRes.convertFromEntity(x)).collect(Collectors.toList());
    }
}
