package com.example.demo.dto.response.invoiceRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Invoice;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class InvoiceRes {
    private String invoiceID;
    private IdNameRes shop;
    private List<InvoiceItemRes> listInvoiceItem;
    private IdNameRes delivery;
    private IdNameRes payment;
    private IdNameRes buyType;
    private String status;
    // Tổng deposit: nếu mua riêng = 0, nếu mua chung khác 0
    private Integer sumDeposit;
    // Tổng tiền hàng: Nếu mà là mua chung thì lúc mới tạo = null
    private Integer sumPrice;
    // Tiền vận chuyển
    private Integer shippingFee;
    // Tổng tiền thanh toán
    private Integer sumPay;
    // Tiền đã trả với thanh toán qua ví
    private Integer paidAmount;
    // Tiền còn lại phải trả
    private Integer remainPayAmount;
    private String consigneeName;
    private String consigneePhone;
    private String shippingAddress;
    private Long createdAt;
    private Long updatedAt;

    public InvoiceRes(List<InvoiceItemRes> listInvoiceItem, Invoice invoice) {
        this.invoiceID = invoice.getInvoiceID();
        this.shop = new IdNameRes(invoice.getShop().getShopID(), invoice.getShop().getName());
        this.listInvoiceItem = listInvoiceItem;
        this.delivery = new IdNameRes(invoice.getDelivery().getDeliveryID(),
                invoice.getDelivery().getName());
        this.payment = new IdNameRes(invoice.getPayment().getPaymentID(), invoice.getPayment().getName());
        this.buyType = new IdNameRes(invoice.getBuyType().getBuyTypeID(), invoice.getBuyType().getName());
        this.status = invoice.getStatus();
        this.sumDeposit = invoice.getBuyType().getBuyTypeID() == 1 ? 0 : invoice.getPaidAmount();
        this.sumPrice = invoice.getTotalAmount();
        this.shippingFee = invoice.getShippingFee();
        this.sumPay = invoice.getTotalAmount() + invoice.getShippingFee();
        this.paidAmount = invoice.getPaidAmount();
        this.remainPayAmount = invoice.getTotalAmount() + invoice.getShippingFee() - invoice.getPaidAmount();
        this.consigneeName = invoice.getConsigneeName();
        this.consigneePhone = invoice.getConsigneePhone();
        this.shippingAddress = invoice.getShippingAddress();
        this.createdAt = invoice.getCreatedAt();
        this.updatedAt = invoice.getUpdatedAt();
    }
}
