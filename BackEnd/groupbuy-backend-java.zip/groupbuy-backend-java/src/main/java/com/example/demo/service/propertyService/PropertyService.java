package com.example.demo.service.propertyService;

import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.propertyRes.PropertyRes;

import java.util.List;

public interface PropertyService {
    /**
     * get all
     * @return
     */
    List<PropertyRes> getAllProperty();

    /**
     * create property
     * @param requestName
     * @return
     */
    BaseRes create(RequestName requestName);

    /**
     * update property
     * @param req
     * @return
     */
    BaseRes update(IdNameReq req);
}
