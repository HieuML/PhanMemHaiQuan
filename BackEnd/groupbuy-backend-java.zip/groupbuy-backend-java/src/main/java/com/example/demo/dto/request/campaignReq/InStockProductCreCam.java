package com.example.demo.dto.request.campaignReq;

import lombok.Data;

@Data
public class InStockProductCreCam {
    private Integer inStockID;
    private Integer campaignInStock;
}
