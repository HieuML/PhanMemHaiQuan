package com.example.demo.service.shopService.impl;

import com.example.demo.constants.Sort;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.userReq.GetLstAllUserReq;
import com.example.demo.dto.response.PageRes;
import com.example.demo.dto.response.authRes.UserRes;
import com.example.demo.dto.response.shopRes.ListShopRes;
import com.example.demo.dto.response.shopRes.ShopDetailRes;
import com.example.demo.dto.response.userRes.ListUserRes;
import com.example.demo.entities.*;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.*;
import com.example.demo.dto.request.UpdateShopRequest;
import com.example.demo.service.shopService.ShopService;
import com.example.demo.utils.CommonMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ShopServiceImpl implements ShopService {
    @Autowired
    WardRepository wardRepository;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    DistrictRepository districtRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    private CampaignRepository campaignRepository;

    @Override
    public Integer updateShop(UpdateShopRequest shop) {
        Optional<Ward> wardData = wardRepository.findById(shop.getWardID());
        if (!wardData.isPresent()) {
            throw new ResourceNotFoundException(TextStatus.WARD_NOT_FOUND);
        }
        Optional<Shop> shopData = shopRepository.findByUserId(shop.getUserID());
        if (shopData.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
        }
        Shop shop_ = shopData.get();
        shop_.setWard(wardData.get());
        shop_.setName(shop.getName());
        shop_.setShopImage(shop.getShopImage());
        shop_.setUpdatedAt(new Date().getTime());
        shopRepository.save(shop_);
        return shop_.getShopID();
    }

    @Override
    public ShopDetailRes getDetailShop(Integer shopID) {
        Optional<Shop> shop = shopRepository.findById(shopID);
        if (shop.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
        }
        Integer sumProduct = productRepository.findByShopShopID(shop.get().getShopID()).size();
        Integer sumCampaign = campaignRepository.findByShopShopID(shop.get().getShopID()).size();

        if (shop.get().getWard() == null) {
            return new ShopDetailRes(shop.get(), sumProduct, sumCampaign);
        } else {
            District district = shop.get().getWard().getDistrict();
            City city = district.getCity();
            return new ShopDetailRes(shop.get(), district, city, sumProduct, sumCampaign);
        }
    }

    @Override
    public ListShopRes getAll(GetLstAllUserReq req) {
        List<String> sortArr = new ArrayList<>();
        String sortTmp = "";
        switch (req.getSort()) {
            case "DEFAULT":
                sortTmp = Sort.DEFAULT;
                break;
            case "CREATED_ASC":
                sortTmp = Sort.CREATED_ASC;
                break;
            case "CREATED_DESC":
                sortTmp = Sort.CREATED_DESC;
                break;
        }
        sortArr = Arrays.stream(sortTmp.split(",")).collect(Collectors.toList());
        if (sortArr.get(0).equals("id"))
            sortArr.set(0, "shopID");
        org.springframework.data.domain.Sort.Order order = new org.springframework.data.domain.Sort.Order(CommonMethod.findDirection(sortArr.get(1)), sortArr.get(0));
        Pageable pageable = PageRequest.of(req.getPageIndex(),
                req.getLimit(),
                org.springframework.data.domain.Sort.by(order));
        Page<Shop> entity = shopRepository.findAll(pageable);
        List<ShopDetailRes> shoplist = entity.getContent().stream()
                .map(x -> new ShopDetailRes(x))
                .collect(Collectors.toList());
        PageRes pageRes = new PageRes(entity.getTotalPages(),
                entity.getSize(),
                entity.getPageable().getPageNumber(),
                entity.hasNext());
        ListShopRes rs = new ListShopRes(shoplist, pageRes);
        return rs;
    }
}
