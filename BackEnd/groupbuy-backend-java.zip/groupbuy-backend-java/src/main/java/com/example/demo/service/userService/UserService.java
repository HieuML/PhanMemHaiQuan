package com.example.demo.service.userService;

import com.example.demo.dto.request.userReq.ChangePasswordReq;
import com.example.demo.dto.request.userReq.GetLstAllUserReq;
import com.example.demo.dto.request.walletReq.TopUpOrWithdrawReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.authRes.UserRes;
import com.example.demo.dto.response.moneyTransferActivityRes.MoneyTransferActivityRes;
import com.example.demo.dto.response.userRes.ListUserRes;
import com.example.demo.dto.response.walletRes.DetailWalletRes;
import com.example.demo.dto.request.UpdatePasswordRequest;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

public interface UserService {
    /**
     * find all users
     *
     * @return
     */
    ListUserRes getAll(GetLstAllUserReq req);

    /**
     * find user by id
     *
     * @param userID
     * @return
     */
    UserRes getById(Integer userID);

    /**
     * find users by firstName
     *
     * @param firstName
     * @return
     */
    List<UserRes> findByFirstName(String firstName);

    /**
     * send otp to emailUser
     *
     * @param email
     */
    boolean sendOTP(String email);

    /**
     * confirm otp
     *
     * @param otp
     * @return
     */
    Optional<Integer> confirmOTP(String otp);

    /**
     * update new password
     *
     * @param updatePasswordRequest
     * @return
     */
    boolean updatePassword(UpdatePasswordRequest updatePasswordRequest);


    BaseRes<BaseUpdated> changePassword(HttpServletRequest request, ChangePasswordReq changePasswordReq);

    MoneyTransferActivityRes topUp(HttpServletRequest request, TopUpOrWithdrawReq topUpOrWithdrawReq);

    DetailWalletRes getInfoWalletByUser(HttpServletRequest request);

    MoneyTransferActivityRes withdraw(HttpServletRequest request, TopUpOrWithdrawReq topUpOrWithdrawReq);

    /**
     * change status user
     *
     * @param userID
     * @return
     */
    BaseRes<BaseUpdated> updateStatusUser(Integer userID);
}
