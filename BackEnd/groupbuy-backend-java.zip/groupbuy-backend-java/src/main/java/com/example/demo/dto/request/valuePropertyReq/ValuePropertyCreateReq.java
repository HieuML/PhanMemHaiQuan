package com.example.demo.dto.request.valuePropertyReq;

import com.example.demo.dto.request.RequestName;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ValuePropertyCreateReq extends RequestName {
    private Integer propertyID;
}
