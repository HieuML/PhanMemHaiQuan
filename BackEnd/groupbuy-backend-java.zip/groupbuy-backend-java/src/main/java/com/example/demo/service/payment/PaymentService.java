package com.example.demo.service.payment;

import com.example.demo.dto.response.BaseRes;

public interface PaymentService {
    /**
     * Get all
     *
     * @return
     */
    BaseRes getAll();
}
