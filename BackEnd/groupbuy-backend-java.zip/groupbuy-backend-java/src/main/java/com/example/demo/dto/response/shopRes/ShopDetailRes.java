package com.example.demo.dto.response.shopRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.City;
import com.example.demo.entities.District;
import com.example.demo.entities.Shop;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
public class ShopDetailRes {
    private String username;
    private Integer shopID;
    private String name;
    private BigDecimal rating;
    private String shopImage;
    private IdNameRes ward;
    private IdNameRes district;
    private IdNameRes city;
    private Integer sumProduct;
    private Integer sumCampaign;
    private BigDecimal systemFee;
    private Long createdAt;

    public ShopDetailRes(Shop shop, District district, City city, Integer sumProduct, Integer sumCampaign) {
        shopID = shop.getShopID();
        name = shop.getName();
        shopImage = shop.getShopImage();
        rating = shop.getRating();
        createdAt = shop.getCreatedAt();
        ward = new IdNameRes(shop.getWard().getWardID(), shop.getWard().getName());
        this.district = new IdNameRes(district.getDistrictID(), district.getName());
        this.city = new IdNameRes(city.getCityID(), city.getName());
        this.sumProduct = sumProduct;
        this.sumCampaign = sumCampaign;
    }

    public ShopDetailRes(Shop shop, Integer sumProduct, Integer sumCampaign) {
        shopID = shop.getShopID();
        name = shop.getName();
        shopImage = shop.getShopImage();
        rating = shop.getRating();
        createdAt = shop.getCreatedAt();
        this.sumProduct = sumProduct;
        this.sumCampaign = sumCampaign;
    }

    public ShopDetailRes(Shop shop) {
        this.username = shop.getUser().getUsername();
        this.shopID = shop.getShopID();
        this.name = shop.getName();
        this.rating = shop.getRating();
        this.shopImage = shop.getShopImage();
        if (shop.getWard() != null) {
            this.ward = new IdNameRes(shop.getWard().getWardID(), shop.getWard().getName());
            this.district = new IdNameRes(shop.getWard().getDistrict().getDistrictID(), shop.getWard().getDistrict().getName());
            this.city = new IdNameRes(shop.getWard().getDistrict().getCity().getCityID(), shop.getWard().getDistrict().getCity().getName());
        }
        this.systemFee = shop.getSystemFee();
        this.createdAt = shop.getCreatedAt();
    }
}
