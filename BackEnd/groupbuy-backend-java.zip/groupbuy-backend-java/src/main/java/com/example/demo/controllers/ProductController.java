package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.productReq.ChangeDefaultImageReq;
import com.example.demo.dto.request.productReq.CreateOrUpdateProductReq;
import com.example.demo.dto.request.productReq.GetAllProductReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.service.productService.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/product")
public class ProductController {
    @Autowired
    private ProductService productService;

    @PostMapping(Path.GET_ALL)
    public ResponseEntity<?> getAllProduct(@RequestBody GetAllProductReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_PRODUCT_SUCCESS, productService.getAllProductByShop(req)));
    }

    @PostMapping(Path.GET_BY_SHOP)
    public ResponseEntity<?> getAllProductByShop(@RequestBody GetAllProductReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_PRODUCT_BY_SHOP_SUCCESS, productService.getAllProductByShop(req)));
    }

    @GetMapping(Path.GET_ALL_IMAGE_OF_PRODUCT)
    public ResponseEntity<?> getAllImageByProduct(@PathVariable String productID) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_IMAGE_BY_PRODUCT_SUCCESS, productService.getAllImageByProduct(productID)));
    }

    //Not use
    @PostMapping(Path.CHANGE_DEFAULT_IMAGE)
    public ResponseEntity<?> changeDefaultImage(HttpServletRequest request, @RequestBody ChangeDefaultImageReq changeDefaultImageReq) {
        productService.changeDefaultImage(request, changeDefaultImageReq);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CHANGE_DEFAULT_IMAGE_SUCCESS, new BaseUpdated(changeDefaultImageReq.getProductID(), true)));
    }

    @GetMapping(Path.GET_DETAIL_PRODUCT)
    public ResponseEntity<?> getDetailProduct(@PathVariable String productID) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_DETAIL_PRODUCT_SUCCESS, productService.getDetailProduct(productID)));
    }

    @PreAuthorize("hasRole('SELLER')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<?> createProduct(HttpServletRequest request, @RequestBody CreateOrUpdateProductReq product) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CREATE_PRODUCT_SUCCESS, productService.createProduct(request, product)));
    }

    @PreAuthorize("hasRole('SELLER')")
    @PostMapping(Path.UPDATE_PRODUCT)
    public ResponseEntity<?> updateProduct(HttpServletRequest request, @PathVariable String productID, @RequestBody CreateOrUpdateProductReq product) {
        productService.updateProduct(request, productID, product);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.UPDATE_PRODUCT_SUCCESS, new BaseUpdated(productID, true)));
    }

    @PreAuthorize("hasRole('SELLER')")
    @PostMapping(Path.CHANGE_STATUS_PRODUCT)
    public ResponseEntity<?> changeStatus(HttpServletRequest request, @PathVariable String productID) {
        productService.changeStatus(request, productID);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CHANGE_STATUS_PRODUCT_SUCCESS, new BaseUpdated(productID, true)));
    }

    //Not use
    @PostMapping(Path.DELETE_PRODUCT)
    public ResponseEntity<?> deleteProduct(HttpServletRequest request, @PathVariable String productID) {
        productService.deleteProduct(request, productID);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.DELETE_PRODUCT_SUCCESS));
    }
}
