package com.example.demo.repository;

import com.example.demo.entities.Product;
import com.example.demo.entities.Shop;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, String> {
    /**
     * find products by name
     *
     * @param productName
     * @return
     */
    List<Product> findAllByNameContaining(String productName);

    /**
     * find products by information search
     *
     * @param productName
     * @param price
     * @param slug
     * @return
     */
    Page<Product> findByNameContainingAndPriceAndSlug(String productName, Integer price, String slug, Pageable pageable);

    Page<Product> findByShopShopID(Integer shopID, Pageable pageable);

    Page<Product> findByIsActive(Boolean isActive, Pageable pageable);

    Page<Product> findByIsActiveAndNameContaining(Boolean isActive, String name, Pageable pageable);

    List<Product> findByShopShopID(Integer shopID);

    @Query(value = "SELECT t from Product t where t.name like %?1% and t.shop = ?2")
    Page<Product> findByShopAndNameContaining(String name, Shop shop, Pageable pageable);

    List<Product> findByNameContaining(String name, Sort sort);

    Long countByIsActiveTrue();

    Long countByIsActiveTrueAndShopShopID(Integer shopID);

}
