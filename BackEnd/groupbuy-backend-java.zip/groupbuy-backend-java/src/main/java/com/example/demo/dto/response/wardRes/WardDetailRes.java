package com.example.demo.dto.response.wardRes;

import com.example.demo.dto.response.districtRes.DistrictRes;
import com.example.demo.entities.Ward;

public class WardDetailRes extends WardRes {
    private DistrictRes districtRes;

    public WardDetailRes(Integer id, String name, DistrictRes districtRes) {
        super(id, name);
        this.districtRes = districtRes;
    }

    public static WardDetailRes convertFromEntity(Ward ward) {
        return new WardDetailRes(ward.getWardID(), ward.getName(), DistrictRes.convertFromEntity(ward.getDistrict()));
    }
}
