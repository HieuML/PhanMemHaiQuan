package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.propertyService.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/property")
public class PropertyController {
    @Autowired
    private PropertyService propertyService;

    @GetMapping(Path.GET_ALL)
    public ResponseEntity<?> getAllProperty() {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_PROPERTY_SUCCESS, propertyService.getAllProperty()));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<BaseRes> createProperty(@RequestBody RequestName req){
        return ResponseEntity.ok(propertyService.create(req));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.UPDATE)
    public ResponseEntity<BaseRes> updateProperty(@RequestBody IdNameReq req){
        return ResponseEntity.ok(propertyService.update(req));
    }

}
