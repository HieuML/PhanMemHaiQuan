package com.example.demo.dto.request.cartItemReq;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ChangeQuantityReq {
    Integer cartItemID;
    Integer quantity;
}
