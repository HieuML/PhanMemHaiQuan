package com.example.demo.dto.response.campaignRes;

import com.example.demo.dto.response.productRes.ProductRes;
import com.example.demo.dto.response.shopRes.ShopRes;
import com.example.demo.entities.Campaign;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CampaignRes {
    private String campaignID;
    private String name;
    private ProductRes productRes;
    private ShopRes shopRes;
    private Integer soldQuantity;
    private Integer inStock;

    public CampaignRes(String id, String name, ProductRes productRes, ShopRes shopRes, Integer soldQuantity, Integer inStock) {
        this.campaignID = id;
        this.name = name;
        this.productRes = productRes;
        this.shopRes = shopRes;
        this.soldQuantity = soldQuantity;
        this.inStock = inStock;
    }

    public static CampaignRes convertFromEntity(Campaign campaign) {
        return new CampaignRes(campaign.getCampaignID(),
                campaign.getName(),
                new ProductRes(campaign.getProduct()),
                ShopRes.convertFromEntity(campaign.getShop()),
                campaign.getSoldQuantity(),
                campaign.getInStock());
    }
}
