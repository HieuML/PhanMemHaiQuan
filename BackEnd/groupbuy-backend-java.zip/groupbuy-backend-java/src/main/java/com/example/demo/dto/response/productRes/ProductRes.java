package com.example.demo.dto.response.productRes;

import com.example.demo.entities.InStockProduct;
import com.example.demo.entities.Product;
import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Property;
import com.example.demo.repository.InStockProductRepository;
import com.example.demo.repository.ValuePropertyRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
public class ProductRes {
    private String productID;
    private String name;
    private String description;
    private Integer price;
    private Integer originPrice;
    private IdNameRes brand;
    private IdNameRes category;
    private IdNameRes shop;
    private IdNameRes origin;
    private Integer soldQuantity;
    private Integer inStock;
    private java.math.BigDecimal rating;
    private String slug;
    private Boolean isActive;
    private String productImage;
    private IdNameRes property;
    private List<InStockProductRes> listInStockProduct;

    public ProductRes(Product _product) {
        this.productID = _product.getProductID();
        this.name = _product.getName();
        this.description = _product.getDescription();
        this.price = _product.getPrice();
        this.originPrice = _product.getOriginPrice();
        if (_product.getBrand() != null) {
            this.brand = new IdNameRes(_product.getBrand().getBrandID(), _product.getBrand().getName());
        }
        if (_product.getCategory() != null) {
            this.category = new IdNameRes(_product.getCategory().getCategoryID(), _product.getCategory().getName());
        }
        this.shop = new IdNameRes(_product.getShop().getShopID(), _product.getShop().getName());
        if (_product.getOrigin() != null) {
            this.origin = new IdNameRes(_product.getOrigin().getOriginID(), _product.getOrigin().getName());
        }
        this.soldQuantity = _product.getSoldQuantity();
        this.inStock = _product.getInStock();
        this.rating = _product.getRating();
        this.slug = _product.getSlug();
        this.isActive = _product.getIsActive();
        this.productImage = _product.getProductImage();
    }

    public ProductRes(Product _product, InStockProductRepository inStockProductRepository, ValuePropertyRepository valuePropertyRepository) {
        this(_product);
        List<InStockProduct> listInStockProduct = inStockProductRepository.findInStockProductByProductProductID(_product.getProductID());
        if (listInStockProduct.size() > 0) {
            InStockProduct inStockProduct = listInStockProduct.get(0);
            Integer valuePropertyID = inStockProduct.getValueProperty().getValuePropertyID();
            Property property = valuePropertyRepository.findById(valuePropertyID).get().getProperty();
            this.property = new IdNameRes(property.getPropertyID(), property.getName());
            this.listInStockProduct = listInStockProduct.stream().map(s -> InStockProductRes.convertFromEntity(s)).toList();
        }
    }
}
