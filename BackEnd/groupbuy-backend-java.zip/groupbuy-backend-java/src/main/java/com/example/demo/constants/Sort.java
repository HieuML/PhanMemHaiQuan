package com.example.demo.constants;

public interface Sort {
    String DEFAULT = "id,asc";
    String PRICE_ASC = "price,asc";
    String PRICE_DESC = "price,desc";
    String CREATED_ASC = "createdAt,asc";
    String CREATED_DESC = "createdAt,desc";
}
