package com.example.demo.dto.response.walletRes;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class DetailWalletRes {
    private Integer money;
}
