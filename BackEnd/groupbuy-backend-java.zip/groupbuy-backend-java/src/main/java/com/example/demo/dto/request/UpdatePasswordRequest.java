package com.example.demo.dto.request;

import lombok.Data;

@Data
public class UpdatePasswordRequest {
    private Integer userId;
    private String newPassword;
}
