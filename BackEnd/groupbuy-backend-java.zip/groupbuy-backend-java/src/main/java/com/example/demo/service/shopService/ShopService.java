package com.example.demo.service.shopService;

import com.example.demo.dto.request.UpdateShopRequest;
import com.example.demo.dto.request.userReq.GetLstAllUserReq;
import com.example.demo.dto.response.shopRes.ListShopRes;
import com.example.demo.dto.response.shopRes.ShopDetailRes;
import com.example.demo.dto.response.userRes.ListUserRes;
import org.springframework.stereotype.Service;

@Service
public interface ShopService {

    /**
     * find all users
     *
     * @return
     */
    ListShopRes getAll(GetLstAllUserReq req);

    Integer updateShop(UpdateShopRequest shop);

    ShopDetailRes getDetailShop(Integer shopId);
}
