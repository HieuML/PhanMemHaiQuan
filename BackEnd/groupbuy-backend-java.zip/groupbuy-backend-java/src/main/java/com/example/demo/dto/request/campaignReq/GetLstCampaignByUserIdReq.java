package com.example.demo.dto.request.campaignReq;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetLstCampaignByUserIdReq extends GetAllCampaignReq {
    private Integer userID;
}
