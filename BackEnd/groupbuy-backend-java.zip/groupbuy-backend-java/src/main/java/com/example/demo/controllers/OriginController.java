package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.originService.OriginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/origin")
public class OriginController {
    @Autowired
    private OriginService originService;

    @GetMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAllOrigin() {
        return ResponseEntity.ok(originService.getAll());
    }

    //Admin
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<BaseRes> createOrigin(@RequestBody RequestName name) {
        return ResponseEntity.ok(originService.create(name));
    }
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.UPDATE)
    public ResponseEntity<BaseRes> updateCategory(@RequestBody IdNameReq req){
        return ResponseEntity.ok(originService.update(req));
    }
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping(Path.DELETE_ORIGIN)
    public ResponseEntity<BaseRes> deleteCategory(@PathVariable Integer originID) {
        return ResponseEntity.ok(originService.delete(originID));
    }

}
