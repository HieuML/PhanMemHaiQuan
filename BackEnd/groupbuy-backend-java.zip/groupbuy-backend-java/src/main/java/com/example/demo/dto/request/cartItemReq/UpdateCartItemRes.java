package com.example.demo.dto.request.cartItemReq;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UpdateCartItemRes {
    private Integer cartItemID;
    private Integer quantity;
    private Integer inStockProductID;
}
