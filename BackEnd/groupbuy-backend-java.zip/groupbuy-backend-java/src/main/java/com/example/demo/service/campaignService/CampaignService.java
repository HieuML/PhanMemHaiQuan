package com.example.demo.service.campaignService;

import com.example.demo.dto.request.campaignReq.CreateOrUpdateCampaignReq;
import com.example.demo.dto.request.campaignReq.GetAllCampaignReq;
import com.example.demo.dto.request.campaignReq.GetLstCampaignByUserIdReq;
import com.example.demo.dto.response.campaignRes.CampaignRes1;
import com.example.demo.dto.response.campaignRes.GetLstCampaignRes;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.Optional;

public interface CampaignService {
    Map<String, Object> getAllCampaignByShop(GetAllCampaignReq getAllCampaignReq);

    /**
     * get campaign by campaignId
     *
     * @param campID
     * @return
     */

    Optional<CampaignRes1> getByCampId(String campID);

    /*
     * get list campaign by infor search
     * @param req
     * @return
     */
    GetLstCampaignRes getByUserId(GetLstCampaignByUserIdReq req);

    CampaignRes1 createCampaign(HttpServletRequest request, CreateOrUpdateCampaignReq campaign);

    void deleteCampaign(HttpServletRequest request, String campaignID);

    void changeActive(HttpServletRequest request, String campaignID);

    void updateCampaign(HttpServletRequest request, String campaignID, CreateOrUpdateCampaignReq campaign);

    void checkStatusCampaign(String campaignID);
}
