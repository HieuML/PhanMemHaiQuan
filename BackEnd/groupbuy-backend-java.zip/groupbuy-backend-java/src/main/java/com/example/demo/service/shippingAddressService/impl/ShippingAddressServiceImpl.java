package com.example.demo.service.shippingAddressService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.shippingAddressReq.ShippingAddressCreateReq;
import com.example.demo.dto.request.shippingAddressReq.ShippingAddressUpdateReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.shippingAddresRes.ShippingAddressRes;
import com.example.demo.entities.ShippingAddress;
import com.example.demo.entities.Ward;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.ShippingAddressRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.repository.WardRepository;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.shippingAddressService.ShippingAddressService;
import com.example.demo.utils.CommonMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ShippingAddressServiceImpl implements ShippingAddressService {
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private ShippingAddressRepository shippingAddressRepository;
    @Autowired
    private WardRepository wardRepository;
    @Autowired
    private UserRepository userRepository;

    public Integer getUserID(HttpServletRequest request) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        return userID;
    }

    @Override
    public BaseRes create(HttpServletRequest request, ShippingAddressCreateReq req) {
        Integer userID = getUserID(request);
        if (req.getConsigneeName() == null || req.getPhone() == null || req.getType() == null || req.getStreet() == null || req.getWardID() == null)
            return new BaseRes<>(HttpStatus.BAD_REQUEST.value(), TextStatus.CREATE_SHIPPING_ADDRESS_FAIL, null);
        Optional<Ward> ward = wardRepository.findById(req.getWardID());
        //if ward not found => return fail
        if (ward.isEmpty()) return new BaseRes<>(HttpStatus.NOT_FOUND.value(), TextStatus.GET_WARD_BY_ID_FAIL, null);
        List<ShippingAddress> lstShippingAddress = shippingAddressRepository.findByUserId(userID);
        ShippingAddress shippingAddress = new ShippingAddress();
        shippingAddress.setUser(userRepository.findById(userID).get());
        shippingAddress.setWard(ward.get());
        shippingAddress.setWard(wardRepository.findById(req.getWardID()).get());
        shippingAddress.setType(req.getType());
        shippingAddress.setAddressDetail(req.getAddressDetail());
        shippingAddress.setConsigneeName(req.getConsigneeName());
        shippingAddress.setStreet(req.getStreet());
        shippingAddress.setPhone(req.getPhone());
        shippingAddress.setCreatedAt(new Date().getTime());
        shippingAddress.setUpdatedAt(new Date().getTime());
        shippingAddress.setIsDefault(lstShippingAddress.size() == 0);
        shippingAddressRepository.save(shippingAddress);
        return new BaseRes<>(HttpStatus.OK.value(), TextStatus.CREATE_SHIPPING_ADDRESS_SUCCESS, new ShippingAddressRes(shippingAddress));
    }

    @Override
    public BaseRes getByUser(HttpServletRequest request) {
        Integer userID = getUserID(request);
        try {
            List<ShippingAddress> entities = shippingAddressRepository.findByUserId(userID);
            return new BaseRes(HttpStatus.OK.value(), TextStatus.GET_SHIPPING_ADDRESS_BY_USER_ID_SUCCESS,
                    entities.stream().map(x -> new ShippingAddressRes(x))
                            .collect(Collectors.toList())
            );
        } catch (Exception e) {
            return new BaseRes<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), TextStatus.INTERNAL_SERVER_ERROR, null);
        }
    }

    @Override
    public BaseRes update(HttpServletRequest request, ShippingAddressUpdateReq req) {
        Integer userID = getUserID(request);
        if (req.getShippingAddressID() == null || req.getConsigneeName() == null || req.getPhone() == null || req.getType() == null || req.getStreet() == null || req.getWardID() == null)
            return new BaseRes<>(HttpStatus.NOT_FOUND.value(), TextStatus.UPDATE_SHIPPING_ADDRESS_FAIL, null);
        Optional<Ward> ward = wardRepository.findById(req.getWardID());
        if (ward.isEmpty()) {
            return new BaseRes<>(HttpStatus.NOT_FOUND.value(), TextStatus.GET_WARD_BY_ID_FAIL, null);
        }
        Optional<ShippingAddress> entity = shippingAddressRepository.findById(req.getShippingAddressID());
        if (entity.isEmpty() || (entity.get().getUser().getId() != userID)) {
            return new BaseRes((HttpStatus.NOT_FOUND.value()), TextStatus.GET_SHIPPING_ADDRESS_BY_ID_FAIL, null);
        }
        ShippingAddress shippingAddressUpdate = entity.get();
        shippingAddressUpdate.setUser(userRepository.findById(userID).get());
        shippingAddressUpdate.setWard(ward.get());
        shippingAddressUpdate.setType(req.getType());
        shippingAddressUpdate.setAddressDetail(req.getAddressDetail());
        shippingAddressUpdate.setConsigneeName(req.getConsigneeName());
        shippingAddressUpdate.setStreet(req.getStreet());
        shippingAddressUpdate.setPhone(req.getPhone());
        shippingAddressUpdate.setUpdatedAt(new Date().getTime());
        shippingAddressRepository.save(shippingAddressUpdate);
        return new BaseRes<>(HttpStatus.OK.value(), TextStatus.UPDATE_SHIPPING_ADDRESS_SUCCESS, new BaseUpdated<>(shippingAddressUpdate.getShippingAddressID(), true));
    }

    @Override

    public BaseRes delete(HttpServletRequest request, Integer shippingAddressID) {
        Integer userID = getUserID(request);
        Optional<ShippingAddress> entity = shippingAddressRepository.findById(shippingAddressID);
        if (entity.isEmpty() || (entity.get().getUser().getId() != userID))
            return new BaseRes<>(HttpStatus.NOT_FOUND.value(), TextStatus.DELETE_SHIPPING_ADDRESS_FAIL, null);
        shippingAddressRepository.deleteById(shippingAddressID);
        return new BaseRes<>(HttpStatus.OK.value(), TextStatus.DELETE_SHIPPING_ADDRESS_SUCCESS, new BaseUpdated<>(entity.get().getShippingAddressID(), true));
    }

    @Override
    public BaseRes changeDefaultAddress(HttpServletRequest request, Integer shippingAddressID) {
        Integer userID = getUserID(request);
        Optional<ShippingAddress> entity = shippingAddressRepository.findById(shippingAddressID);
        if (entity.isEmpty() || (entity.get().getUser().getId() != userID))
            return new BaseRes<>(HttpStatus.NOT_FOUND.value(), TextStatus.CHANGE_DEFAULT_SHIPPING_ADDRESS_FAIL, null);
        List<ShippingAddress> lstUpdateShippingAddress = shippingAddressRepository.findByUserId(userID);
        lstUpdateShippingAddress.stream().forEach(x -> {
            if (x.getShippingAddressID().equals(entity.get().getShippingAddressID())) {
                x.setIsDefault(true);
            } else {
                x.setIsDefault(false);
            }
        });
        shippingAddressRepository.saveAll(lstUpdateShippingAddress);
        return new BaseRes<>(HttpStatus.OK.value(),
                TextStatus.CHANGE_DEFAULT_SHIPPING_ADDRESS_SUCCESS,
                new BaseUpdated<>(entity.get().getShippingAddressID(), true));
    }

    @Override
    public BaseRes getAddressDefault(HttpServletRequest request) {
        Integer userID = getUserID(request);
        Optional<ShippingAddress> defaultAddress = shippingAddressRepository.findByUserIdAndIsDefault(userID, true);
        if (defaultAddress.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.ERROR_GET_DEFAULT_SHIPPING_ADDRESS);
        }
        return new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_DEFAULT_SHIPPING_ADDRESS_SUCCESS, new ShippingAddressRes(defaultAddress.get()));
    }
}
