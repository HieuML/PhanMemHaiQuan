package com.example.demo.repository;

import com.example.demo.entities.Campaign;
import com.example.demo.entities.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;
import java.util.List;

public interface CampaignRepository extends JpaRepository<Campaign, String> {
    /**
     * find campaign by shopId
     *
     * @param shopId
     * @return
     */
    Page<Campaign> findCampaignByShopShopID(int shopId, Pageable pageable);

    /**
     * find all campaign
     *
     * @param pageable
     * @return
     */
    Page<Campaign> findAll(Pageable pageable);

    Page<Campaign> findByIsActive(Boolean isActive, Pageable pageable);

    Page<Campaign> findByIsActiveAndNameContaining(Boolean isActive, String name, Pageable pageable);

    List<Campaign> findByShopShopID(Integer shopID);

    Page<Campaign> findByShopShopID(Integer shopID, Pageable pageable);

    Optional<Campaign> findByProductProductIDAndIsActive(String productID, Boolean isActive);

    @Query("select t.campaignID from Campaign t where t.product = ?1 and (t.startTime > ?2 or t.isActive = true)")
    Optional<String> checkUpdateProduct(Product product, Long currentTime);

    Optional<Campaign> findByProductProductIDAndStatus(String productID, String status);

    Page<Campaign> findByShopShopIDAndNameContaining(Integer shopID, String campaignID, Pageable pageable);

    @Query("select count (t.campaignID) from Campaign t where t.status = ?1")
    Long countByStatus(String status);

    Long countByShopShopID(Integer shopID);

    Long countByIsActiveTrueAndShopShopID(Integer shopID);
}
