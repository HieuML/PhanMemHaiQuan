package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.cityService.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
// All
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/city")
public class CityController {
    @Autowired
    private CityService cityService;

    @GetMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAllCities() {
        return ResponseEntity.ok(cityService.getAll());
    }
}
