package com.example.demo.service.wardService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.wardRes.WardRes;
import com.example.demo.entities.Ward;
import com.example.demo.repository.WardRepository;
import com.example.demo.service.wardService.WardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WardServiceImpl implements WardService {
    @Autowired
    private WardRepository wardRepository;

    @Override
    @Transactional
    public BaseRes getAll() {
        try {
            return new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_WARD, wardRepository.findAll().stream().map(x -> WardRes.convertFromEntity(x)).collect(Collectors.toList()));
        } catch (Exception error) {
            return new BaseRes<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), TextStatus.INTERNAL_SERVER_ERROR, null);
        }
    }

    @Override
    public List<WardRes> getWardByDistrict(Integer districtID) {
        List<Ward> entities = wardRepository.getWardByDistrictDistrictID(districtID);
        return entities.stream().map(x -> WardRes.convertFromEntity(x)).collect(Collectors.toList());
    }
}
