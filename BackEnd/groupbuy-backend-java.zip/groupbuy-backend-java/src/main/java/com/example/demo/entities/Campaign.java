package com.example.demo.entities;

import com.example.demo.constants.Status;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "campaign")
@Setter
@Getter
@NoArgsConstructor
public class Campaign {
    @Id
    @GeneratedValue(generator = "generator")
    @GenericGenerator(name = "generator", parameters = {@org.hibernate.annotations.Parameter(name = "prefix", value = "cp")}, strategy = "com.example.demo.utils.generatorIDHandler")
    @Column(name = "campaign_id")
    private String campaignID;
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "shop_id", nullable = false)
    private Shop shop;
    @Column(length = 100, nullable = false)
    private String name;
    private Integer deposit;
    @Column(name = "start_time")
    private Long startTime;
    @Column(name = "end_time")
    private Long endTime;
    @Column(name = "sold_quantity")
    private Integer soldQuantity;
    @Column(name = "in_stock")
    private Integer inStock;
    private Boolean isActive;
    private String slug;
    private String status;
    @Column(name = "price_current")
    private Integer priceCurrent;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public void changeIsActive() {
        isActive = !isActive;
    }

    public Campaign(String name, Integer deposit, Long startTime, Long endTime, Integer inStock, Product product, Shop shop, Integer priceCurrent) {
        this.name = name;
        this.deposit = deposit;
        this.priceCurrent = priceCurrent;
        this.startTime = startTime;
        this.endTime = endTime;
        this.soldQuantity = 0;
        this.product = product;
        this.shop = shop;
        this.inStock = inStock;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
        this.isActive = false;
        this.status = Status.WAITING_START;
    }
}
