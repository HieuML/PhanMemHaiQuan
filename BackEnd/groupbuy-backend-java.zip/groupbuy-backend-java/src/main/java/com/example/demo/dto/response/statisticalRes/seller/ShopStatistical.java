package com.example.demo.dto.response.statisticalRes.seller;


import com.example.demo.dto.response.campaignRes.CampaignRes1;
import com.example.demo.dto.response.productRes.ProductRes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ShopStatistical {
    //sumCampaign
    private Long sumCampaignByShop;

    //sumCampaignRun
    private Long sumCampaignRunByShop;

    //sumProduct
    private Long sumProductByShop;

    //BestSellerCampaign
    private List<CampaignRes1> bestSellerCampaign;


    //BestSellerProduct
    private List<ProductRes> bestSellerProduct;
}
