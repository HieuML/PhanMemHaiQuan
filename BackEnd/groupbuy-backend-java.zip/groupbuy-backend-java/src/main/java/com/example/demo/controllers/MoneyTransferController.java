package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.adminReq.ConfirmOrCancelTransactionReq;
import com.example.demo.dto.request.productReq.GetAllMoneyTransferReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.service.moneyTransferService.MoneyTransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/money-transfer")
public class MoneyTransferController {
    @Autowired
    MoneyTransferService moneyTransferService;

    //All
    @PostMapping(Path.GET_ALL)
    public ResponseEntity<?> getAllMoneyTransfer(HttpServletRequest request, @RequestBody GetAllMoneyTransferReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_MONEY_TRANSFER_SUCCESS, moneyTransferService.getAllMoneyTransfer(request,req)));
    }

    //All
    @PostMapping(Path.CANCEL_TRANSACTION)
    public ResponseEntity<?> confirmTransaction(HttpServletRequest request, @RequestBody ConfirmOrCancelTransactionReq confirmOrCancelTransactionReq) {
        moneyTransferService.cancelTransaction(request, confirmOrCancelTransactionReq);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CONFIRM_TRANSACTION_SUCCESS, new BaseUpdated(confirmOrCancelTransactionReq.getMoneyTransferActivityID(), true)));
    }
}
