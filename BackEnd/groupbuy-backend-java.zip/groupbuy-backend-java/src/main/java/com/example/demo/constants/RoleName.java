package com.example.demo.constants;

public interface RoleName {
    String CUSTOMER = "ROLE_CUSTOMER";
    String SELLER = "ROLE_SELLER";
    String ADMIN = "ROLE_ADMIN";
}
