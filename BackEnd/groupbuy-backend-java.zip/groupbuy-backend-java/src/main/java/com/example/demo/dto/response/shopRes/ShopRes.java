package com.example.demo.dto.response.shopRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.dto.response.authRes.UserRes;
import com.example.demo.dto.response.wardRes.WardDetailRes;
import com.example.demo.entities.Shop;

public class ShopRes extends IdNameRes {
    private UserRes userRes;
    private WardDetailRes wardDetailRes;

    public ShopRes(Integer id, String name, UserRes userRes, WardDetailRes wardDetailRes) {
        super(id, name);
        this.userRes = userRes;
        this.wardDetailRes = wardDetailRes;
    }

    public static ShopRes convertFromEntity(Shop shop) {
        return new ShopRes(shop.getShopID(), shop.getName(), new UserRes(shop.getUser()), WardDetailRes.convertFromEntity(shop.getWard()));
    }
}
