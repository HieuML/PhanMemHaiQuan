package com.example.demo.dto.response.statisticalRes.seller;

import com.example.demo.dto.response.statisticalRes.OrderStatistical;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StatisticalForSellerRes {
    private ShopStatistical shopStatistical;

    private OrderStatistical orderStatisticalByShop;
}
