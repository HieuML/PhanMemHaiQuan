package com.example.demo.service.commonService.impl;

import com.example.demo.dto.request.GetDistanceReq;
import com.example.demo.service.commonService.CommonService;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Service
public class CommonServiceImpl implements CommonService {
    @Override
    public Long getDistance(GetDistanceReq getDistanceReq) throws Exception {
        Long distance;
        var url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=" + getDistanceReq.getStartLocation() + "&destinations=" + getDistanceReq.getEndLocation() + "&key=AIzaSyAtdTWAUA78Q0bf5FaWF1o5ABbIvWkjXCE";
        var request = HttpRequest.newBuilder().GET().uri(URI.create(url)).build();
        var client = HttpClient.newBuilder().build();
        var response = client.send(request, HttpResponse.BodyHandlers.ofString()).body();
        //parsing json data
        JSONParser jp = new JSONParser();
        JSONObject jo = (JSONObject) jp.parse(response);
        JSONArray ja = (JSONArray) jo.get("rows");
        jo = (JSONObject) ja.get(0);
        ja = (JSONArray) jo.get("elements");
        jo = (JSONObject) ja.get(0);
        JSONObject je = (JSONObject) jo.get("distance");
        distance = (Long) je.get("value");
        return distance;
    }
}


