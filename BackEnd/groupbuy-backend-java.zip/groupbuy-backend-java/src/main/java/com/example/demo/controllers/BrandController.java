package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.brandService.BrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/brand")
public class BrandController {
    @Autowired
    private BrandService brandService;

    @GetMapping(Path.GET_ALL)
    public ResponseEntity<BaseRes> getAll() {
        return ResponseEntity.ok(brandService.getAll());
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<BaseRes> createBrand(@RequestBody RequestName name) {
        return ResponseEntity.ok(brandService.create(name));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping(Path.UPDATE)
    public ResponseEntity<BaseRes> updateBrand(@RequestBody IdNameReq req){
        return ResponseEntity.ok(brandService.update(req));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping(Path.DELETE_BRAND)
    public ResponseEntity<BaseRes> deleteBrand(@PathVariable Integer brandID){
        return ResponseEntity.ok(brandService.delete(brandID));
    }
}
