package com.example.demo.dto.response.valuePropertyRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.ValueProperty;

public class ValuePropertyRes extends IdNameRes {
    public ValuePropertyRes(Integer id, String name) {
        super(id, name);
    }

    public static ValuePropertyRes convertFromEntity(ValueProperty valueProperty) {
        return new ValuePropertyRes(valueProperty.getValuePropertyID(),
                valueProperty.getName());
    }
}
