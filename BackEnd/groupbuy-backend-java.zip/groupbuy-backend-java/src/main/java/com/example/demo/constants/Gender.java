package com.example.demo.constants;

public interface Gender {
    String MALE = "MALE";
    String FEMALE = "FEMALE";
    String OTHER = "OTHER";
}
