package com.example.demo.dto.request.cartItemReq;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class GetShippingFeeReq {
    String userLocation;
    Integer shopID;
    Integer deliveryID;
}
