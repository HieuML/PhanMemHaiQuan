package com.example.demo.dto.request.invoiceReq;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class CreateListInvoiceReq {
    private List<InvoiceReq> listInvoiceReq;

    //Cho các đơn mua riêng còn mua chung mặc định là trả khi mà nhận hàng
    private Integer paymentID;

    // kiểm tra xem payment này có tồn tại không

    private Integer shippingAddressID;

    // Kiểm tra xem shippingAddressID có tồn tại ko và user có shippingAddress này  ko
}
