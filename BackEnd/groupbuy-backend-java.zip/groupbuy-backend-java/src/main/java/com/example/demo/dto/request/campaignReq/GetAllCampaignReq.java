package com.example.demo.dto.request.campaignReq;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetAllCampaignReq {
    private Integer shopID;
    private String sort;
    private String campaignName;
    private Integer limit;
    private Integer pageIndex;
}
