package com.example.demo.service.valuePropertyService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyCreateReq;
import com.example.demo.dto.request.valuePropertyReq.ValuePropertyUpdateReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.originRes.OriginRes;
import com.example.demo.dto.response.valuePropertyRes.ValuePropertyRes;
import com.example.demo.entities.Origin;
import com.example.demo.entities.Property;
import com.example.demo.entities.ValueProperty;
import com.example.demo.repository.PropertyRepository;
import com.example.demo.repository.ValuePropertyRepository;
import com.example.demo.service.valuePropertyService.ValuePropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ValuePropertyServiceImpl implements ValuePropertyService {
    @Autowired
    private ValuePropertyRepository valuePropertyRepository;

    @Autowired
    private PropertyRepository propertyRepository;

    @Override
    public List<ValuePropertyRes> getAllValueOfProperty(Integer propertyID) {
        return valuePropertyRepository.findByPropertyPropertyID(propertyID).stream().map(s -> ValuePropertyRes.convertFromEntity(s)).toList();
    }

    public BaseRes create(ValuePropertyCreateReq req) {
        Optional<ValueProperty> valuePropertyEntity = valuePropertyRepository.findValuePropertyByName(req.getName());
        Optional<Property> propertyEntity = propertyRepository.findById(req.getPropertyID());
        if (valuePropertyEntity.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(), TextStatus.NAME_HAS_EXISTED, null);

        if(propertyEntity.isEmpty())
            return new BaseRes(HttpStatus.NOT_FOUND.value(), TextStatus.PROPERTY_NOT_FOUND, null);
        ValueProperty newValueProperty = new ValueProperty();
        newValueProperty.setCreatedAt(new Date().getTime());
        newValueProperty.setUpdatedAt(new Date().getTime());
        newValueProperty.setName(req.getName());
        newValueProperty.setProperty(propertyEntity.get());
        valuePropertyRepository.save(newValueProperty);
        return new BaseRes(HttpStatus.OK.value(), TextStatus.CREATE_SUCCESS,
                ValuePropertyRes.convertFromEntity(valuePropertyRepository.findValuePropertyByName(req.getName()).get()));
    }

    @Override
    public BaseRes update(ValuePropertyUpdateReq req) {
        Optional<ValueProperty> entity = valuePropertyRepository.findById(req.getId());
        Optional<ValueProperty> valuePropertyHasSameName = valuePropertyRepository.findValuePropertyByName(req.getName());
        Optional<Property> propertyEntity = propertyRepository.findById(req.getPropertyID());
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);
        if (valuePropertyHasSameName.isPresent())
            return new BaseRes(HttpStatus.BAD_REQUEST.value(),
                    TextStatus.NAME_HAS_EXISTED,
                    null);
        if(propertyEntity.isEmpty())
            return new BaseRes(HttpStatus.NOT_FOUND.value(),
                    TextStatus.PROPERTY_NOT_FOUND, null);

        ValueProperty entityUpdate = entity.get();
        entityUpdate.setName(req.getName());
        entityUpdate.setUpdatedAt(new Date().getTime());
        entityUpdate.setProperty(propertyEntity.get());
        valuePropertyRepository.save(entityUpdate);
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.UPDATE_SUCCESS,
                new BaseUpdated<>(entityUpdate.getValuePropertyID(), true)
        );
    }

    @Override
    public BaseRes delete(Integer valuePropertyID) {
        Optional<ValueProperty> entity = valuePropertyRepository.findById(valuePropertyID);
        if (entity.isEmpty())
            return new BaseRes((HttpStatus.NOT_FOUND.value()),
                    TextStatus.NOT_FOUND,
                    null);

        valuePropertyRepository.delete(entity.get());
        return new BaseRes(HttpStatus.OK.value(),
                TextStatus.DELETE_SUCCESS,
                new BaseUpdated<>(entity.get().getValuePropertyID(), true)
        );
    }
}
