package com.example.demo.service.cityService.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.cityRes.CityRes;
import com.example.demo.repository.CityRepository;
import com.example.demo.service.cityService.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.stream.Collectors;

@Service
public class CityServiceImpl implements CityService {
    @Autowired
    private CityRepository cityRepository;

    @Override
    @Transactional
    public BaseRes getAll() {
        try {
            return new BaseRes<>(HttpStatus.OK.value(),
                    TextStatus.GET_ALL_CITY,
                    cityRepository.findAll().stream().map(x -> CityRes.convertFromEntity(x)).collect(Collectors.toList()));
        } catch (Exception error) {
            return new BaseRes<>(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    TextStatus.INTERNAL_SERVER_ERROR,
                    null);
        }
    }
}
