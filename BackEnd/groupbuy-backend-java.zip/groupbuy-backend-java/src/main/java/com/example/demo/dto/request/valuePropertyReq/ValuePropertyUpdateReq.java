package com.example.demo.dto.request.valuePropertyReq;

import com.example.demo.dto.request.IdNameReq;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ValuePropertyUpdateReq extends IdNameReq {
    private Integer propertyID;

    public ValuePropertyUpdateReq(Integer id, String name, Integer propertyID) {
        super(id, name);
        this.propertyID = propertyID;
    }
}
