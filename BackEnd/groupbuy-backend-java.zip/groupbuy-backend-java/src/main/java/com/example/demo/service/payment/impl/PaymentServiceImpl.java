package com.example.demo.service.payment.impl;

import com.example.demo.constants.TextStatus;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.paymentRes.PaymentRes;
import com.example.demo.entities.Payment;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.service.payment.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PaymentServiceImpl implements PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    @Transactional
    public BaseRes getAll() {
        try {
            List<Payment> entities = paymentRepository.findAll();
            return new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_PAYMENT,
                    entities.stream().map(x -> new PaymentRes(x.getPaymentID(), x.getName())).collect(Collectors.toList()));
        } catch (Exception error) {
            return new BaseRes<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), TextStatus.INTERNAL_SERVER_ERROR, null);
        }
    }
}
