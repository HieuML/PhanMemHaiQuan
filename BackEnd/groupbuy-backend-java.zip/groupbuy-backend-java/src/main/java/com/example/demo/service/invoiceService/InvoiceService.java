package com.example.demo.service.invoiceService;

import com.example.demo.dto.request.invoiceReq.CreateListInvoiceReq;
import com.example.demo.dto.request.invoiceReq.GetLstInvoiceReq;
import com.example.demo.dto.response.invoiceRes.GetLstInvoiceRes;
import com.example.demo.dto.response.invoiceRes.InvoiceRes;

import javax.servlet.http.HttpServletRequest;

public interface InvoiceService {
    /**
     * get all invoice
     *
     * @param servletRequest
     * @param req
     * @return
     */
    GetLstInvoiceRes getAll(HttpServletRequest servletRequest, GetLstInvoiceReq req);

    /**
     * get detail invoice
     *
     * @param invoiceID
     * @return
     */
    InvoiceRes getDetailInvoice(String invoiceID);

    /**
     * change status invoice
     *
     * @param servletRequest
     * @param invoiceID
     */
    void changeStatusInvoice(HttpServletRequest servletRequest, String invoiceID);

    void returnedInvoice(String invoiceID);

    void cancelReturnInvoice(String invoiceID);

    /**
     * complete invoice
     *
     * @param invoiceID
     */
    void completedInvoice(String invoiceID);

    /**
     * create list invoice
     *
     * @param servletRequest
     * @param createListInvoiceReq
     * @return
     */
    String createListInvoice(HttpServletRequest servletRequest, CreateListInvoiceReq createListInvoiceReq);

}
