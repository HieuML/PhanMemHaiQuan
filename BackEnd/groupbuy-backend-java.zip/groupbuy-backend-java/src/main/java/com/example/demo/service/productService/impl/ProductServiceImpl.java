package com.example.demo.service.productService.impl;

import com.example.demo.constants.Sort;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.inStockProductReq.InstockProductReq;
import com.example.demo.dto.request.productReq.ChangeDefaultImageReq;
import com.example.demo.dto.request.productReq.CreateOrUpdateProductReq;
import com.example.demo.dto.request.productReq.GetAllProductReq;
import com.example.demo.dto.response.PageRes;
import com.example.demo.dto.response.productImageRes.ProductImageRes;
import com.example.demo.dto.response.productRes.ProductRes;
import com.example.demo.entities.*;
import com.example.demo.exception.*;
import com.example.demo.repository.*;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.productService.ProductService;
import com.example.demo.utils.CommonMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private BrandRepository brandRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private OriginRepository originRepository;
    @Autowired
    private ShopRepository shopRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ProductImageRepository productImageRepository;
    @Autowired
    private PropertyRepository propertyRepository;
    @Autowired
    private ValuePropertyRepository valuePropertyRepository;
    @Autowired
    private InStockProductRepository inStockProductRepository;
    @Autowired
    private CampaignRepository campaignRepository;

    @Override
    public Map<String, Object> getAllProductByShop(GetAllProductReq getALLProductReq) {
        String productName = getALLProductReq.getProductName();
        Integer pageIndex = getALLProductReq.getPageIndex();
        Integer limit = getALLProductReq.getLimit();
        String sort = getALLProductReq.getSort();
        String sortTmp = "";
        String[] sortArr;
        if (sort.equals("DEFAULT") || sort.equals("CREATED_ASC") || sort.equals("CREATED_DESC") ||
                sort.equals("PRICE_ASC") || sort.equals("PRICE_DESC")) {
            switch (sort) {
                case "DEFAULT":
                    sortTmp = Sort.DEFAULT;
                    break;
                case "CREATED_ASC":
                    sortTmp = Sort.CREATED_ASC;
                    break;
                case "CREATED_DESC":
                    sortTmp = Sort.CREATED_DESC;
                    break;
                case "PRICE_ASC":
                    sortTmp = Sort.PRICE_ASC;
                    break;
                case "PRICE_DESC":
                    sortTmp = Sort.PRICE_DESC;
                    break;
            }
            sortArr = sortTmp.split(",");
        } else {
            throw new ResourceNotFoundException(TextStatus.ORDER_NOT_FOUND);
        }
        if (sortArr[0].equals("id")) {
            sortArr[0] = "productID";
        }
        org.springframework.data.domain.Sort.Order order = new org.springframework.data.domain.Sort.Order(CommonMethod.findDirection(sortArr[1]), sortArr[0]);

        Pageable pagingSort = PageRequest.of(pageIndex, limit, org.springframework.data.domain.Sort.by(order));

        Page<Product> pageProds;

        if (getALLProductReq.getShopID() != null) {
            Optional<Shop> shop = shopRepository.findById(getALLProductReq.getShopID());
            if (shop.isEmpty()) {
                throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
            }
            if (productName != null && !productName.trim().equals("")) {
                pageProds = productRepository.findByShopAndNameContaining(productName, shop.get(), pagingSort);
            } else {
                pageProds = productRepository.findByShopShopID(getALLProductReq.getShopID(), pagingSort);
            }
        } else {
            if (productName != null && !productName.trim().equals("")) {
                pageProds = productRepository.findByIsActiveAndNameContaining(true, productName, pagingSort);
            } else {
                pageProds = productRepository.findByIsActive(true, pagingSort);
            }
        }
        List<ProductRes> listProductsRes = new ArrayList<>();
        for (Product product : pageProds.getContent()) {
            listProductsRes.add(new ProductRes(product, inStockProductRepository, valuePropertyRepository));
        }
        Map<String, Object> response = new HashMap<>();
        response.put("totalItem", pageProds.getTotalElements());
        response.put("listProduct", listProductsRes);
        PageRes pageRes = new PageRes(pageProds.getTotalPages(),
                limit,
                pageIndex,
                pageIndex != pageProds.getTotalPages() - 1
        );
        response.put("pageRes", pageRes);
        return response;
    }

    @Override
    public ProductRes getDetailProduct(String productID) {
        Optional<Product> productData = productRepository.findById(productID);
        if (productData.isPresent()) {
            Product product_ = productRepository.findById(productID).get();
            return new ProductRes(product_, inStockProductRepository, valuePropertyRepository);
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_PRODUCT_ERROR);
        }
    }

    public void createInStock(CreateOrUpdateProductReq product, Product newProduct) {
        if (product.getPropertyID() != null) {
            Optional<Property> propertyData = propertyRepository.findById(product.getPropertyID());
            if (propertyData.isEmpty()) throw new ResourceNotFoundException(TextStatus.PROPERTY_NOT_FOUND);
            Property property = propertyData.get();
            ArrayList<InstockProductReq> listInStockProduct = product.getListInStockProduct();
            Iterator<InstockProductReq> iterator = listInStockProduct.iterator();
            while (iterator.hasNext()) {
                ValueProperty valueProperty = null;
                InstockProductReq inStockProductReq = iterator.next();
                String valuePropertyName = inStockProductReq.getValueProperty();
                Optional<Integer> valuePropertyData = valuePropertyRepository.findByNameLike(valuePropertyName);
                if (valuePropertyData.isEmpty()) {
                    valueProperty = valuePropertyRepository.save(new ValueProperty(valuePropertyName, property));
                } else {
                    valueProperty = valuePropertyRepository.findById(valuePropertyData.get()).get();
                }
                inStockProductRepository.save(new InStockProduct(inStockProductReq.getInStock(), newProduct, valueProperty));
            }

        } else {
            newProduct.setInStock(product.getInStock());
            productRepository.save(newProduct);
        }
    }
    
    public Product createBrandOriginCategory(CreateOrUpdateProductReq product, Shop shop) {
        Product newProduct = new Product(product.getName(), product.getDescription(), product.getPrice(), product.getOriginPrice(), shop);
        if (product.getBrandID() != null) {
            Optional<Brand> brandData = brandRepository.findById(product.getBrandID());
            if (!brandData.isPresent()) {
                throw new ResourceNotFoundException(TextStatus.BRAND_NOT_FOUND);
            }
            newProduct.setBrand(brandData.get());
        }
        if (product.getCategoryID() != null) {
            Optional<Category> categoryData = categoryRepository.findById(product.getCategoryID());
            if (!categoryData.isPresent()) {
                throw new ResourceNotFoundException(TextStatus.CATEGORY_NOT_FOUND);
            }
            newProduct.setCategory(categoryData.get());
        }
        if (product.getOriginID() != null) {
            Optional<Origin> originData = originRepository.findById(product.getOriginID());
            if (!originData.isPresent()) {
                throw new ResourceNotFoundException(TextStatus.ORIGIN_NOT_FOUND);
            }
            newProduct.setOrigin(originData.get());
        }
        return newProduct;
    }

    public void createProductImage(CreateOrUpdateProductReq product, Product newProduct) {
        Integer defaultUrl = product.getDefaultUrl();
        Iterator<String> iterator = product.getListUrl().iterator();
        int i = 0;
        while (iterator.hasNext()) {
            ProductImage productImage = new ProductImage(iterator.next(), newProduct);
            if (i++ == defaultUrl) {
                productImage.setIsDefault(true);
                newProduct.setProductImage(productImage.getUrl());
                productRepository.save(newProduct);
            }
            productImageRepository.save(productImage);
        }
    }

    public void checkInStock(CreateOrUpdateProductReq product) {
        if (product.getInStock() == null) {
            if (product.getPropertyID() == null) throw new BadRequestException(TextStatus.MISSING_INSTOCK);
            if (product.getListInStockProduct() == null || product.getListInStockProduct().size() < 1)
                throw new BadRequestException(TextStatus.MISSING_VALUE_PROPERTY);
        } else {
            if (!(product.getPropertyID() != null && product.getListInStockProduct() != null
                    && product.getListInStockProduct().size() > 0) && !(product.getPropertyID() == null && product.getListInStockProduct() == null))
                throw new BadRequestException(TextStatus.MISSING_VALUE_PROPERTY);
        }
    }


    @Override
    public ProductRes createProduct(HttpServletRequest request, CreateOrUpdateProductReq product) {
        // Lấy username
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        //Check shop
        Optional<Shop> shopData = shopRepository.findByUserId(userID);
        if (shopData.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
        }
        //Check brand, origin, category
        Product newProduct = createBrandOriginCategory(product, shopData.get());
        //Check inStock
        checkInStock(product);
        productRepository.save(newProduct);
        //Tạo instock
        createInStock(product, newProduct);
        //Tạo image
        createProductImage(product, newProduct);
        productRepository.save(newProduct);
        return new ProductRes(newProduct, inStockProductRepository, valuePropertyRepository);
    }

    @Override
    public void updateProduct(HttpServletRequest request, String productID, CreateOrUpdateProductReq product) {
        //Lấy userName
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Optional<Product> productData = productRepository.findById(productID);
        if (productData.isEmpty()) throw new ResourceNotFoundException(TextStatus.NOT_FOUND_PRODUCT_ERROR);
        //Check own product
        if (!testOwnProduct(request, productID)) throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
        Product product_ = productData.get();
        //Kiểm tra xem product có thuộc một campain chưa chạy hoặc đang chạy ko
        Optional<String> campaignData = campaignRepository.checkUpdateProduct(product_, new Date().getTime());
        if (campaignData.isPresent()) throw new BadRequestException(TextStatus.UPDATE_PRODUCT_ERROR);
        //Kiểm tra inStock
        checkInStock(product);
        //Check shop
        Optional<Shop> shopData = shopRepository.findByUserId(userID);
        if (shopData.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
        }
        Product newProduct = createBrandOriginCategory(product, shopData.get());
        //Cập nhật inStock
        product_.setInStock(0);
        inStockProductRepository.deleteByProductProductID(productID);
        createInStock(product, product_);
        //Cập nhật image
        productImageRepository.deleteByProductProductID(productID);
        createProductImage(product, product_);
        product_.setName(newProduct.getName());
        product_.setDescription(newProduct.getDescription());
        product_.setPrice(newProduct.getPrice());
        product_.setOriginPrice(newProduct.getOriginPrice());
        product_.setShop(newProduct.getShop());
        product_.setBrand(newProduct.getBrand());
        product_.setCategory(newProduct.getCategory());
        product_.setOrigin(newProduct.getOrigin());
        product_.setUpdatedAt(new Date().getTime());
        productRepository.save(product_);
    }

    @Override
    public void deleteProduct(HttpServletRequest request, String productID) {
        Optional<Product> productData = productRepository.findById(productID);
        if (productData.isPresent()) {
            if (!testOwnProduct(request, productID)) throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            productRepository.deleteById(productID);
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_PRODUCT_ERROR);
        }
    }

    @Override
    public void changeStatus(HttpServletRequest request, String productID) {
        Optional<Product> productData = productRepository.findById(productID);
        if (productData.isPresent()) {
            if (!testOwnProduct(request, productID)) throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            Product product_ = productData.get();
            //Kiểm tra xem product có thuộc một campain chưa chạy hoặc đang chạy ko
            Optional<String> campaignData = campaignRepository.checkUpdateProduct(product_, new Date().getTime());
            if (campaignData.isPresent()) throw new BadRequestException(TextStatus.UPDATE_PRODUCT_ERROR);
            product_.changeIsActive();
            productRepository.save(product_);
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_PRODUCT_ERROR);
        }
    }

    @Override
    public List<ProductImageRes> getAllImageByProduct(String productID) {
        Optional<Product> productData = productRepository.findById(productID);
        if (productData.isPresent()) {
            return productImageRepository.findByProductProductID(productID).stream().map(s -> ProductImageRes.convertFromEntity(s)).toList();
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_PRODUCT_ERROR);
        }
    }

    @Override
    public void changeDefaultImage(HttpServletRequest request, ChangeDefaultImageReq changeDefaultImageReq) {
        String productID = changeDefaultImageReq.getProductID();
        Integer defaultUrl = changeDefaultImageReq.getDefaultUrl();
        Optional<Product> productData = productRepository.findById(productID);
        Product product = productData.get();
        if (productData.isPresent()) {
            if (!testOwnProduct(request, productID)) throw new ResourceNotFoundException(TextStatus.UNAUTHORIZED);
            ArrayList<ProductImage> imageArrayList = productImageRepository.findByProductProductID(productID);
            imageArrayList.stream().filter(s -> s.getIsDefault()).findFirst().get().setIsDefault(false);
            Iterator<ProductImage> iterator = imageArrayList.iterator();
            int i = 0;
            while (iterator.hasNext()) {
                ProductImage productImage = iterator.next();
                if (i++ == defaultUrl) {
                    productImage.setIsDefault(true);
                    product.setProductImage(productImage.getUrl());
                    productRepository.save(product);
                }
                productImageRepository.save(productImage);
            }
        } else {
            throw new ResourceNotFoundException(TextStatus.NOT_FOUND_PRODUCT_ERROR);
        }
    }


    public boolean testOwnProduct(HttpServletRequest request, String productID) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Optional<Shop> shopData = shopRepository.findByUserId(userID);
        if (shopData.isEmpty()) {
            throw new ResourceNotFoundException(TextStatus.SHOP_NOT_FOUND);
        }
        Integer shopID = shopData.get().getShopID();
        List<Product> product_list = productRepository.findByShopShopID(shopID);
        Optional<Product> product = product_list.stream().filter(s -> s.getProductID() == productID).findFirst();
        return product.isPresent();
    }

//    public Page<ProductSearchDTO> convertPageFromEntity(Page<Product> productPage){
//        Page<ProductSearchDTO> rs = new PageImpl<>(productPage.getContent().stream().map(x -> ProductSearchDTO.convertFromEntity(x)).
//                collect(Collectors.toList()),
//                productPage.getPageable(),
//                productPage.getTotalPages());
//        return rs;
//    }
}
