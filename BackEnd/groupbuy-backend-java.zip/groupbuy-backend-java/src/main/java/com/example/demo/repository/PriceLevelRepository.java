package com.example.demo.repository;

import com.example.demo.entities.PriceLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface PriceLevelRepository extends JpaRepository<PriceLevel, String> {
    @Transactional
    void deleteByCampaignCampaignID(String campaignID);

    List<PriceLevel> findByCampaignCampaignID(String campaignID);
}
