package com.example.demo.dto.request.priceLevelRequest;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PriceLevelReq {
    private Integer quantity;
    private Integer price;
}
