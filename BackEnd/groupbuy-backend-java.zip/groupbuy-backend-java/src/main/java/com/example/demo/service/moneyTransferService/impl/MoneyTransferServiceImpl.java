package com.example.demo.service.moneyTransferService.impl;

import com.example.demo.constants.RoleName;
import com.example.demo.constants.Status;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.adminReq.ConfirmOrCancelTransactionReq;
import com.example.demo.dto.request.productReq.GetAllMoneyTransferReq;
import com.example.demo.dto.response.PageRes;
import com.example.demo.dto.response.moneyTransferActivityRes.MoneyTransferActivityRes;
import com.example.demo.entities.MoneyTransferActivity;
import com.example.demo.entities.User;
import com.example.demo.exception.*;
import com.example.demo.repository.MoneyTransferActivityRepo;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.moneyTransferService.MoneyTransferService;
import com.example.demo.utils.CommonMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Service
public class MoneyTransferServiceImpl implements MoneyTransferService {
    @Autowired
    MoneyTransferActivityRepo moneyTransferActivityRepo;
    @Autowired
    JwtUtils jwtUtils;

    @Autowired
    UserRepository userRepository;

    @Override
    public Map<String, Object> getAllMoneyTransfer(HttpServletRequest request, GetAllMoneyTransferReq getAllMoneyTransferReq) {
        Integer pageIndex = getAllMoneyTransferReq.getPageIndex();
        Integer limit = getAllMoneyTransferReq.getLimit();
        String filter = getAllMoneyTransferReq.getFilter();
        org.springframework.data.domain.Sort.Order order = new org.springframework.data.domain.Sort.Order(CommonMethod.findDirection("desc"), "updatedAt");
        Pageable pagingSort = PageRequest.of(getAllMoneyTransferReq.getPageIndex(), getAllMoneyTransferReq.getLimit(), org.springframework.data.domain.Sort.by(order));
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Optional<User> userByUsername = userRepository.findByUsername(username);
        String roleNameUser = userByUsername.get().getRole().getName();
        Integer userID = userByUsername.get().getId();
        Page<MoneyTransferActivity> pageMoneyTransfers = null;
        if (filter.equals(Status.DEFAULT) || filter.equals(Status.WAITING_CONFIRM) || filter.equals(Status.CONFIRMED) || filter.equals(Status.CANCELLED)) {
            switch (filter) {
                case Status.DEFAULT: {
                    //role là admin
                    if (roleNameUser.equals(RoleName.ADMIN)) {
                        pageMoneyTransfers = moneyTransferActivityRepo.findAll(pagingSort);
                        break;
                    }//role là customer hoặc seller
                    else {
                        pageMoneyTransfers = moneyTransferActivityRepo.findByFromUserIDOrToUserID(userID, userID, pagingSort);
                        break;
                    }
                }
                default: {
                    //role là admin
                    if (roleNameUser.equals(RoleName.ADMIN)) {
                        pageMoneyTransfers = moneyTransferActivityRepo.findByStatus(filter, pagingSort);
                        break;
                    }
                    //role là customer hoặc seller
                    else {
                        pageMoneyTransfers = moneyTransferActivityRepo.findByStatusAndFromUserIDOrStatusAndToUserID(filter, userID, filter, userID, pagingSort);
                    }
                }
            }
        } else {
            throw new ResourceNotFoundException(TextStatus.FILTER_MONEY_TRANSFER_STATUS_NOT_FOUND);
        }
        List<MoneyTransferActivityRes> listMoneyTransfersRes = new ArrayList<>();
        for (MoneyTransferActivity moneyTransferActivity : pageMoneyTransfers.getContent()) {
            listMoneyTransfersRes.add(MoneyTransferActivityRes.convertFromEntity(moneyTransferActivity, userRepository));
        }
        Map<String, Object> response = new HashMap<>();
        response.put("totalItem", pageMoneyTransfers.getTotalElements());
        response.put("listMoneyTransferActivities", listMoneyTransfersRes);
        PageRes pageRes = new PageRes(pageMoneyTransfers.getTotalPages(),
                limit,
                pageIndex,
                pageIndex != pageMoneyTransfers.getTotalPages() - 1
        );
        response.put("pageRes", pageRes);
        return response;
    }

    @Override
    public void cancelTransaction(HttpServletRequest request, ConfirmOrCancelTransactionReq confirmOrCancelTransactionReq) {
        Integer moneyTransferActivityID = confirmOrCancelTransactionReq.getMoneyTransferActivityID();
        Optional<MoneyTransferActivity> moneyTransferActivityData = moneyTransferActivityRepo.findById(moneyTransferActivityID);
        if (moneyTransferActivityData.isEmpty())
            throw new ResourceNotFoundException(TextStatus.MONEY_TRANSFER_ACTIVITY_NOT_FOUND);
        MoneyTransferActivity moneyTransferActivity = moneyTransferActivityData.get();
        if (!moneyTransferActivity.getStatus().equals(Status.WAITING_CONFIRM))
            throw new BadRequestException(TextStatus.ERROR_TRANSACTION_HAS_CONFIRMED_OR_CANCELLED);

        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Optional<User> userByUsername = userRepository.findByUsername(username);

        Integer userID = userByUsername.get().getId();
        String roleNameUser = userByUsername.get().getRole().getName();

        // role là customer hoặc seller
        if (roleNameUser.equals(RoleName.CUSTOMER) || roleNameUser.equals(RoleName.SELLER)) {
            if (moneyTransferActivity.getToUserID() != userID)
                throw new ForbiddenException(TextStatus.UNAUTHORIZED);
        }
        moneyTransferActivity.setStatus(Status.CANCELLED);
        moneyTransferActivity.setUpdatedAt(new Date().getTime());
        moneyTransferActivity.setDescription(TextStatus.TRANSITION_CANCEL_DESCRIPTION);
        moneyTransferActivityRepo.save(moneyTransferActivity);
    }
}
