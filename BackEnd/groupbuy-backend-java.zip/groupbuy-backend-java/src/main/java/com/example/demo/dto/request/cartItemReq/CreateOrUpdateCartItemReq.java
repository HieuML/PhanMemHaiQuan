package com.example.demo.dto.request.cartItemReq;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateOrUpdateCartItemReq {
    private String id;
    private Integer quantity;
    private Integer inStockProductID;
}
