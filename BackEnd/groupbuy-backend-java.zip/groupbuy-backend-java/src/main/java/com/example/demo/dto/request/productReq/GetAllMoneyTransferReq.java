package com.example.demo.dto.request.productReq;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetAllMoneyTransferReq {
    private Integer limit;
    private Integer pageIndex;
    private String filter;
}
