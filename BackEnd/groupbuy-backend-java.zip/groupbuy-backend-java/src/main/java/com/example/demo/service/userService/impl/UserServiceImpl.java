package com.example.demo.service.userService.impl;

import com.example.demo.constants.AdminAccount;
import com.example.demo.constants.Sort;
import com.example.demo.constants.Status;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.UpdatePasswordRequest;
import com.example.demo.dto.request.userReq.ChangePasswordReq;
import com.example.demo.dto.request.userReq.GetLstAllUserReq;
import com.example.demo.dto.request.walletReq.TopUpOrWithdrawReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.PageRes;
import com.example.demo.dto.response.authRes.UserRes;
import com.example.demo.dto.response.moneyTransferActivityRes.MoneyTransferActivityRes;
import com.example.demo.dto.response.userRes.ListUserRes;
import com.example.demo.dto.response.walletRes.DetailWalletRes;
import com.example.demo.entities.ConfirmationOTP;
import com.example.demo.entities.MoneyTransferActivity;
import com.example.demo.entities.User;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.MoneyTransferActivityRepo;
import com.example.demo.repository.OTPRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.repository.WalletRepository;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.userService.UserService;
import com.example.demo.utils.CommonMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private PasswordEncoder encoder;
    @Autowired
    private WalletRepository walletRepository;
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private UserRepository repository;
    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private OTPRepository otpRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private MoneyTransferActivityRepo moneyTransferActivityRepo;

    @Override
    public ListUserRes getAll(GetLstAllUserReq req) {
        List<String> sortArr = new ArrayList<>();
        String sortTmp = "";
        switch (req.getSort()) {
            case "DEFAULT":
                sortTmp = Sort.DEFAULT;
                break;
            case "CREATED_ASC":
                sortTmp = Sort.CREATED_ASC;
                break;
            case "CREATED_DESC":
                sortTmp = Sort.CREATED_DESC;
                break;
        }
        sortArr = Arrays.stream(sortTmp.split(",")).collect(Collectors.toList());
        org.springframework.data.domain.Sort.Order order = new org.springframework.data.domain.Sort.Order(CommonMethod.findDirection(sortArr.get(1)), sortArr.get(0));
        Pageable pageable = PageRequest.of(req.getPageIndex(),
                req.getLimit(),
                org.springframework.data.domain.Sort.by(order));
        Page<User> entity = userRepository.findAll(pageable);
        List<UserRes> userResList = entity.getContent().stream()
                .map(x -> new UserRes(x))
                .collect(Collectors.toList());
        PageRes pageRes = new PageRes(entity.getTotalPages(),
                entity.getSize(),
                entity.getPageable().getPageNumber(),
                entity.hasNext());
        ListUserRes rs = new ListUserRes(userResList, pageRes);
        return rs;
    }

    @Override
    public UserRes getById(Integer userID) {
        return new UserRes(repository.findById(userID).get());
    }

    @Override
    public List<UserRes> findByFirstName(String firstName) {
        return repository.findUsersByFirstNameContaining(firstName).stream().map(x -> new UserRes(x)).collect(Collectors.toList());
    }

    @Async
    @Transactional
    @Override
    public boolean sendOTP(String email) {
        try {
            if (repository.findUserByEmail(email).isEmpty()) {
                return false;
            }
            User user = repository.findUserByEmail(email).get();
            Optional<ConfirmationOTP> findOTPByUser = otpRepository.findConfirmationOTPByUserId(user.getId());
            ConfirmationOTP confirmationOTP = new ConfirmationOTP();
            if (findOTPByUser.isPresent()) {
                confirmationOTP = findOTPByUser.get();
            } else {
                confirmationOTP.setUserId(user.getId());
            }
            confirmationOTP.setOtp(UUID.randomUUID().toString().substring(0, 4));
            confirmationOTP.setCreatedAt(LocalDateTime.now());
            confirmationOTP.setExpiredAt(LocalDateTime.now().plusMinutes(15));
            confirmationOTP.setConfirmedAt(null);
            otpRepository.save(confirmationOTP);
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, "utf-8");
            helper.setText(confirmationOTP.getOtp(), true);
            helper.setTo(user.getEmail());
            helper.setSubject("Your otp to get password");
            helper.setFrom("phamduytung910016@gmail.com");
            javaMailSender.send(mimeMessage);
            return true;
        } catch (MessagingException e) {
            return false;
        }
    }

    @Override
    public Optional<Integer> confirmOTP(String otp) {
        if (otpRepository.findConfirmationOTPByOtp(otp).isEmpty()) {
            return Optional.empty();
        }
        ConfirmationOTP confirmationOTP = otpRepository.findConfirmationOTPByOtp(otp).get();
        if (confirmationOTP.getExpiredAt().isBefore(LocalDateTime.now())) {
            return Optional.empty();
        }
        confirmationOTP.setConfirmedAt(LocalDateTime.now());
        otpRepository.save(confirmationOTP);
        return Optional.of(confirmationOTP.getUserId());
    }

    @Override
    public boolean updatePassword(UpdatePasswordRequest updatePasswordRequest) {
        if (repository.findById(updatePasswordRequest.getUserId()).isEmpty()) {
            throw new IllegalStateException("Not found user");
        }
        User userNeedUpdatePassword = repository.findById(updatePasswordRequest.getUserId()).get();
        if (updatePasswordRequest.getNewPassword().length() <= 8) {
            throw new IllegalStateException("Password is illegal");
        }
        userNeedUpdatePassword.setPassword(encoder.encode(updatePasswordRequest.getNewPassword()));
        userNeedUpdatePassword.setUpdatedAt(new Date().getTime());
        repository.save(userNeedUpdatePassword);
        return true;
    }

    @Override
    public BaseRes<BaseUpdated> changePassword(HttpServletRequest request, ChangePasswordReq changePasswordReq) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        User user = userRepository.findByUsername(username).get();
        Integer userID = user.getId();
        String password = user.getPassword();
        System.out.println(encoder.encode(password));
        if (!encoder.matches(changePasswordReq.getOldPassword(), password))
            throw new ResourceNotFoundException(TextStatus.CHANGE_PASSWORD_ERROR);
        else {
            user.setPassword(encoder.encode(changePasswordReq.getNewPassword()));
            userRepository.save(user);
            return new BaseRes<>(HttpStatus.OK.value(), TextStatus.CHANGE_PASSWORD_SUCCESS, new BaseUpdated(userID, true));
        }
    }

    //Nạp tiền
    @Override
    public MoneyTransferActivityRes topUp(HttpServletRequest request, TopUpOrWithdrawReq topUpReq) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Integer topUpMoney = topUpReq.getMoney();
        if (topUpMoney < 1) {
            throw new BadRequestException(TextStatus.MONEY_TOP_UP_INVALID);
        }
        if (username.equals(AdminAccount.USERNAME)) {
            walletRepository.findByUserId(userID).addMoney(topUpMoney);
            MoneyTransferActivity moneyTransferActivity = new MoneyTransferActivity(null, userID, topUpMoney, Status.CONFIRMED, TextStatus.TRANSITION_SUCCESS_DESCRIPTION);
            moneyTransferActivityRepo.save(moneyTransferActivity);
            return MoneyTransferActivityRes.convertFromEntity(moneyTransferActivity, userRepository);
        } else {
            MoneyTransferActivity moneyTransferActivity = new MoneyTransferActivity(userRepository.findByUsername(AdminAccount.USERNAME).get().getId(), userID, topUpReq.getMoney(), Status.WAITING_CONFIRM, TextStatus.DESCRIPTION_ACTIVITY_WAITING);
            moneyTransferActivityRepo.save(moneyTransferActivity);
            return MoneyTransferActivityRes.convertFromEntity(moneyTransferActivity, userRepository);
        }
    }

    @Override
    public DetailWalletRes getInfoWalletByUser(HttpServletRequest request) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        return new DetailWalletRes(walletRepository.findByUserId(userID).getMoney());
    }

    //Rút tiền
    @Override
    public MoneyTransferActivityRes withdraw(HttpServletRequest request, TopUpOrWithdrawReq withdrawReq) {
        String username = CommonMethod.getUsernameFromJwt(request, jwtUtils);
        Integer userID = userRepository.findByUsername(username).get().getId();
        Integer withdrawMoney = withdrawReq.getMoney();
        if (withdrawMoney < 1) {
            throw new BadRequestException(TextStatus.MONEY_WITHDRAW_INVALID);
        }
        if (username.equals(AdminAccount.USERNAME)) {
            Integer adminMoney = walletRepository.findByUserId(userID).getMoney();
            if (adminMoney < withdrawMoney) throw new BadRequestException(TextStatus.WITHDRAW_ERROR);
            walletRepository.findByUserId(userID).subMoney(withdrawMoney);
            MoneyTransferActivity moneyTransferActivity = new MoneyTransferActivity(userID, null, withdrawMoney, Status.CONFIRMED, TextStatus.TRANSITION_SUCCESS_DESCRIPTION);
            moneyTransferActivityRepo.save(moneyTransferActivity);
            return MoneyTransferActivityRes.convertFromEntity(moneyTransferActivity, userRepository);
        } else {
            Integer userMoney = walletRepository.findByUserId(userID).getMoney();
            if (userMoney < withdrawMoney) throw new BadRequestException(TextStatus.WITHDRAW_ERROR);
            MoneyTransferActivity moneyTransferActivity = new MoneyTransferActivity(userID, userRepository.findByUsername(AdminAccount.USERNAME).get().getId(), withdrawReq.getMoney(), Status.WAITING_CONFIRM, TextStatus.DESCRIPTION_ACTIVITY_WAITING);
            moneyTransferActivityRepo.save(moneyTransferActivity);
            return MoneyTransferActivityRes.convertFromEntity(moneyTransferActivity, userRepository);
        }
    }

    @Override
    public BaseRes<BaseUpdated> updateStatusUser(Integer userID) {
        Optional<User> entity = userRepository.findById(userID);
        if (entity.isEmpty())
            return new BaseRes<>(HttpStatus.NOT_FOUND.value(), TextStatus.USER_NOT_FOUND, null);
        User userUpdate = entity.get();
        userUpdate.setIsActive(!userUpdate.getIsActive());
        userUpdate.setUpdatedAt(new Date().getTime());
        userRepository.save(userUpdate);
        return new BaseRes<>(HttpStatus.OK.value(), TextStatus.UPDATE_STATUS, new BaseUpdated<>(userUpdate.getId(), true));
    }
}
