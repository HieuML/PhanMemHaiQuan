package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.campaignReq.CreateOrUpdateCampaignReq;
import com.example.demo.dto.request.campaignReq.GetAllCampaignReq;
import com.example.demo.dto.request.campaignReq.GetLstCampaignByUserIdReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.BaseUpdated;
import com.example.demo.dto.response.campaignRes.GetLstCampaignRes;
import com.example.demo.service.campaignService.CampaignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/campaign")
public class CampaignController {
    @Autowired
    private CampaignService campaignService;

    @PostMapping(Path.GET_ALL)
    public ResponseEntity<?> getAllCampaign(@RequestBody GetAllCampaignReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_ALL_CAMPAIGN_SUCCESS, campaignService.getAllCampaignByShop(req)));
    }

    @PostMapping(Path.GET_BY_SHOP)
    public ResponseEntity<?> getAllCampaignByShop(@RequestBody GetAllCampaignReq req) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_CAMPAIGN_BY_SHOP_SUCCESS, campaignService.getAllCampaignByShop(req)));
    }

    @GetMapping(Path.GET_DETAIL_CAMPAIGN)
    public ResponseEntity<BaseRes> getDetailCampaign(@PathVariable String campaignID) {
        if (campaignService.getByCampId(campaignID).isPresent())
            return ResponseEntity.ok(new BaseRes(HttpStatus.OK.value(), TextStatus.GET_CAMPAIGN_BY_ID_SUCCESS, campaignService.getByCampId(campaignID).get()));
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.NOT_FOUND.value(), TextStatus.GET_CAMPAIGN_BY_ID_FAIL, null));
    }

    @PostMapping(Path.GET_BY_USER)
    public ResponseEntity<BaseRes> getByUserId(@RequestBody GetLstCampaignByUserIdReq getLstCampaignByUserIdReq) {
        if (campaignService.getByUserId(getLstCampaignByUserIdReq) == null)
            return ResponseEntity.ok(new BaseRes<GetLstCampaignRes>(HttpStatus.NOT_FOUND.value(), TextStatus.GET_CAMPAIGN_BY_USER_ID_FAIL, null));
        return ResponseEntity.ok(new BaseRes<GetLstCampaignRes>(HttpStatus.OK.value(), TextStatus.GET_CAMPAIGN_BY_USER_ID_SUCCESS, campaignService.getByUserId(getLstCampaignByUserIdReq)));
    }

    @PreAuthorize("hasRole('SELLER')")
    @PostMapping(Path.CREATE)
    public ResponseEntity<?> createCampaign(HttpServletRequest request, @RequestBody CreateOrUpdateCampaignReq campaign) {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CREATE_CAMPAIGN_SUCCESS, campaignService.createCampaign(request, campaign)));
    }

    @PreAuthorize("hasRole('SELLER')")
    @PostMapping(Path.CHANGE_ACTIVE_CAMPAIGN)
    public ResponseEntity<?> changeActive(HttpServletRequest request, @PathVariable String campaignID) {
        campaignService.changeActive(request, campaignID);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.CHANGE_STATUS_CAMPAIGN_SUCCESS, new BaseUpdated(campaignID, true)));
    }

    //Not use
    @PostMapping(Path.DELETE_CAMPAIGN)
    public ResponseEntity<?> deleteCampaign(HttpServletRequest request, @PathVariable String campaignID) {
        campaignService.deleteCampaign(request, campaignID);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.DELETE_CAMPAIGN_SUCCESS));
    }

    @PreAuthorize("hasRole('SELLER')")
    @PostMapping(Path.UPDATE_CAMPAIGN)
    public ResponseEntity<?> updateCampaign(HttpServletRequest request, @PathVariable String campaignID, @RequestBody CreateOrUpdateCampaignReq campaign) {
        campaignService.updateCampaign(request, campaignID, campaign);
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.UPDATE_CAMPAIGN_SUCCESS, new BaseUpdated(campaignID, true)));
    }

}
