package com.example.demo.dto.request.invoiceReq;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class InvoiceReq {
    private Integer shopID;
    private List<Integer> listCartItemID;
    private Integer deliveryID;
    // Kiểm tra xem delivery này có tồn tại ko
    private Integer buyTypeID;
    // Kiểm tra xem buyType này có tồn tại ko
}
