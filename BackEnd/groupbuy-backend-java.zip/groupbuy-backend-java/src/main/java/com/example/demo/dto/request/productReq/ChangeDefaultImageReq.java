package com.example.demo.dto.request.productReq;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ChangeDefaultImageReq {
    private String productID;
    private Integer defaultUrl;
}
