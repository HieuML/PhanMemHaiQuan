package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "wallet")
@Setter
@Getter
@NoArgsConstructor
public class Wallet {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "wallet_id")
    private Integer walletID;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_inform_id")
    private User user;
    private Integer money;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public void addMoney(Integer money) {
        this.money += money;
    }

    public void subMoney(Integer money) {
        this.money -= money;
    }

    public Wallet(User user) {
        this.user = user;
        this.money = 0;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
    }
}

