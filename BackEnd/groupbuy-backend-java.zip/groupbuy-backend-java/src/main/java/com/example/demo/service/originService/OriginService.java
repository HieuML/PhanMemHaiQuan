package com.example.demo.service.originService;

import com.example.demo.dto.request.IdNameReq;
import com.example.demo.dto.request.RequestName;
import com.example.demo.dto.response.BaseRes;

public interface OriginService {
    /**
     * get all origins
     *
     * @return
     */
    BaseRes getAll();

    /**
     * create origin
     *
     * @param name
     * @return
     */
    BaseRes create(RequestName name);

    /**
     * update origin
     * @param req
     * @return
     */
    BaseRes update(IdNameReq req);

    /**
     * delete origin
     * @param originID
     * @return
     */
    BaseRes delete(Integer originID);
}
