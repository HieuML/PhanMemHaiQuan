package com.example.demo.service.cityService;

import com.example.demo.dto.response.BaseRes;

public interface CityService {
    /**
     * get all cities
     *
     * @return
     */
    BaseRes getAll();
}
