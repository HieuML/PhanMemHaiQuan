package com.example.demo.dto.response.cartItemRes;

import com.example.demo.dto.response.IdNameRes;
import com.example.demo.entities.Shop;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class GetAllCartItemByUserRes {
    private IdNameRes shop;
    private List<CartItemRes> listCartItemRes;
    private Integer totalItem;

    public GetAllCartItemByUserRes(Shop shop, List<CartItemRes> listCartItemRes, Integer totalItem) {
        this.shop = new IdNameRes(shop.getShopID(), shop.getName());
        this.listCartItemRes = listCartItemRes;
        this.totalItem = totalItem;
    }
}


