package com.example.demo.dto.request.adminReq;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ConfirmOrCancelTransactionReq {
    private Integer moneyTransferActivityID;
}
