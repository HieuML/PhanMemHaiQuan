package com.example.demo.dto.response.statisticalRes;


import com.example.demo.dto.response.statisticalRes.SumObjectByDate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class OrderStatistical {
    private Long sumOrder;
    private Long sumOrderCompleted;
    private Long sumOrderCancel;
    private Long sumOrderReturn;
    private List<SumObjectByDate> listSumOrderInTime;
    private List<SumObjectByDate> listSumOrderCompletedInTime;
    private List<SumObjectByDate> listSumOrderCancelledInTime;
    private List<SumObjectByDate> lstSumOrderReturnInTime;
}
