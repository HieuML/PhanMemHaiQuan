package com.example.demo.dto.response.campaignRes;

import com.example.demo.dto.response.priceLevelRes.PriceLevelRes;
import com.example.demo.dto.response.productRes.InStockProductRes;
import com.example.demo.dto.response.productRes.ProductRes;
import com.example.demo.dto.response.shopRes.ShopDetailRes;
import com.example.demo.entities.PriceLevel;
import com.example.demo.entities.Campaign;
import com.example.demo.entities.InStockProduct;
import com.example.demo.repository.InStockProductRepository;
import com.example.demo.repository.PriceLevelRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.stream.Collectors;

@Setter
@Getter
@AllArgsConstructor
public class CampaignRes1 {
    private String campaignID;
    private String name;
    private Integer deposit;
    private Integer priceCurrent;
    private Long startTime;
    private Long endTime;
    private ProductRes productRes;
    private ShopDetailRes shopDetailRes;
    private Integer inStock;
    private Boolean isActive;
    private List<PriceLevelRes> listPriceLevel;
    private List<InStockProductRes> listInStock;
    private Integer soldQuantity;
    private String status;

    public CampaignRes1(Campaign campaign, ProductRes productRes, ShopDetailRes shopDetailRes, PriceLevelRepository priceLevelRepository, InStockProductRepository inStockProductRepository) {
        this.campaignID = campaign.getCampaignID();
        this.name = campaign.getName();
        this.deposit = campaign.getDeposit();
        this.priceCurrent = campaign.getPriceCurrent();
        this.startTime = campaign.getStartTime();
        this.endTime = campaign.getEndTime();
        this.inStock = campaign.getInStock();
        this.isActive = campaign.getIsActive();
        this.productRes = productRes;
        this.shopDetailRes = shopDetailRes;
        this.soldQuantity = campaign.getSoldQuantity();
        this.status = campaign.getStatus();
        List<PriceLevel> listPriceLevel = priceLevelRepository.findByCampaignCampaignID(campaign.getCampaignID());

        if (listPriceLevel.size() != 0) {
            listPriceLevel = listPriceLevel.stream().sorted((a,b)-> b.getPrice().compareTo(a.getPrice())).collect(Collectors.toList());
            this.listPriceLevel = listPriceLevel.stream().map(s -> PriceLevelRes.convertFromEntity(s)).toList();
        }
        List<InStockProduct> listInStock = inStockProductRepository.findByCampaignCampaignID(campaign.getCampaignID());
        if (listInStock.size() != 0) {
            this.listInStock = listInStock.stream().map(s -> InStockProductRes.convertFromEntity(s)).toList();
        }
    }
}
