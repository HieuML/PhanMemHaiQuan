package com.example.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class BaseRes<T> {
    private int status;
    private String textStatus;
    private T data;

    public BaseRes(int status, String textStatus) {
        this.status = status;
        this.textStatus = textStatus;
    }
}
