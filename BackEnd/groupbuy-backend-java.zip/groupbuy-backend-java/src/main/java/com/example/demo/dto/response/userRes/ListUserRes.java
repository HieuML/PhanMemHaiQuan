package com.example.demo.dto.response.userRes;

import com.example.demo.dto.response.PageRes;
import com.example.demo.dto.response.authRes.UserRes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Getter
@Service
@AllArgsConstructor
@NoArgsConstructor
public class ListUserRes {
    private List<UserRes> listUsers;
    private PageRes pageRes;
}
