package com.example.demo.controllers;

import com.example.demo.constants.Path;
import com.example.demo.constants.TextStatus;
import com.example.demo.dto.request.GetDistanceReq;
import com.example.demo.dto.response.BaseRes;
import com.example.demo.service.commonService.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(path = "api/")
public class CommonController {
    @Autowired
    private CommonService commonService;

    //Not use
    @GetMapping(Path.GET_DISTANCE)
    public ResponseEntity<BaseRes> getDistance(@RequestBody GetDistanceReq getDistanceReq) throws Exception {
        return ResponseEntity.ok(new BaseRes<>(HttpStatus.OK.value(), TextStatus.GET_DISTANCE, commonService.getDistance(getDistanceReq)));
    }
}
