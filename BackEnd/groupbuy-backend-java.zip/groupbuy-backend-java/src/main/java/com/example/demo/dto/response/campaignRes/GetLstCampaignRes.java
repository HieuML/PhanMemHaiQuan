package com.example.demo.dto.response.campaignRes;

import com.example.demo.dto.response.PageRes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GetLstCampaignRes {
    private List<CampaignRes1> content = new ArrayList<>();
    private PageRes pageRes;
    private Long totalItem;
}
