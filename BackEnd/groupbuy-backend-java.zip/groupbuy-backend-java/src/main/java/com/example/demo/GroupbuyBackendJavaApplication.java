package com.example.demo;

import com.example.demo.constants.AdminAccount;
import com.example.demo.constants.RoleName;
import com.example.demo.entities.Role;
import com.example.demo.entities.User;
import com.example.demo.entities.Wallet;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableJpaAuditing
@SpringBootApplication
public class GroupbuyBackendJavaApplication implements CommandLineRunner {
    @Autowired
    UserRepository userRepository;
    @Autowired
    WalletRepository walletRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    PasswordEncoder encoder;

    public static void main(String[] args) {
        SpringApplication.run(GroupbuyBackendJavaApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
//        roleRepository.save(new Role(RoleName.CUSTOMER));
//        roleRepository.save(new Role(RoleName.SELLER));
//        roleRepository.save(new Role(RoleName.ADMIN));
//        User admin = userRepository.save(new User(AdminAccount.USERNAME, encoder.encode(AdminAccount.PASSWORD), AdminAccount.EMAIL, roleRepository.findByName(RoleName.ADMIN)));
//        walletRepository.save(new Wallet(admin));
    }
}
