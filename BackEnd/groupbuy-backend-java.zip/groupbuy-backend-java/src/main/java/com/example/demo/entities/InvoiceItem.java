package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "invoice_item")
@Setter
@Getter
@NoArgsConstructor
public class InvoiceItem {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "invoice_item_id")
    private Integer invoiceItemID;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "invoice_id", nullable = false)
    private Invoice invoice;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "inStock_product_id", nullable = true)
    private InStockProduct inStockProduct;
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "buy_type_id", nullable = false)
    private BuyType buyType;
    @Column(name = "price_current")
    private Integer priceCurrent;
    private Integer quantity;
    @Column(name = "deposit")
    private Integer deposit;
    private Boolean isFinalPrice;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;
}
