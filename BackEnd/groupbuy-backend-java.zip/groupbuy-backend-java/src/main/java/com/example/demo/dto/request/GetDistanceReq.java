package com.example.demo.dto.request;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class GetDistanceReq {
    private String startLocation;
    private String endLocation;
}
