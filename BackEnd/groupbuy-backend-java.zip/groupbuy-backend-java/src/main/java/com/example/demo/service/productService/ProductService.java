package com.example.demo.service.productService;

import com.example.demo.dto.request.productReq.ChangeDefaultImageReq;
import com.example.demo.dto.request.productReq.CreateOrUpdateProductReq;
import com.example.demo.dto.request.productReq.GetAllProductReq;
import com.example.demo.dto.response.productImageRes.ProductImageRes;
import com.example.demo.dto.response.productRes.ProductRes;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

public interface ProductService {
    Map<String, Object> getAllProductByShop(GetAllProductReq getALLProductReq);

    ProductRes getDetailProduct(String productID);

    ProductRes createProduct(HttpServletRequest request, CreateOrUpdateProductReq product);

    void updateProduct(HttpServletRequest request, String productID, CreateOrUpdateProductReq product);

    void deleteProduct(HttpServletRequest request, String productID);
    
    void changeStatus(HttpServletRequest request, String productID);

    List<ProductImageRes> getAllImageByProduct(String productID);

    void changeDefaultImage(HttpServletRequest request, ChangeDefaultImageReq changeDefaultImageReq);
}
