package com.example.demo.service.shippingAddressService;

import com.example.demo.dto.request.shippingAddressReq.ShippingAddressCreateReq;
import com.example.demo.dto.request.shippingAddressReq.ShippingAddressUpdateReq;
import com.example.demo.dto.response.BaseRes;

import javax.servlet.http.HttpServletRequest;

public interface ShippingAddressService {
    /**
     * create shipping address
     *
     * @param req
     * @return
     */
    BaseRes create(HttpServletRequest request, ShippingAddressCreateReq req);

    /**
     * get by user
     *
     * @return
     */
    BaseRes getByUser(HttpServletRequest request);

    /**
     * get by user
     *
     * @return
     */
    BaseRes getAddressDefault(HttpServletRequest request);

    /**
     * update shipping address
     *
     * @param req
     * @return
     */
    BaseRes update(HttpServletRequest request, ShippingAddressUpdateReq req);

    /**
     * delete shipping address
     *
     * @param shippingAddressID
     * @return
     */
    BaseRes delete(HttpServletRequest request, Integer shippingAddressID);

    /**
     * change default shipping address
     *
     * @param shippingAddressID
     * @return
     */
    BaseRes changeDefaultAddress(HttpServletRequest request, Integer shippingAddressID);
}
