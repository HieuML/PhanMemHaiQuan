package com.example.demo.dto.response.shopRes;

import com.example.demo.dto.response.PageRes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Getter
@Service
@AllArgsConstructor
@NoArgsConstructor
public class ListShopRes {
    private List<ShopDetailRes> listShop;
    private PageRes pageRes;
}
