package com.example.demo.dto.request.invoiceReq;

import com.example.demo.dto.request.PageReq;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetLstInvoiceReq extends PageReq {
    private String filterStatus;
}
