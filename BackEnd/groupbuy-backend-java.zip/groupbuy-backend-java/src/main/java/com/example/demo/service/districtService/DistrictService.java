package com.example.demo.service.districtService;

import com.example.demo.dto.response.BaseRes;
import com.example.demo.dto.response.districtRes.DistrictRes;

import java.util.List;

public interface DistrictService {
    /**
     * get all distric
     *
     * @return
     */
    BaseRes getAll();

    /**
     * get district by cityId
     *
     * @param cityID
     * @return
     */
    List<DistrictRes> getDistrictByCity(Integer cityID);
}
