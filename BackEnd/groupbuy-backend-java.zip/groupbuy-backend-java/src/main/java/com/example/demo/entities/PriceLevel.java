package com.example.demo.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "price_level")
@Setter
@Getter
@NoArgsConstructor
public class PriceLevel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "price_level_id")
    private Integer priceLevelID;
    private Integer quantity;
    private Integer price;
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "campaign_id", nullable = true)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Campaign campaign;
    private Boolean isCurrent;
    @Column(name = "created_at")
    private Long createdAt;
    @Column(name = "updated_at")
    private Long updatedAt;

    public PriceLevel(Integer quantity, Integer price, Boolean isCurrent, Campaign campaign) {
        this.quantity = quantity;
        this.price = price;
        this.isCurrent = isCurrent;
        this.campaign = campaign;
        this.createdAt = new Date().getTime();
        this.updatedAt = new Date().getTime();
    }
}
