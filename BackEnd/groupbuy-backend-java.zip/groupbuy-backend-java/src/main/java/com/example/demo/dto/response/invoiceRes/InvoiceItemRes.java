package com.example.demo.dto.response.invoiceRes;

import com.example.demo.repository.CampaignRepository;
import com.example.demo.dto.response.productRes.InStockProductRes;
import com.example.demo.dto.response.productRes.ProductRes;
import com.example.demo.entities.Campaign;
import com.example.demo.entities.InvoiceItem;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Optional;

@Getter
@Setter
@NoArgsConstructor
public class InvoiceItemRes {
    private Integer invoiceItemID;
    private String campaignID;
    private Integer buyTypeID;
    private Integer quantity;
    private Integer priceCurrent;
    private Integer deposit;
    private ProductRes product;
    private InStockProductRes inStockProduct;
    private Boolean isFinalPrice;

    public InvoiceItemRes(InvoiceItem invoiceItem, CampaignRepository campaignRepository) {
        this.invoiceItemID = invoiceItem.getInvoiceItemID();
        this.quantity = invoiceItem.getQuantity();
        this.priceCurrent = invoiceItem.getPriceCurrent();
        this.deposit = invoiceItem.getDeposit();
        this.product = new ProductRes(invoiceItem.getProduct());
        if (invoiceItem.getInStockProduct() != null) {
            this.inStockProduct = InStockProductRes.convertFromEntity(invoiceItem.getInStockProduct());
        }
        this.isFinalPrice = invoiceItem.getIsFinalPrice();
        this.buyTypeID = invoiceItem.getBuyType().getBuyTypeID();
        if (invoiceItem.getBuyType().getBuyTypeID() == 2) {
            Optional<Campaign> campaign = campaignRepository.findByProductProductIDAndIsActive(invoiceItem.getProduct().getProductID(), true);
            if (campaign.isPresent()) this.campaignID = campaign.get().getCampaignID();
        }
    }
}
