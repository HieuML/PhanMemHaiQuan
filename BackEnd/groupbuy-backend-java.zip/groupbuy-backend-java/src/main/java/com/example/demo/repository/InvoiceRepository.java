package com.example.demo.repository;

import com.example.demo.entities.Invoice;
import com.example.demo.entities.Shop;
import com.example.demo.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface InvoiceRepository extends JpaRepository<Invoice, String> {
    Page<Invoice> findByUserId(Integer userID, Pageable pageable);

    Page<Invoice> findByShopShopID(Integer shopID, Pageable pageable);

    @Query(value = "SELECT t from Invoice t where t.status = 'RETURNING' or t.status = 'SHIPPING_COMPLETED' or t.status= 'CANCELED_RETURN'")
    Page<Invoice> findByStatusReturningOrShippingCompletedOrCanceledReturn(Pageable pageable);

    @Query(value = "SELECT t from Invoice t where t.user = ?1 and t.status like %?2% order by t.status desc ")
    Page<Invoice> findByUserIdAndStatusContainingAndOrderByStatusDesc(User user, String containing, Pageable pageable);

    @Query(value = "SELECT t from Invoice t where t.shop = ?1 and t.status like %?2% order by t.status desc ")
    Page<Invoice> findByShopShopIDAndStatusContainingAndOrderByStatusDesc(Shop shop, String containing, Pageable pageable);

    Page<Invoice> findByStatus(String status, Pageable pageable);

    Page<Invoice> findByUserIdAndStatus(Integer userID, String status, Pageable pageable);

    Page<Invoice> findByShopShopIDAndStatus(Integer shopID, String status, Pageable pageable);

    List<Invoice> findByShopShopID(Integer shopID);

    List<Invoice> findByUserId(Integer userID);
}


